/*    */ package jp.ngt.rtm.block;
/*    */ 
/*    */ import jp.ngt.ngtlib.block.BlockContainerCustom;
/*    */ import jp.ngt.rtm.block.tileentity.TileEntityEffect;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockEffect extends BlockContainerCustom
/*    */ {
/*    */   public BlockEffect()
/*    */   {
/* 13 */     super(Material.field_151577_b);
/* 14 */     func_149713_g(0);
/* 15 */     func_149711_c(10000.0F);
/*    */   }
/*    */   
/*    */ 
/*    */   public TileEntity func_149915_a(World par1, int par2)
/*    */   {
/* 21 */     return new TileEntityEffect();
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */