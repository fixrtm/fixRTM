/*     */ package jp.ngt.rtm.block;
/*     */ 
/*     */ import jp.ngt.ngtlib.block.BlockArgHolder;
/*     */ import jp.ngt.ngtlib.block.BlockContainerCustomWithMeta;
/*     */ import jp.ngt.ngtlib.block.BlockUtil;
/*     */ import jp.ngt.ngtlib.util.NGTUtil;
/*     */ import jp.ngt.rtm.RTMBlock;
/*     */ import jp.ngt.rtm.RTMCore;
/*     */ import jp.ngt.rtm.RTMItem;
/*     */ import jp.ngt.rtm.block.tileentity.TileEntityMovingMachine;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.EnumBlockRenderType;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class BlockMovingMachine extends BlockContainerCustomWithMeta
/*     */ {
/*     */   public BlockMovingMachine()
/*     */   {
/*  28 */     super(Material.field_151573_f);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean func_149662_c(IBlockState state)
/*     */   {
/*  34 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public EnumBlockRenderType func_149645_b(IBlockState state)
/*     */   {
/*  40 */     return EnumBlockRenderType.MODEL;
/*     */   }
/*     */   
/*     */ 
/*     */   public TileEntity func_149915_a(World world, int meta)
/*     */   {
/*  46 */     return new TileEntityMovingMachine();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean onBlockActivated(BlockArgHolder holder, float hitX, float hitY, float hitZ)
/*     */   {
/*  52 */     World world = holder.getWorld();
/*  53 */     BlockPos pos = holder.getBlockPos();
/*  54 */     EntityPlayer player = holder.getPlayer();
/*  55 */     TileEntity tile0 = BlockUtil.getTileEntity(world, pos);
/*  56 */     int meta = BlockUtil.getMetadata(world, pos);
/*  57 */     TileEntityMovingMachine tile = (TileEntityMovingMachine)tile0;
/*  58 */     if (NGTUtil.isEquippedItem(player, RTMItem.crowbar))
/*     */     {
/*  60 */       if (!world.field_72995_K)
/*     */       {
/*  62 */         if (meta == 0)
/*     */         {
/*  64 */           if (!tile.hasPair())
/*     */           {
/*  66 */             tile.searchMM(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());
/*     */           }
/*     */         }
/*  69 */         else if (meta == 1)
/*     */         {
/*  71 */           tile.generateVehicle(player);
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */     }
/*  77 */     else if (world.field_72995_K)
/*     */     {
/*  79 */       TileEntityMovingMachine core = tile.getCore();
/*  80 */       player.openGui(RTMCore.instance, RTMCore.guiIdMovingMachine, world, core.func_174877_v().func_177958_n(), core.func_174877_v().func_177956_o(), core.func_174877_v().func_177952_p());
/*     */     }
/*     */     
/*  83 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void neighborChanged(BlockArgHolder holder)
/*     */   {
/*  89 */     World world = holder.getWorld();
/*  90 */     BlockPos pos = holder.getBlockPos();
/*  91 */     if (!world.field_72995_K)
/*     */     {
/*  93 */       TileEntity tile = BlockUtil.getTileEntity(world, pos);
/*  94 */       int meta = BlockUtil.getMetadata(world, pos);
/*  95 */       if (meta == 0)
/*     */       {
/*  97 */         ((TileEntityMovingMachine)tile).onBlockChanged();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean removedByPlayer(BlockArgHolder holder, boolean willHarvest)
/*     */   {
/* 105 */     World world = holder.getWorld();
/* 106 */     BlockPos pos = holder.getBlockPos();
/* 107 */     if (!world.field_72995_K)
/*     */     {
/* 109 */       TileEntity tile = BlockUtil.getTileEntity(world, pos);
/* 110 */       int meta = BlockUtil.getMetadata(world, pos);
/* 111 */       if (meta == 0)
/*     */       {
/* 113 */         ((TileEntityMovingMachine)tile).reset(true);
/*     */       }
/*     */     }
/* 116 */     return super.removedByPlayer(holder, willHarvest);
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_149666_a(CreativeTabs tabs, NonNullList<ItemStack> list)
/*     */   {
/* 123 */     list.add(new ItemStack(this, 1, 0));
/* 124 */     list.add(new ItemStack(this, 1, 1));
/*     */   }
/*     */   
/*     */ 
/*     */   protected ItemStack getItem(int damage)
/*     */   {
/* 130 */     return new ItemStack(RTMBlock.movingMachine, 1, damage);
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockMovingMachine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */