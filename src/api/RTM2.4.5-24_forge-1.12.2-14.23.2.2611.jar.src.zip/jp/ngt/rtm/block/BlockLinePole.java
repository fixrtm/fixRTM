/*    */ package jp.ngt.rtm.block;
/*    */ 
/*    */ import jp.ngt.ngtlib.block.BlockContainerCustomWithMeta;
/*    */ import jp.ngt.ngtlib.block.BlockUtil;
/*    */ import jp.ngt.rtm.RTMBlock;
/*    */ import jp.ngt.rtm.RTMItem;
/*    */ import jp.ngt.rtm.block.tileentity.TileEntityPole;
/*    */ import jp.ngt.rtm.item.ItemInstalledObject.IstlObjType;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockLinePole extends BlockContainerCustomWithMeta
/*    */ {
/*    */   public BlockLinePole()
/*    */   {
/* 23 */     super(Material.field_151576_e);
/* 24 */     func_149711_c(2.0F);
/* 25 */     func_149752_b(10.0F);
/*    */   }
/*    */   
/*    */ 
/*    */   public TileEntity func_149915_a(World world, int par2)
/*    */   {
/* 31 */     return new TileEntityPole();
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isLadder(IBlockState state, IBlockAccess world, BlockPos pos, EntityLivingBase entity)
/*    */   {
/* 37 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   protected ItemStack getItem(int damage)
/*    */   {
/* 43 */     if (this == RTMBlock.linePole)
/*    */     {
/* 45 */       return new ItemStack(RTMItem.installedObject, 1, ItemInstalledObject.IstlObjType.LINEPOLE.id);
/*    */     }
/*    */     
/*    */ 
/* 49 */     return new ItemStack(RTMBlock.framework, 1, damage);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static boolean isConnected(IBlockAccess world, int x, int y, int z, int type)
/*    */   {
/* 75 */     IBlockState state = BlockUtil.getBlockState(world, x, y, z);
/* 76 */     Block block = state.func_177230_c();
/* 77 */     boolean isPole = (block == RTMBlock.linePole) || (block == RTMBlock.framework) || (block == RTMBlock.signal);
/* 78 */     if (type == 0)
/*    */     {
/* 80 */       return isPole;
/*    */     }
/* 82 */     if (type == 1)
/*    */     {
/* 84 */       return (isPole) || (state.func_185914_p());
/*    */     }
/* 86 */     if (type == 2)
/*    */     {
/* 88 */       Material material = state.func_185904_a();
/* 89 */       return (material != Material.field_151579_a) && (!material.func_76224_d());
/*    */     }
/* 91 */     return true;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockLinePole.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */