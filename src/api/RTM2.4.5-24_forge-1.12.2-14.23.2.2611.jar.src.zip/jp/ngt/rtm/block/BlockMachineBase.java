/*    */ package jp.ngt.rtm.block;
/*    */ 
/*    */ import jp.ngt.ngtlib.block.BlockArgHolder;
/*    */ import jp.ngt.ngtlib.block.BlockContainerCustomWithMeta;
/*    */ import jp.ngt.rtm.RTMCore;
/*    */ import jp.ngt.rtm.block.tileentity.TileEntityMachineBase;
/*    */ import jp.ngt.rtm.modelpack.cfg.MachineConfig;
/*    */ import jp.ngt.rtm.modelpack.modelset.ModelSetMachine;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public abstract class BlockMachineBase extends BlockContainerCustomWithMeta
/*    */ {
/*    */   protected BlockMachineBase(net.minecraft.block.material.Material mat)
/*    */   {
/* 19 */     super(mat);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean onBlockActivated(BlockArgHolder holder, float hitX, float hitY, float hitZ)
/*    */   {
/* 25 */     clickMachine(holder.getWorld(), holder.getBlockPos().func_177958_n(), holder.getBlockPos().func_177956_o(), holder.getBlockPos().func_177952_p(), holder.getPlayer());
/* 26 */     return true;
/*    */   }
/*    */   
/*    */   protected boolean clickMachine(World world, int x, int y, int z, EntityPlayer player)
/*    */   {
/* 31 */     if (player.func_70093_af())
/*    */     {
/* 33 */       if (world.field_72995_K)
/*    */       {
/* 35 */         player.openGui(RTMCore.instance, RTMCore.guiIdSelectTileEntityModel, player.func_130014_f_(), x, y, z);
/*    */       }
/* 37 */       return true;
/*    */     }
/* 39 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   public int getLightValue(IBlockState state, IBlockAccess world, BlockPos pos)
/*    */   {
/* 45 */     TileEntityMachineBase tile = (TileEntityMachineBase)world.func_175625_s(pos);
/* 46 */     if (tile == null) return 0;
/* 47 */     MachineConfig cfg = (MachineConfig)((ModelSetMachine)tile.getResourceState().getResourceSet()).getConfig();
/* 48 */     return tile.isGettingPower ? cfg.brightness[1] : cfg.brightness[0];
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockMachineBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */