/*    */ package jp.ngt.rtm.block;
/*    */ 
/*    */ import java.util.Random;
/*    */ import jp.ngt.ngtlib.block.BlockCustomWithMeta;
/*    */ import jp.ngt.ngtlib.block.BlockUtil;
/*    */ import jp.ngt.rtm.RTMMaterial;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.DamageSource;
/*    */ import net.minecraft.util.EnumBlockRenderType;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockMetalSlab
/*    */   extends BlockCustomWithMeta
/*    */ {
/*    */   public BlockMetalSlab()
/*    */   {
/* 20 */     super(RTMMaterial.fireproof);
/* 21 */     func_149713_g(0);
/* 22 */     func_149675_a(true);
/* 23 */     setAABB(new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.0625D, 1.0D));
/*    */   }
/*    */   
/*    */ 
/*    */   public EnumBlockRenderType func_149645_b(IBlockState state)
/*    */   {
/* 29 */     return EnumBlockRenderType.MODEL;
/*    */   }
/*    */   
/*    */ 
/*    */   public void func_180634_a(World world, BlockPos pos, IBlockState state, Entity entity)
/*    */   {
/* 35 */     if (BlockUtil.getMetadata(world, pos) > 0)
/*    */     {
/* 37 */       entity.func_70097_a(DamageSource.field_76371_c, 1.0F);
/* 38 */       entity.func_70015_d(1);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void func_180650_b(World world, BlockPos pos, IBlockState state, Random rand)
/*    */   {
/* 45 */     if (!world.field_72995_K)
/*    */     {
/* 47 */       int meta = BlockUtil.getMetadata(world, pos);
/* 48 */       if (meta > 0)
/*    */       {
/* 50 */         BlockUtil.setBlock(world, pos, this, --meta, 2);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public String getHarvestTool(IBlockState state)
/*    */   {
/* 58 */     return "";
/*    */   }
/*    */   
/*    */ 
/*    */   public int getHarvestLevel(IBlockState state)
/*    */   {
/* 64 */     return -1;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockMetalSlab.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */