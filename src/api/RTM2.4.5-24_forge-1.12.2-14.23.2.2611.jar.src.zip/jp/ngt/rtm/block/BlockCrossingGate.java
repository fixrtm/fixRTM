/*    */ package jp.ngt.rtm.block;
/*    */ 
/*    */ import jp.ngt.ngtlib.block.BlockArgHolder;
/*    */ import jp.ngt.ngtlib.block.BlockUtil;
/*    */ import jp.ngt.rtm.RTMItem;
/*    */ import jp.ngt.rtm.block.tileentity.TileEntityCrossingGate;
/*    */ import jp.ngt.rtm.item.ItemInstalledObject.IstlObjType;
/*    */ import net.minecraft.block.SoundType;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockCrossingGate extends BlockMachineBase
/*    */ {
/*    */   public BlockCrossingGate()
/*    */   {
/* 21 */     super(Material.field_151576_e);
/* 22 */     func_149672_a(SoundType.field_185853_f);
/* 23 */     func_149713_g(0);
/* 24 */     setAABB(new AxisAlignedBB(0.125D, 0.0D, 0.125D, 0.875D, 3.0D, 0.875D));
/*    */   }
/*    */   
/*    */ 
/*    */   public TileEntity func_149915_a(World world, int par2)
/*    */   {
/* 30 */     return new TileEntityCrossingGate();
/*    */   }
/*    */   
/*    */ 
/*    */   public void func_180653_a(World world, BlockPos pos, IBlockState state, float chance, int fortune)
/*    */   {
/* 36 */     if (!world.field_72995_K)
/*    */     {
/* 38 */       func_180635_a(world, pos, new ItemStack(RTMItem.installedObject, 1, ItemInstalledObject.IstlObjType.CROSSING.id));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   protected void neighborChanged(BlockArgHolder holder)
/*    */   {
/* 45 */     super.neighborChanged(holder);
/* 46 */     BlockPos pos = holder.getBlockPos();
/* 47 */     checkPower(holder.getWorld(), pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());
/*    */   }
/*    */   
/*    */ 
/*    */   public void func_176213_c(World world, BlockPos pos, IBlockState state)
/*    */   {
/* 53 */     super.func_176213_c(world, pos, state);
/* 54 */     checkPower(world, pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());
/*    */   }
/*    */   
/*    */   private void checkPower(World world, int x, int y, int z)
/*    */   {
/* 59 */     TileEntityCrossingGate tile = (TileEntityCrossingGate)BlockUtil.getTileEntity(world, x, y, z);
/* 60 */     tile.isGettingPower = (world.func_175687_A(new BlockPos(x, y, z)) > 0);
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockCrossingGate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */