/*     */ package jp.ngt.rtm.block;
/*     */ 
/*     */ import java.util.Random;
/*     */ import jp.ngt.ngtlib.block.BlockArgHolder;
/*     */ import jp.ngt.ngtlib.block.BlockContainerCustomWithMeta;
/*     */ import jp.ngt.rtm.RTMCore;
/*     */ import jp.ngt.rtm.block.tileentity.TileEntitySignBoard;
/*     */ import jp.ngt.rtm.item.ItemInstalledObject.IstlObjType;
/*     */ import jp.ngt.rtm.modelpack.cfg.SignboardConfig;
/*     */ import jp.ngt.rtm.modelpack.modelset.TextureSetSignboard;
/*     */ import jp.ngt.rtm.modelpack.state.ResourceStateSignboard;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockSignBoard extends BlockContainerCustomWithMeta
/*     */ {
/*     */   public BlockSignBoard()
/*     */   {
/*  22 */     super(net.minecraft.block.material.Material.field_151594_q);
/*  23 */     func_149713_g(0);
/*     */   }
/*     */   
/*     */ 
/*     */   public net.minecraft.tileentity.TileEntity func_149915_a(World var1, int var2)
/*     */   {
/*  29 */     return new TileEntitySignBoard();
/*     */   }
/*     */   
/*     */ 
/*     */   protected ItemStack getItem(int damage)
/*     */   {
/*  35 */     return new ItemStack(jp.ngt.rtm.RTMItem.installedObject, 1, ItemInstalledObject.IstlObjType.SIGNBOARD.id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean onBlockActivated(BlockArgHolder holder, float hitX, float hitY, float hitZ)
/*     */   {
/* 118 */     if (holder.getWorld().field_72995_K)
/*     */     {
/* 120 */       int x = holder.getBlockPos().func_177958_n();
/* 121 */       int y = holder.getBlockPos().func_177956_o();
/* 122 */       int z = holder.getBlockPos().func_177952_p();
/* 123 */       holder.getPlayer().openGui(RTMCore.instance, RTMCore.guiIdSignboard, holder.getWorld(), x, y, z);
/*     */     }
/* 125 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getLightValue(IBlockState state, IBlockAccess world, BlockPos pos)
/*     */   {
/* 131 */     TileEntitySignBoard tile = (TileEntitySignBoard)world.func_175625_s(pos);
/* 132 */     if (tile != null)
/*     */     {
/* 134 */       int value = ((SignboardConfig)((TextureSetSignboard)tile.getResourceState().getResourceSet()).getConfig()).lightValue;
/* 135 */       if (value >= 0)
/*     */       {
/* 137 */         return value;
/*     */       }
/* 139 */       if (value == -16)
/*     */       {
/* 141 */         return jp.ngt.ngtlib.math.NGTMath.RANDOM.nextInt(6) * 3;
/*     */       }
/* 143 */       if (tile.isGettingPower)
/*     */       {
/* 145 */         return -value;
/*     */       }
/*     */     }
/* 148 */     return 0;
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockSignBoard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */