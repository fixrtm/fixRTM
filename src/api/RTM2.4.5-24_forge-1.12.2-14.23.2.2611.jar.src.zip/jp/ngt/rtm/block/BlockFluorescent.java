/*    */ package jp.ngt.rtm.block;
/*    */ 
/*    */ import java.util.Random;
/*    */ import jp.ngt.ngtlib.block.BlockContainerCustomWithMeta;
/*    */ import jp.ngt.ngtlib.block.BlockUtil;
/*    */ import jp.ngt.ngtlib.math.NGTMath;
/*    */ import jp.ngt.rtm.RTMItem;
/*    */ import jp.ngt.rtm.block.tileentity.TileEntityFluorescent;
/*    */ import jp.ngt.rtm.item.ItemInstalledObject.IstlObjType;
/*    */ import net.minecraft.block.SoundType;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockFluorescent extends BlockContainerCustomWithMeta
/*    */ {
/*    */   public BlockFluorescent()
/*    */   {
/* 23 */     super(net.minecraft.block.material.Material.field_151592_s);
/* 24 */     func_149672_a(SoundType.field_185853_f);
/* 25 */     func_149715_a(1.0F);
/* 26 */     func_149752_b(5.0F);
/* 27 */     func_149713_g(0);
/* 28 */     func_149711_c(1.0F);
/*    */   }
/*    */   
/*    */ 
/*    */   public AxisAlignedBB func_180646_a(IBlockState state, IBlockAccess world, BlockPos pos)
/*    */   {
/* 34 */     return field_185506_k;
/*    */   }
/*    */   
/*    */ 
/*    */   public TileEntity func_149915_a(World world, int par2)
/*    */   {
/* 40 */     return new TileEntityFluorescent();
/*    */   }
/*    */   
/*    */ 
/*    */   protected ItemStack getItem(int damage)
/*    */   {
/* 46 */     return new ItemStack(RTMItem.installedObject, 1, ItemInstalledObject.IstlObjType.FLUORESCENT.id);
/*    */   }
/*    */   
/*    */ 
/*    */   public int getLightValue(IBlockState state, IBlockAccess world, BlockPos pos)
/*    */   {
/* 52 */     if (BlockUtil.getMetadata(world, pos) == 2)
/*    */     {
/* 54 */       switch (NGTMath.RANDOM.nextInt(4)) {
/*    */       case 0: 
/* 56 */         return 0;
/* 57 */       case 1:  return 4;
/* 58 */       case 2:  return 8;
/* 59 */       case 3:  return 12;
/*    */       }
/*    */     }
/* 62 */     return 15;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockFluorescent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */