/*    */ package jp.ngt.rtm.block;
/*    */ 
/*    */ import jp.ngt.ngtlib.block.BlockArgHolder;
/*    */ import jp.ngt.ngtlib.block.BlockContainerCustomWithMeta;
/*    */ import jp.ngt.ngtlib.block.BlockUtil;
/*    */ import jp.ngt.rtm.RTMCore;
/*    */ import jp.ngt.rtm.RTMItem;
/*    */ import jp.ngt.rtm.block.tileentity.TileEntityRailroadSign;
/*    */ import jp.ngt.rtm.item.ItemInstalledObject.IstlObjType;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockRailroadSign extends BlockContainerCustomWithMeta
/*    */ {
/*    */   public BlockRailroadSign()
/*    */   {
/* 24 */     super(net.minecraft.block.material.Material.field_151594_q);
/* 25 */     float f0 = 0.0625F;
/* 26 */     setAABB(new AxisAlignedBB(f0 * 7.0F, 0.0D, f0 * 7.0F, f0 * 9.0F, 1.5D, f0 * 9.0F));
/*    */   }
/*    */   
/*    */ 
/*    */   public TileEntity func_149915_a(World var1, int var2)
/*    */   {
/* 32 */     return new TileEntityRailroadSign();
/*    */   }
/*    */   
/*    */ 
/*    */   public AxisAlignedBB func_185496_a(IBlockState state, IBlockAccess world, BlockPos pos)
/*    */   {
/* 38 */     if (BlockUtil.getBlock(world, pos.func_177984_a()) != Blocks.field_150350_a)
/*    */     {
/* 40 */       return new AxisAlignedBB(0.4375D, -0.5D, 0.4375D, 0.5625D, 1.0D, 0.5625D);
/*    */     }
/*    */     
/*    */ 
/* 44 */     return new AxisAlignedBB(0.4375D, 0.0D, 0.4375D, 0.5625D, 1.5D, 0.5625D);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean onBlockActivated(BlockArgHolder holder, float hitX, float hitY, float hitZ)
/*    */   {
/* 51 */     if (holder.getWorld().field_72995_K)
/*    */     {
/* 53 */       int x = holder.getBlockPos().func_177958_n();
/* 54 */       int y = holder.getBlockPos().func_177956_o();
/* 55 */       int z = holder.getBlockPos().func_177952_p();
/* 56 */       holder.getPlayer().openGui(RTMCore.instance, RTMCore.guiIdSelectTileEntityTexture, holder.getWorld(), x, y, z);
/*    */     }
/* 58 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   protected ItemStack getItem(int damage)
/*    */   {
/* 64 */     return new ItemStack(RTMItem.installedObject, 1, ItemInstalledObject.IstlObjType.RAILLOAD_SIGN.id);
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockRailroadSign.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */