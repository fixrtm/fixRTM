/*    */ package jp.ngt.rtm.block;
/*    */ 
/*    */ import jp.ngt.ngtlib.block.BlockContainerCustom;
/*    */ import jp.ngt.rtm.block.tileentity.TileEntityDecoration;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockDecoration extends BlockContainerCustom
/*    */ {
/*    */   public BlockDecoration()
/*    */   {
/* 13 */     super(Material.field_151576_e);
/*    */   }
/*    */   
/*    */ 
/*    */   public TileEntity func_149915_a(World world, int meta)
/*    */   {
/* 19 */     return new TileEntityDecoration();
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockDecoration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */