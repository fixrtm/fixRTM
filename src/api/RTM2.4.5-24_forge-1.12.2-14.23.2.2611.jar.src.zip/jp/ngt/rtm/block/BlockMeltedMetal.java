/*     */ package jp.ngt.rtm.block;
/*     */ 
/*     */ import java.util.Random;
/*     */ import jp.ngt.ngtlib.block.BlockLiquidBase;
/*     */ import jp.ngt.ngtlib.block.BlockUtil;
/*     */ import jp.ngt.rtm.RTMBlock;
/*     */ import jp.ngt.rtm.RTMFluid;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fluids.Fluid;
/*     */ 
/*     */ public class BlockMeltedMetal
/*     */   extends BlockLiquidBase
/*     */ {
/*     */   public BlockMeltedMetal(Fluid fluid)
/*     */   {
/*  24 */     super(fluid, Material.field_151587_i);
/*  25 */     func_149715_a(1.0F);
/*     */   }
/*     */   
/*     */ 
/*     */   public int func_149738_a(World world)
/*     */   {
/*  31 */     return 10;
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_180650_b(World world, BlockPos pos, IBlockState state, Random random)
/*     */   {
/*  37 */     super.func_180650_b(world, pos, state, random);
/*     */     
/*  39 */     int x = pos.func_177958_n();
/*  40 */     int y = pos.func_177956_o();
/*  41 */     int z = pos.func_177952_p();
/*     */     
/*  43 */     if (this == RTMFluid.liquefiedSteel)
/*     */     {
/*  45 */       if ((BlockUtil.getMetadata(world, x, y, z) == 0) && (random.nextInt(5) == 0))
/*     */       {
/*  47 */         if (!world.field_72995_K)
/*     */         {
/*  49 */           boolean flag0 = false;
/*  50 */           boolean flag1 = true;
/*  51 */           for (int i = 0; i < BlockUtil.facing.length; i++)
/*     */           {
/*  53 */             int x0 = x + BlockUtil.facing[i][0];
/*  54 */             int y0 = y + BlockUtil.facing[i][1];
/*  55 */             int z0 = z + BlockUtil.facing[i][2];
/*  56 */             Block block1 = BlockUtil.getBlock(world, x0, y0, z0);
/*  57 */             if (block1 == Blocks.field_150350_a)
/*     */             {
/*  59 */               flag0 = true;
/*     */             }
/*     */             
/*  62 */             if (((block1 instanceof BlockLiquidBase)) && (BlockUtil.getMetadata(world, x0, y0, z0) > 0))
/*     */             {
/*  64 */               flag1 = false;
/*     */             }
/*     */           }
/*     */           
/*  68 */           if ((flag0) && (flag1) && (random.nextInt(5) == 0))
/*     */           {
/*  70 */             BlockUtil.setBlock(world, x, y, z, RTMBlock.steelSlab, 15, 2);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected int canFlowLiquid(World world, int x, int y, int z)
/*     */   {
/*  80 */     Block block = BlockUtil.getBlock(world, x, y, z);
/*  81 */     if ((block == RTMFluid.furnaceFire) || (block == RTMFluid.exhaustGas))
/*     */     {
/*  83 */       return 15;
/*     */     }
/*  85 */     return super.canFlowLiquid(world, x, y, z);
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_189540_a(IBlockState state, World world, BlockPos pos, Block block, BlockPos fromPos)
/*     */   {
/*  91 */     if (!world.field_72995_K)
/*     */     {
/*  93 */       int x = pos.func_177958_n();
/*  94 */       int y = pos.func_177956_o();
/*  95 */       int z = pos.func_177952_p();
/*     */       
/*  97 */       for (int i = 0; i < BlockUtil.facing.length; i++)
/*     */       {
/*  99 */         int x0 = x + BlockUtil.facing[i][0];
/* 100 */         int y0 = y + BlockUtil.facing[i][1];
/* 101 */         int z0 = z + BlockUtil.facing[i][2];
/* 102 */         IBlockState state2 = BlockUtil.getBlockState(world, x0, y0, z0);
/* 103 */         if (state2.func_185904_a() == Material.field_151586_h)
/*     */         {
/* 105 */           BlockUtil.setAir(world, x0, y0, z0);
/* 106 */           BlockUtil.setAir(world, x, y, z);
/* 107 */           world.func_72876_a(null, x + 0.5D, y + 0.5D, z + 0.5D, 8.0F, true);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 112 */     super.func_189540_a(state, world, pos, block, fromPos);
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_180634_a(World world, BlockPos pos, IBlockState state, Entity entity)
/*     */   {
/* 118 */     entity.field_70181_x = 0.20000000298023224D;
/* 119 */     entity.field_70159_w = ((world.field_73012_v.nextFloat() - world.field_73012_v.nextFloat()) * 0.2F);
/* 120 */     entity.field_70179_y = ((world.field_73012_v.nextFloat() - world.field_73012_v.nextFloat()) * 0.2F);
/* 121 */     entity.func_184185_a(SoundEvents.field_187662_cZ, 0.4F, 2.0F + world.field_73012_v.nextFloat() * 0.4F);
/* 122 */     entity.func_70097_a(DamageSource.field_76371_c, 1.0F);
/* 123 */     entity.func_70015_d(5);
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockMeltedMetal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */