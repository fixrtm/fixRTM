/*     */ package jp.ngt.rtm.block.tileentity;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import jp.ngt.ngtlib.block.TileEntityCustom;
/*     */ import jp.ngt.ngtlib.item.ItemUtil;
/*     */ import jp.ngt.rtm.RTMCore;
/*     */ import jp.ngt.rtm.gui.ContainerRTMWorkBench;
/*     */ import jp.ngt.rtm.network.PacketNotice;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.util.ITickable;
/*     */ import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
/*     */ 
/*     */ public class TileEntityTrainWorkBench extends TileEntityCustom implements ITickable
/*     */ {
/*  19 */   private ItemStack[] craftSlots = ItemUtil.getEmptyArray(30);
/*     */   
/*     */   public static final int Max_CraftingTime = 64;
/*  22 */   private int craftingTime = 0;
/*  23 */   private boolean isCrafting = false;
/*     */   
/*     */ 
/*     */   public void func_145839_a(NBTTagCompound nbt)
/*     */   {
/*  28 */     super.func_145839_a(nbt);
/*  29 */     NBTTagList nbttaglist = nbt.func_150295_c("Items", 10);
/*  30 */     Arrays.fill(this.craftSlots, ItemStack.field_190927_a);
/*  31 */     for (int i = 0; i < nbttaglist.func_74745_c(); i++)
/*     */     {
/*  33 */       NBTTagCompound nbt1 = nbttaglist.func_150305_b(i);
/*  34 */       int j = nbt1.func_74771_c("Slot") & 0xFF;
/*  35 */       if ((j >= 0) && (j < this.craftSlots.length))
/*     */       {
/*  37 */         this.craftSlots[j] = new ItemStack(nbt1);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public NBTTagCompound func_189515_b(NBTTagCompound nbt)
/*     */   {
/*  45 */     super.func_189515_b(nbt);
/*  46 */     NBTTagList tagList = new NBTTagList();
/*  47 */     for (int i = 0; i < this.craftSlots.length; i++)
/*     */     {
/*  49 */       if (this.craftSlots[i] != null)
/*     */       {
/*  51 */         NBTTagCompound nbt1 = new NBTTagCompound();
/*  52 */         nbt1.func_74774_a("Slot", (byte)i);
/*  53 */         this.craftSlots[i].func_77955_b(nbt1);
/*  54 */         tagList.func_74742_a(nbt1);
/*     */       }
/*     */     }
/*  57 */     nbt.func_74782_a("Items", tagList);
/*  58 */     return nbt;
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_73660_a()
/*     */   {
/*  64 */     if (this.isCrafting)
/*     */     {
/*  66 */       if (this.craftingTime < 64)
/*     */       {
/*  68 */         this.craftingTime += 1;
/*     */       }
/*     */       else
/*     */       {
/*  72 */         this.craftingTime = 0;
/*  73 */         this.isCrafting = false;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void readItemsFromTile(IInventory inventory, IInventory inv2)
/*     */   {
/*  80 */     for (int i = 0; i < 25; i++)
/*     */     {
/*  82 */       inventory.func_70299_a(i, this.craftSlots[i]);
/*     */     }
/*     */     
/*  85 */     for (int i = 25; i < 30; i++)
/*     */     {
/*  87 */       inv2.func_70299_a(i - 25, this.craftSlots[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeItemsToTile(IInventory inventory, IInventory inv2)
/*     */   {
/*  93 */     for (int i = 0; i < this.craftSlots.length; i++)
/*     */     {
/*  95 */       this.craftSlots[i] = inventory.func_70301_a(i);
/*     */     }
/*     */     
/*  98 */     for (int i = 25; i < 30; i++)
/*     */     {
/* 100 */       this.craftSlots[i] = inv2.func_70301_a(i - 25);
/*     */     }
/*     */     
/* 103 */     sendPacket();
/*     */   }
/*     */   
/*     */   public int getCraftingTime()
/*     */   {
/* 108 */     return this.craftingTime;
/*     */   }
/*     */   
/*     */   public void setCraftingTime(int par1)
/*     */   {
/* 113 */     this.craftingTime = par1;
/*     */   }
/*     */   
/*     */   public void startCrafting(EntityPlayer player, boolean sendPacket)
/*     */   {
/* 118 */     this.craftingTime = 0;
/* 119 */     this.isCrafting = true;
/*     */     
/* 121 */     ContainerRTMWorkBench container = (ContainerRTMWorkBench)player.field_71070_bA;
/* 122 */     container.startCrafting();
/*     */     
/* 124 */     if (sendPacket)
/*     */     {
/* 126 */       String s = "StartCrafting";
/* 127 */       RTMCore.NETWORK_WRAPPER.sendToServer(new PacketNotice((byte)0, s, this));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isCrafting()
/*     */   {
/* 133 */     return this.isCrafting;
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityTrainWorkBench.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */