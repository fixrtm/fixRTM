/*     */ package jp.ngt.rtm.block.tileentity;
/*     */ 
/*     */ import jp.ngt.ngtlib.block.TileEntityCustom;
/*     */ import jp.ngt.rtm.RTMResource;
/*     */ import jp.ngt.rtm.modelpack.cfg.SignboardConfig;
/*     */ import jp.ngt.rtm.modelpack.modelset.TextureSetSignboard;
/*     */ import jp.ngt.rtm.modelpack.state.ResourceState;
/*     */ import jp.ngt.rtm.modelpack.state.ResourceStateSignboard;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.ITickable;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class TileEntitySignBoard extends TileEntityCustom implements jp.ngt.rtm.modelpack.IResourceSelector, ITickable
/*     */ {
/*  19 */   private ResourceStateSignboard state = new ResourceStateSignboard(RTMResource.SIGNBOARD);
/*     */   
/*     */   public boolean isGettingPower;
/*     */   
/*     */   private byte direction;
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int counter;
/*     */   
/*     */   public void func_145839_a(NBTTagCompound nbt)
/*     */   {
/*  30 */     super.func_145839_a(nbt);
/*  31 */     this.state.readFromNBT(nbt.func_74775_l("State"));
/*     */     
/*  33 */     if (this.state.version < 1)
/*     */     {
/*  35 */       getResourceState().setResourceName(nbt.func_74779_i("name"));
/*     */     }
/*     */     
/*  38 */     this.direction = nbt.func_74771_c("dir");
/*     */   }
/*     */   
/*     */ 
/*     */   public NBTTagCompound func_189515_b(NBTTagCompound nbt)
/*     */   {
/*  44 */     super.func_189515_b(nbt);
/*  45 */     nbt.func_74782_a("State", this.state.writeToNBT());
/*  46 */     nbt.func_74774_a("dir", this.direction);
/*  47 */     return nbt;
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_73660_a()
/*     */   {
/*  53 */     TextureSetSignboard set = (TextureSetSignboard)getResourceState().getResourceSet();
/*     */     
/*  55 */     if (this.field_145850_b.field_72995_K)
/*     */     {
/*  57 */       this.counter += 1;
/*  58 */       if (this.counter >= ((SignboardConfig)set.getConfig()).frame * ((SignboardConfig)set.getConfig()).animationCycle)
/*     */       {
/*  60 */         this.counter = 0;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  65 */     boolean b = this.field_145850_b.func_175687_A(func_174877_v()) > 0;
/*  66 */     if ((this.isGettingPower ^ b))
/*     */     {
/*  68 */       this.isGettingPower = b;
/*  69 */       this.field_145850_b.func_175664_x(func_174877_v());
/*     */     }
/*  71 */     else if (((SignboardConfig)set.getConfig()).lightValue == -16)
/*     */     {
/*  73 */       this.field_145850_b.func_175664_x(func_174877_v());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void updateResourceState()
/*     */   {
/*  80 */     if ((this.field_145850_b == null) || (!this.field_145850_b.field_72995_K))
/*     */     {
/*  82 */       func_70296_d();
/*  83 */       sendPacket();
/*  84 */       if (this.field_145850_b != null)
/*     */       {
/*  86 */         jp.ngt.ngtlib.block.BlockUtil.markBlockForUpdate(func_145831_w(), func_174877_v());
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*  91 */       this.counter = 0;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int[] getSelectorPos()
/*     */   {
/*  98 */     return new int[] { func_174877_v().func_177958_n(), func_174877_v().func_177956_o(), func_174877_v().func_177952_p() };
/*     */   }
/*     */   
/*     */   public byte getDirection()
/*     */   {
/* 103 */     return this.direction;
/*     */   }
/*     */   
/*     */   public void setDirection(byte par1)
/*     */   {
/* 108 */     this.direction = par1;
/* 109 */     sendPacket();
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public AxisAlignedBB getRenderBoundingBox()
/*     */   {
/* 116 */     TextureSetSignboard set = (TextureSetSignboard)getResourceState().getResourceSet();
/* 117 */     SignboardConfig cfg = (SignboardConfig)set.getConfig();
/* 118 */     int x = func_174877_v().func_177958_n();
/* 119 */     int y = func_174877_v().func_177956_o();
/* 120 */     int z = func_174877_v().func_177952_p();
/* 121 */     double height = cfg.height / 2.0F;
/* 122 */     double width = cfg.width / 2.0F;
/* 123 */     double depth = cfg.depth / 2.0F;
/* 124 */     double d0 = width >= depth ? width : depth;
/* 125 */     AxisAlignedBB bb = new AxisAlignedBB(x - d0, y - height, z - d0, x + d0 + 1.0D, y + height + 1.0D, z + d0 + 1.0D);
/* 126 */     return bb;
/*     */   }
/*     */   
/*     */ 
/*     */   public ResourceStateSignboard getResourceState()
/*     */   {
/* 132 */     return this.state;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean closeGui(ResourceState par1)
/*     */   {
/* 138 */     return true;
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntitySignBoard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */