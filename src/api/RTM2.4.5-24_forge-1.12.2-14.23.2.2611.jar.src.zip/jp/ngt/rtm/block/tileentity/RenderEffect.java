/*     */ package jp.ngt.rtm.block.tileentity;
/*     */ 
/*     */ import jp.ngt.ngtlib.renderer.GLHelper;
/*     */ import jp.ngt.ngtlib.renderer.model.IModelNGT;
/*     */ import jp.ngt.ngtlib.renderer.model.ModelLoader;
/*     */ import jp.ngt.ngtlib.renderer.model.VecAccuracy;
/*     */ import jp.ngt.rtm.RTMCore;
/*     */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class RenderEffect
/*     */   extends TileEntitySpecialRenderer<TileEntityEffect>
/*     */ {
/*  19 */   private static final ResourceLocation tex_N = new ResourceLocation("rtm", "textures/effect/explosion_n.png");
/*  20 */   private static final ResourceLocation tex_S = new ResourceLocation("rtm", "textures/effect/explosion_s.png");
/*  21 */   private static final ResourceLocation tex_R = new ResourceLocation("rtm", "textures/effect/explosion_r.png");
/*     */   
/*     */   private IModelNGT model;
/*     */   
/*     */   private IModelNGT sphere;
/*     */   private IModelNGT ring;
/*     */   private boolean finishLoading;
/*  28 */   private static final String[] partNames = { "obj1", "obj2", "obj3", "obj4", "obj5" };
/*     */   
/*     */   public RenderEffect()
/*     */   {
/*  32 */     Thread thread = new Thread()
/*     */     {
/*     */       public void run()
/*     */       {
/*  36 */         RenderEffect.this.model = ModelLoader.loadModel(new ResourceLocation("rtm", "models/explosion_n.mqo"), VecAccuracy.MEDIUM, new Object[0]);
/*  37 */         RenderEffect.this.sphere = ModelLoader.loadModel(new ResourceLocation("rtm", "models/explosion_s.mqo"), VecAccuracy.MEDIUM, new Object[0]);
/*  38 */         RenderEffect.this.ring = ModelLoader.loadModel(new ResourceLocation("rtm", "models/explosion_r.mqo"), VecAccuracy.MEDIUM, new Object[0]);
/*  39 */         RenderEffect.this.finishLoading = true;
/*     */       }
/*  41 */     };
/*  42 */     thread.start();
/*     */   }
/*     */   
/*     */   private final void render(TileEntityEffect par1, double par2, double par3, double par4, float par5)
/*     */   {
/*  47 */     if (!this.finishLoading) { return;
/*     */     }
/*  49 */     GL11.glPushMatrix();
/*  50 */     GL11.glEnable(32826);
/*  51 */     GL11.glTranslatef((float)par2 + 0.5F, (float)par3 + 0.5F, (float)par4 + 0.5F);
/*     */     
/*  53 */     if (par1.tickCount < 40)
/*     */     {
/*  55 */       float alpha = 1.0F - par1.tickCount / 40.0F;
/*  56 */       GL11.glEnable(3042);
/*  57 */       GL11.glBlendFunc(1, 1);
/*  58 */       GL11.glDisable(2896);
/*  59 */       GL11.glDepthMask(true);
/*  60 */       GLHelper.setLightmapMaxBrightness();
/*  61 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, alpha);
/*     */       
/*     */ 
/*  64 */       float size = (-0.025F * (float)Math.pow(par1.tickCount - 20.0F, 2.0D) + 10.0F) * 0.25F * 20.0F;
/*  65 */       GL11.glScalef(size, size, size);
/*  66 */       func_147499_a(tex_S);
/*  67 */       GL11.glMatrixMode(5890);
/*  68 */       GL11.glLoadIdentity();
/*  69 */       float f0 = par1.tickCount % 100 + par5;
/*  70 */       GL11.glTranslatef(0.0F, -f0 * 0.01F, 0.0F);
/*  71 */       GL11.glMatrixMode(5888);
/*  72 */       this.sphere.renderAll(RTMCore.smoothing);
/*  73 */       GL11.glMatrixMode(5890);
/*  74 */       GL11.glLoadIdentity();
/*  75 */       GL11.glMatrixMode(5888);
/*     */       
/*  77 */       GL11.glEnable(2896);
/*  78 */       GL11.glDisable(3042);
/*  79 */       GL11.glEnable(3008);
/*  80 */       GL11.glDepthMask(true);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*  85 */       float f0 = par1.tickCount - 40;
/*  86 */       float size1 = (float)(par1.getSigmoid(f0, 0.03125F) * 20.0D);
/*  87 */       float size2 = (float)(par1.getSigmoid(f0, 0.015625F) * 20.0D);
/*     */       
/*  89 */       GL11.glEnable(3042);
/*  90 */       GL11.glBlendFunc(770, 771);
/*  91 */       GL11.glDepthMask(true);
/*  92 */       float color = 1.0F - f0 / 760.0F;
/*  93 */       GL11.glColor4f(color, color, color, color);
/*  94 */       GLHelper.setLightmapMaxBrightness();
/*     */       
/*  96 */       func_147499_a(tex_N);
/*  97 */       GL11.glMatrixMode(5890);
/*  98 */       GL11.glLoadIdentity();
/*  99 */       float f1 = par1.tickCount % 100 + par5;
/* 100 */       GL11.glTranslatef(0.0F, f1 * 0.01F, 0.0F);
/* 101 */       GL11.glMatrixMode(5888);
/*     */       
/* 103 */       GL11.glPushMatrix();
/* 104 */       GL11.glScalef(size1, size1, size1);
/* 105 */       this.model.renderPart(RTMCore.smoothing, "objC");
/* 106 */       GL11.glPopMatrix();
/*     */       
/* 108 */       GL11.glPushMatrix();
/* 109 */       GL11.glScalef(size1, size2, size1);
/* 110 */       this.model.renderPart(RTMCore.smoothing, "objB");
/* 111 */       GL11.glPopMatrix();
/*     */       
/* 113 */       GL11.glPushMatrix();
/* 114 */       GL11.glScalef(size2, size2, size2);
/* 115 */       float color2 = color * 0.75F;
/* 116 */       GL11.glColor4f(color2, color2, color2, color2);
/* 117 */       float f2 = par1.tickCount % 2880 * 0.125F;
/* 118 */       GL11.glRotatef(f2, 0.0F, 1.0F, 0.0F);
/* 119 */       this.model.renderPart(RTMCore.smoothing, "objD_1");
/* 120 */       GL11.glRotatef(-f2 * 2.0F, 0.0F, 1.0F, 0.0F);
/* 121 */       this.model.renderPart(RTMCore.smoothing, "objD_2");
/* 122 */       GL11.glPopMatrix();
/*     */       
/* 124 */       GL11.glMatrixMode(5890);
/* 125 */       GL11.glLoadIdentity();
/* 126 */       GL11.glTranslatef(0.0F, -f1 * 0.01F, 0.0F);
/* 127 */       GL11.glMatrixMode(5888);
/*     */       
/* 129 */       GL11.glPushMatrix();
/* 130 */       float f3 = (size1 - size2) * 6.61F;
/* 131 */       GL11.glTranslatef(0.0F, -f3, 0.0F);
/* 132 */       GL11.glScalef(size1, size1, size1);
/* 133 */       GL11.glColor4f(color, color, color, color);
/* 134 */       this.model.renderPart(RTMCore.smoothing, "objA");
/* 135 */       GL11.glPopMatrix();
/*     */       
/* 137 */       func_147499_a(tex_R);
/* 138 */       GL11.glMatrixMode(5890);
/* 139 */       GL11.glLoadIdentity();
/* 140 */       GL11.glTranslatef(0.0F, -f1 * 0.01F, 0.0F);
/* 141 */       GL11.glMatrixMode(5888);
/*     */       
/* 143 */       GL11.glPushMatrix();
/* 144 */       f3 = (float)(par1.getLinear(f0) * 0.1D);
/* 145 */       GL11.glScalef(f3, f3 * 0.75F, f3);
/* 146 */       GL11.glTranslatef(0.0F, 0.5F, 0.0F);
/* 147 */       for (int i = 0; i < partNames.length; i++)
/*     */       {
/* 149 */         GL11.glColor4f(color, color, color, color2);
/* 150 */         this.ring.renderPart(RTMCore.smoothing, partNames[i]);
/* 151 */         color2 *= 0.75F;
/*     */       }
/* 153 */       GL11.glPopMatrix();
/*     */       
/* 155 */       GL11.glMatrixMode(5890);
/* 156 */       GL11.glLoadIdentity();
/* 157 */       GL11.glMatrixMode(5888);
/*     */       
/* 159 */       GL11.glDisable(3042);
/* 160 */       GL11.glEnable(3008);
/* 161 */       GL11.glDepthMask(true);
/*     */     }
/*     */     
/* 164 */     GL11.glPopMatrix();
/*     */   }
/*     */   
/*     */ 
/*     */   public void render(TileEntityEffect par1, double par2, double par3, double par4, float par5, int par6, float alpha)
/*     */   {
/* 170 */     render(par1, par2, par3, par4, par5);
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/RenderEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */