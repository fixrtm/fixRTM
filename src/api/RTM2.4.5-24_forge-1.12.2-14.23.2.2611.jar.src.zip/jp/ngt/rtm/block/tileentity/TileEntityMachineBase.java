/*     */ package jp.ngt.rtm.block.tileentity;
/*     */ 
/*     */ import jp.ngt.ngtlib.block.TileEntityPlaceable;
/*     */ import jp.ngt.ngtlib.math.Vec3;
/*     */ import jp.ngt.rtm.CommonProxy;
/*     */ import jp.ngt.rtm.RTMCore;
/*     */ import jp.ngt.rtm.modelpack.ResourceType;
/*     */ import jp.ngt.rtm.modelpack.ScriptExecuter;
/*     */ import jp.ngt.rtm.modelpack.modelset.ModelSetMachine;
/*     */ import jp.ngt.rtm.modelpack.state.ResourceState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.ITickable;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public abstract class TileEntityMachineBase extends TileEntityPlaceable implements jp.ngt.rtm.modelpack.IResourceSelector, ITickable
/*     */ {
/*  21 */   private ResourceState<ModelSetMachine> state = new ResourceState(getSubType());
/*  22 */   private ScriptExecuter executer = new ScriptExecuter();
/*     */   
/*     */   private float pitch;
/*     */   
/*     */   public int tick;
/*     */   
/*     */   public boolean isGettingPower;
/*     */   
/*     */   protected Vec3 normal;
/*     */   
/*     */   private boolean yawFixed;
/*     */   
/*     */   public TileEntityMachineBase()
/*     */   {
/*  36 */     getResourceState().dataMap.setEntity(this);
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_145839_a(NBTTagCompound nbt)
/*     */   {
/*  42 */     super.func_145839_a(nbt);
/*  43 */     this.state.readFromNBT(nbt.func_74775_l("State"));
/*     */     
/*  45 */     if (this.state.version < 1)
/*     */     {
/*  47 */       String s = nbt.func_74779_i("ModelName");
/*  48 */       if ((s == null) || (s.length() == 0))
/*     */       {
/*  50 */         s = getSubType().defaultName;
/*     */       }
/*  52 */       getResourceState().setResourceName(s);
/*     */     }
/*     */     
/*  55 */     this.pitch = nbt.func_74760_g("Pitch");
/*  56 */     this.yawFixed = nbt.func_74764_b("Yaw");
/*     */   }
/*     */   
/*     */ 
/*     */   public NBTTagCompound func_189515_b(NBTTagCompound nbt)
/*     */   {
/*  62 */     super.func_189515_b(nbt);
/*  63 */     nbt.func_74782_a("State", this.state.writeToNBT());
/*  64 */     nbt.func_74776_a("Pitch", this.pitch);
/*  65 */     return nbt;
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_73660_a()
/*     */   {
/*  71 */     this.tick += 1;
/*  72 */     if (this.tick == Integer.MAX_VALUE)
/*     */     {
/*  74 */       this.tick = 0;
/*     */     }
/*     */     
/*  77 */     if (!func_145831_w().field_72995_K)
/*     */     {
/*  79 */       this.executer.execScript(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRotation(EntityPlayer player, float rotationInterval, boolean synch)
/*     */   {
/*  87 */     super.setRotation(player, rotationInterval, synch);
/*  88 */     this.pitch = (-player.field_70125_A);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setRotation(float par1, boolean synch)
/*     */   {
/*  94 */     super.setRotation(par1, synch);
/*  95 */     this.yawFixed = true;
/*     */   }
/*     */   
/*     */   public float getPitch()
/*     */   {
/* 100 */     return this.pitch;
/*     */   }
/*     */   
/*     */   public Vec3 getNormal(float x, float y, float z, float pitch, float yaw)
/*     */   {
/* 105 */     if (this.normal == null)
/*     */     {
/* 107 */       this.normal = new Vec3(x, y, z);
/*     */     }
/* 109 */     return this.normal;
/*     */   }
/*     */   
/*     */ 
/*     */   public void onActivate()
/*     */   {
/* 115 */     ModelSetMachine set = (ModelSetMachine)getResourceState().getResourceSet();
/* 116 */     if ((this.field_145850_b.field_72995_K) && (set.sound_OnActivate != null))
/*     */     {
/* 118 */       RTMCore.proxy.playSound(this, set.sound_OnActivate, 1.0F, 1.0F);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean shouldRenderInPass(int pass)
/*     */   {
/* 125 */     return pass >= 0;
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*     */   public AxisAlignedBB getRenderBoundingBox()
/*     */   {
/* 132 */     AxisAlignedBB bb = new AxisAlignedBB(func_174877_v(), func_174877_v().func_177982_a(1, 1, 1));
/* 133 */     return bb;
/*     */   }
/*     */   
/*     */ 
/*     */   public ResourceState<ModelSetMachine> getResourceState()
/*     */   {
/* 139 */     return this.state;
/*     */   }
/*     */   
/*     */ 
/*     */   public void updateResourceState()
/*     */   {
/* 145 */     if ((this.field_145850_b == null) || (!this.field_145850_b.field_72995_K))
/*     */     {
/* 147 */       sendPacket();
/* 148 */       func_70296_d();
/* 149 */       jp.ngt.ngtlib.block.BlockUtil.markBlockForUpdate(func_145831_w(), func_174877_v());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int[] getSelectorPos()
/*     */   {
/* 156 */     return new int[] { func_174877_v().func_177958_n(), func_174877_v().func_177956_o(), func_174877_v().func_177952_p() };
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean closeGui(ResourceState par1)
/*     */   {
/* 162 */     return true;
/*     */   }
/*     */   
/*     */   protected abstract ResourceType getSubType();
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityMachineBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */