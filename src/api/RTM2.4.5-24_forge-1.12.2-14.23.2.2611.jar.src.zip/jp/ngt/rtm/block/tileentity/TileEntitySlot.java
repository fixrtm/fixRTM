/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.rtm.RTMBlock;
/*    */ import jp.ngt.rtm.block.BlockSlot;
/*    */ import net.minecraft.util.ITickable;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class TileEntitySlot extends net.minecraft.tileentity.TileEntity implements ITickable
/*    */ {
/*    */   private int count;
/*    */   
/*    */   public void func_73660_a()
/*    */   {
/* 15 */     this.count += 1;
/* 16 */     if (this.count > 4)
/*    */     {
/* 18 */       this.count = 0;
/*    */     }
/*    */     
/* 21 */     if ((this.count == 0) && (this.field_145850_b.func_175640_z(func_174877_v())))
/*    */     {
/* 23 */       if (!this.field_145850_b.field_72995_K)
/*    */       {
/* 25 */         ((BlockSlot)RTMBlock.slot).inhaleLiquid(this.field_145850_b, func_174877_v().func_177958_n(), func_174877_v().func_177956_o(), func_174877_v().func_177952_p());
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntitySlot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */