/*     */ package jp.ngt.rtm.block.tileentity;
/*     */ 
/*     */ import jp.ngt.ngtlib.block.BlockUtil;
/*     */ import jp.ngt.ngtlib.math.NGTMath;
/*     */ import jp.ngt.ngtlib.renderer.GLHelper;
/*     */ import jp.ngt.ngtlib.renderer.GLObject;
/*     */ import jp.ngt.ngtlib.renderer.NGTObjectRenderer;
/*     */ import jp.ngt.ngtlib.renderer.NGTRenderer;
/*     */ import jp.ngt.ngtlib.renderer.NGTTessellator;
/*     */ import jp.ngt.ngtlib.world.NGTWorld;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.texture.TextureMap;
/*     */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.MinecraftForgeClient;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class RenderMovingMachine
/*     */   extends TileEntitySpecialRenderer<TileEntityMovingMachine>
/*     */ {
/*     */   private void renderMovingMachine(TileEntityMovingMachine tileEntity, double x, double y, double z, float p5)
/*     */   {
/*  27 */     if ((!tileEntity.isCore) && (tileEntity.hasPair())) { return;
/*     */     }
/*  29 */     GL11.glPushMatrix();
/*  30 */     GL11.glEnable(32826);
/*  31 */     GL11.glEnable(2884);
/*  32 */     GL11.glTranslatef((float)x + 0.5F, (float)y + 0.5F, (float)z + 0.5F);
/*     */     
/*  34 */     GLHelper.disableLighting();
/*  35 */     GLHelper.setLightmapMaxBrightness();
/*  36 */     GL11.glDisable(3553);
/*     */     
/*  38 */     if (tileEntity.guideVisibility)
/*     */     {
/*  40 */       NGTTessellator tessellator = NGTTessellator.instance;
/*  41 */       tessellator.startDrawing(1);
/*  42 */       tessellator.setColorRGBA_I(16711680, 255);
/*  43 */       tessellator.addVertex(0.0F, 0.0F, 0.0F);
/*  44 */       tessellator.addVertex(tileEntity.pairBlockX, tileEntity.pairBlockY, tileEntity.pairBlockZ);
/*  45 */       tessellator.draw();
/*     */     }
/*     */     
/*  48 */     double dx = tileEntity.prevPosX + (tileEntity.posX - tileEntity.prevPosX) * p5;
/*  49 */     double dy = tileEntity.prevPosY + (tileEntity.posY - tileEntity.prevPosY) * p5;
/*  50 */     double dz = tileEntity.prevPosZ + (tileEntity.posZ - tileEntity.prevPosZ) * p5;
/*  51 */     GL11.glTranslatef((float)(dx + 0.5D), (float)(dy + 0.5D), (float)(dz + 0.5D));
/*     */     
/*  53 */     if (tileEntity.guideVisibility)
/*     */     {
/*  55 */       NGTRenderer.renderFrame(tileEntity.offsetX, tileEntity.offsetY, tileEntity.offsetZ, tileEntity.width, tileEntity.height, tileEntity.depth, 65295, 255);
/*     */     }
/*     */     
/*  58 */     GL11.glEnable(3553);
/*  59 */     GLHelper.enableLighting();
/*     */     
/*  61 */     if (setupBrightness(tileEntity)) {}
/*     */     
/*     */ 
/*     */ 
/*  65 */     renderBlocks(tileEntity, p5);
/*     */     
/*  67 */     GL11.glDisable(2884);
/*  68 */     GL11.glPopMatrix();
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean setupBrightness(TileEntityMovingMachine tileEntity)
/*     */   {
/*  74 */     int x = NGTMath.floor(tileEntity.func_174877_v().func_177958_n() + tileEntity.posX);
/*  75 */     int y = NGTMath.floor(tileEntity.func_174877_v().func_177956_o() + tileEntity.posY);
/*  76 */     int z = NGTMath.floor(tileEntity.func_174877_v().func_177952_p() + tileEntity.posZ);
/*  77 */     if (BlockUtil.isAir(func_178459_a(), x, y, z))
/*     */     {
/*  79 */       int i = tileEntity.func_145831_w().func_175671_l(new BlockPos(x, y, z));
/*  80 */       GLHelper.setBrightness(i);
/*  81 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  82 */       return true;
/*     */     }
/*  84 */     return false;
/*     */   }
/*     */   
/*     */   private void renderBlocks(TileEntityMovingMachine tile, float p2)
/*     */   {
/*  89 */     if ((tile.dummyWorld == null) || (tile.blocksObject == null)) { return;
/*     */     }
/*  91 */     if (tile.glLists == null)
/*     */     {
/*  93 */       tile.glLists = new GLObject[2];
/*     */     }
/*     */     
/*  96 */     int pass = MinecraftForgeClient.getRenderPass();
/*  97 */     if (pass == -1)
/*     */     {
/*  99 */       pass = 0;
/*     */     }
/* 101 */     NGTWorld world = (NGTWorld)tile.dummyWorld;
/* 102 */     NGTObjectRenderer.INSTANCE.renderTileEntities(world, p2, pass);
/*     */     
/* 104 */     RenderHelper.func_74518_a();
/* 105 */     func_147499_a(TextureMap.field_110575_b);
/* 106 */     if (!GLHelper.isValid(tile.glLists[pass]))
/*     */     {
/* 108 */       tile.glLists[pass] = GLHelper.generateGLList();
/* 109 */       GLHelper.startCompile(tile.glLists[pass]);
/* 110 */       NGTObjectRenderer.INSTANCE.renderNGTObject(world, tile.blocksObject, false, 0, pass);
/* 111 */       GLHelper.endCompile();
/*     */     }
/*     */     else
/*     */     {
/* 115 */       GLHelper.callList(tile.glLists[pass]);
/*     */     }
/* 117 */     RenderHelper.func_74519_b();
/*     */   }
/*     */   
/*     */ 
/*     */   public void render(TileEntityMovingMachine tileEntity, double p2, double p3, double p4, float p5, int p6, float alpha)
/*     */   {
/* 123 */     renderMovingMachine(tileEntity, p2, p3, p4, p5);
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/RenderMovingMachine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */