/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.rtm.RTMResource;
/*    */ import jp.ngt.rtm.modelpack.ResourceType;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.util.ITickable;
/*    */ 
/*    */ public class TileEntityFluorescent extends TileEntityOrnament implements ITickable
/*    */ {
/* 10 */   private int count = 0;
/*    */   
/*    */   public byte dirF;
/*    */   
/*    */   public void func_145839_a(NBTTagCompound nbt)
/*    */   {
/* 16 */     super.func_145839_a(nbt);
/* 17 */     this.dirF = nbt.func_74771_c("dir");
/*    */   }
/*    */   
/*    */ 
/*    */   public NBTTagCompound func_189515_b(NBTTagCompound nbt)
/*    */   {
/* 23 */     super.func_189515_b(nbt);
/* 24 */     nbt.func_74774_a("dir", this.dirF);
/* 25 */     return nbt;
/*    */   }
/*    */   
/*    */   public byte getDir()
/*    */   {
/* 30 */     return this.dirF;
/*    */   }
/*    */   
/*    */   public void setDir(byte byte0)
/*    */   {
/* 35 */     this.dirF = byte0;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void func_73660_a()
/*    */   {
/* 42 */     if (func_145832_p() == 2)
/*    */     {
/* 44 */       this.count += 1;
/* 45 */       if (this.count == 3)
/*    */       {
/*    */ 
/* 48 */         this.field_145850_b.func_175664_x(func_174877_v());
/* 49 */         this.count = 0;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   protected ResourceType getSubType()
/*    */   {
/* 57 */     return RTMResource.ORNAMENT_LAMP;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityFluorescent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */