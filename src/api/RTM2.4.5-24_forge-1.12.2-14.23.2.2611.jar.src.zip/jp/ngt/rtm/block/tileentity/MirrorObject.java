package jp.ngt.rtm.block.tileentity;

import jp.ngt.ngtlib.block.EnumFace;
import jp.ngt.rtm.block.BlockMirror.MirrorType;
import net.minecraft.world.World;

public class MirrorObject
{
  public static void remove(MirrorComponent mirrorComponent) {}
  
  public static void add(World worldObj, MirrorComponent mirrorComponent, EnumFace face, BlockMirror.MirrorType mirrorType) {}
}


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/MirrorObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */