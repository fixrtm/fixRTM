/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.rtm.RTMResource;
/*    */ import jp.ngt.rtm.modelpack.ResourceType;
/*    */ 
/*    */ public class TileEntityPlantOrnament
/*    */   extends TileEntityOrnament
/*    */ {
/*    */   protected ResourceType getSubType()
/*    */   {
/* 11 */     return RTMResource.ORNAMENT_PLANT;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityPlantOrnament.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */