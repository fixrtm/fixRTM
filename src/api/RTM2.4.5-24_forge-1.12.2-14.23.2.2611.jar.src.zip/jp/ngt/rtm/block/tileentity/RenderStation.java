/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.ngtlib.renderer.GLHelper;
/*    */ import jp.ngt.ngtlib.renderer.NGTRenderer;
/*    */ import jp.ngt.ngtlib.renderer.NGTTessellator;
/*    */ import jp.ngt.ngtlib.util.NGTUtilClient;
/*    */ import jp.ngt.rtm.RTMBlock;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.entity.EntityPlayerSP;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.renderer.entity.RenderManager;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class RenderStation extends net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer<TileEntityStation>
/*    */ {
/* 22 */   private static final ResourceLocation texture = new ResourceLocation("rtm", "textures/mark.png");
/*    */   private Item stationBlock;
/*    */   
/*    */   public void renderStation(TileEntityStation tileEntity, double par2, double par4, double par6, float par8)
/*    */   {
/* 27 */     if (this.stationBlock == null)
/*    */     {
/* 29 */       this.stationBlock = Item.func_150898_a(RTMBlock.stationCore);
/*    */     }
/*    */     
/*    */ 
/* 33 */     ItemStack stack = NGTUtilClient.getMinecraft().field_71439_g.func_184614_ca();
/* 34 */     if ((stack == null) || (stack.func_77973_b() != this.stationBlock)) { return;
/*    */     }
/* 36 */     GL11.glPushMatrix();
/* 37 */     GL11.glEnable(32826);
/* 38 */     GL11.glTranslatef((float)par2, (float)par4, (float)par6);
/* 39 */     GLHelper.disableLighting();
/* 40 */     GLHelper.setLightmapMaxBrightness();
/* 41 */     GL11.glEnable(2884);
/*    */     
/* 43 */     GL11.glDisable(3553);
/* 44 */     NGTRenderer.renderFrame(0.0F, 0.0F, 0.0F, tileEntity.width, tileEntity.height, tileEntity.depth, 65280, 255);
/* 45 */     GL11.glEnable(3553);
/*    */     
/* 47 */     GL11.glTranslatef(0.5F, 1.0F, 0.5F);
/* 48 */     GL11.glRotatef(-NGTUtilClient.getMinecraft().func_175598_ae().field_78735_i + 180.0F, 0.0F, 1.0F, 0.0F);
/* 49 */     func_147499_a(texture);
/* 50 */     float size = 8.0F;
/* 51 */     float depth = 0.0F;
/* 52 */     NGTTessellator tessellator = NGTTessellator.instance;
/* 53 */     tessellator.startDrawingQuads();
/* 54 */     tessellator.addVertexWithUV(size, 0.0F, depth, 1.0F, 1.0F);
/* 55 */     tessellator.addVertexWithUV(size, 16.0F, depth, 1.0F, 0.0F);
/* 56 */     tessellator.addVertexWithUV(-size, 16.0F, depth, 0.0F, 0.0F);
/* 57 */     tessellator.addVertexWithUV(-size, 0.0F, depth, 0.0F, 1.0F);
/* 58 */     tessellator.draw();
/*    */     
/* 60 */     GL11.glTranslatef(0.0F, 11.0F, 0.0625F);
/* 61 */     FontRenderer fontRenderer = func_147498_b();
/* 62 */     String s = tileEntity.getName();
/* 63 */     int w = fontRenderer.func_78256_a(s);
/* 64 */     float f = 4.0F / w;
/* 65 */     GL11.glScalef(f, -f, -f);
/* 66 */     fontRenderer.func_78276_b(s, -w >> 1, -4, 65280);
/*    */     
/* 68 */     GLHelper.enableLighting();
/* 69 */     GL11.glPopMatrix();
/*    */   }
/*    */   
/*    */ 
/*    */   public void render(TileEntityStation tileEntity, double par2, double par4, double par6, float par8, int par9, float alpha)
/*    */   {
/* 75 */     renderStation(tileEntity, par2, par4, par6, par8);
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/RenderStation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */