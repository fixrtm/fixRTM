/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.ngtlib.item.IItemRendererCustom;
/*    */ import jp.ngt.ngtlib.renderer.NGTTessellator;
/*    */ import jp.ngt.ngtlib.util.NGTUtilClient;
/*    */ import jp.ngt.rtm.block.decoration.DecorationModel;
/*    */ import jp.ngt.rtm.block.decoration.DecorationStore;
/*    */ import jp.ngt.rtm.block.decoration.Element;
/*    */ import jp.ngt.rtm.block.decoration.Face;
/*    */ import jp.ngt.rtm.item.ItemDecoration;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.EntityRenderer;
/*    */ import net.minecraft.client.renderer.RenderHelper;
/*    */ import net.minecraft.client.renderer.texture.TextureAtlasSprite;
/*    */ import net.minecraft.client.renderer.texture.TextureMap;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class RenderDecoration
/*    */   extends TileEntitySpecialRenderer<TileEntityDecoration> implements IItemRendererCustom
/*    */ {
/*    */   public void render(TileEntityDecoration par1, double par2, double par4, double par6, float par8, int par9, float alpha)
/*    */   {
/* 28 */     GL11.glPushMatrix();
/* 29 */     GL11.glEnable(32826);
/* 30 */     GL11.glTranslatef((float)par2 + 0.0F, (float)par4 + 0.0F, (float)par6 + 0.0F);
/* 31 */     DecorationModel model = DecorationStore.INSTANCE.getModel(par1.getModelName());
/* 32 */     renderModel(model, true);
/* 33 */     GL11.glPopMatrix();
/*    */   }
/*    */   
/*    */   public void renderModel(DecorationModel model, boolean onWorld)
/*    */   {
/* 38 */     RenderHelper.func_74518_a();
/* 39 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*    */     
/* 41 */     NGTUtilClient.bindTexture(TextureMap.field_110575_b);
/* 42 */     NGTTessellator tessellator = NGTTessellator.instance;
/* 43 */     tessellator.startDrawingQuads();
/* 44 */     for (Element element : model.elements)
/*    */     {
/* 46 */       for (Face face : element.faces)
/*    */       {
/* 48 */         TextureAtlasSprite icon = NGTUtilClient.getIcon(face.texture);
/* 49 */         tessellator.setColorOpaque_F(face.shadow, face.shadow, face.shadow);
/* 50 */         addVertex(tessellator, icon, face.vertex[0]);
/* 51 */         addVertex(tessellator, icon, face.vertex[1]);
/* 52 */         addVertex(tessellator, icon, face.vertex[2]);
/* 53 */         addVertex(tessellator, icon, face.vertex[3]);
/*    */       }
/*    */     }
/* 56 */     tessellator.draw();
/*    */     
/* 58 */     RenderHelper.func_74519_b();
/* 59 */     if (onWorld)
/*    */     {
/*    */ 
/* 62 */       NGTUtilClient.getMinecraft().field_71460_t.func_180436_i();
/*    */     }
/* 64 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*    */   }
/*    */   
/*    */   private void addVertex(NGTTessellator tessellator, TextureAtlasSprite icon, float[] array)
/*    */   {
/* 69 */     float u = icon.func_94209_e() + (icon.func_94212_f() - icon.func_94209_e()) * array[3];
/* 70 */     float v = icon.func_94206_g() + (icon.func_94210_h() - icon.func_94206_g()) * array[4];
/* 71 */     tessellator.addVertexWithUV(array[0], array[1], array[2], u, v);
/*    */   }
/*    */   
/*    */ 
/*    */   public void renderItem(ItemStack itemStack)
/*    */   {
/* 77 */     String name = ItemDecoration.getModelName(itemStack);
/* 78 */     DecorationModel model = DecorationStore.INSTANCE.getModel(name);
/* 79 */     GL11.glPushMatrix();
/*    */     
/* 81 */     GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
/* 82 */     GL11.glTranslatef(-1.0F, 0.0F, -1.0F);
/* 83 */     renderModel(model, false);
/* 84 */     GL11.glPopMatrix();
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/RenderDecoration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */