/*     */ package jp.ngt.rtm.block.tileentity;
/*     */ 
/*     */ import jp.ngt.ngtlib.renderer.GLHelper;
/*     */ import jp.ngt.ngtlib.renderer.NGTTessellator;
/*     */ import jp.ngt.ngtlib.util.ColorUtil;
/*     */ import jp.ngt.ngtlib.util.NGTUtilClient;
/*     */ import jp.ngt.rtm.CommonProxy;
/*     */ import jp.ngt.rtm.RTMCore;
/*     */ import jp.ngt.rtm.RTMItem;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityPlayerSP;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class RenderPaint extends net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer<TileEntityPaint>
/*     */ {
/*     */   private static final float PIXEL_SIZE = 0.0625F;
/*     */   private static final float GAP = 0.015625F;
/*     */   
/*     */   private void renderPaintAt(TileEntityPaint tileEntity, double par2, double par4, double par6, float par8)
/*     */   {
/*  25 */     GL11.glPushMatrix();
/*  26 */     GL11.glEnable(32826);
/*  27 */     GL11.glEnable(2884);
/*  28 */     GL11.glTranslatef((float)par2, (float)par4, (float)par6);
/*     */     
/*  30 */     GLHelper.disableLighting();
/*  31 */     GL11.glDisable(3553);
/*  32 */     GL11.glDisable(3008);
/*  33 */     GL11.glEnable(3042);
/*  34 */     GL11.glBlendFunc(770, 771);
/*  35 */     GL11.glDepthMask(false);
/*     */     
/*  37 */     NGTTessellator tessellator = NGTTessellator.instance;
/*  38 */     tessellator.startDrawingQuads();
/*  39 */     float d2 = 0.015625F;
/*  40 */     float d3 = 1.0F - d2;
/*     */     
/*  42 */     for (int i = 0; i < 6; i++)
/*     */     {
/*  44 */       if (tileEntity.hasColor(i))
/*     */       {
/*  46 */         for (int j = 0; j < 16; j++)
/*     */         {
/*  48 */           float d0 = j * 0.0625F;
/*     */           
/*  50 */           for (int k = 0; k < 16; k++)
/*     */           {
/*  52 */             int alpha = tileEntity.getAlpha(j, k, i);
/*  53 */             if (alpha != 0) {
/*  54 */               int color = tileEntity.getColor(j, k, i);
/*  55 */               float d1 = k * 0.0625F;
/*     */               
/*  57 */               switch (i)
/*     */               {
/*     */               case 0: 
/*  60 */                 tessellator.setColorRGBA_I(ColorUtil.multiplicating(8421504, color), alpha);
/*  61 */                 tessellator.addVertex(d0, d3, d1 + 0.0625F);
/*  62 */                 tessellator.addVertex(d0, d3, d1);
/*  63 */                 tessellator.addVertex(d0 + 0.0625F, d3, d1);
/*  64 */                 tessellator.addVertex(d0 + 0.0625F, d3, d1 + 0.0625F);
/*  65 */                 break;
/*     */               case 1: 
/*  67 */                 tessellator.setColorRGBA_I(color, alpha);
/*  68 */                 tessellator.addVertex(d0 + 0.0625F, d2, d1 + 0.0625F);
/*  69 */                 tessellator.addVertex(d0 + 0.0625F, d2, d1);
/*  70 */                 tessellator.addVertex(d0, d2, d1);
/*  71 */                 tessellator.addVertex(d0, d2, d1 + 0.0625F);
/*  72 */                 break;
/*     */               case 2: 
/*  74 */                 tessellator.setColorRGBA_I(ColorUtil.multiplicating(13421772, color), alpha);
/*  75 */                 tessellator.addVertex(d0 + 0.0625F, d1 + 0.0625F, d3);
/*  76 */                 tessellator.addVertex(d0 + 0.0625F, d1, d3);
/*  77 */                 tessellator.addVertex(d0, d1, d3);
/*  78 */                 tessellator.addVertex(d0, d1 + 0.0625F, d3);
/*  79 */                 break;
/*     */               case 3: 
/*  81 */                 tessellator.setColorRGBA_I(ColorUtil.multiplicating(13421772, color), alpha);
/*  82 */                 tessellator.addVertex(d0, d1 + 0.0625F, d2);
/*  83 */                 tessellator.addVertex(d0, d1, d2);
/*  84 */                 tessellator.addVertex(d0 + 0.0625F, d1, d2);
/*  85 */                 tessellator.addVertex(d0 + 0.0625F, d1 + 0.0625F, d2);
/*  86 */                 break;
/*     */               case 4: 
/*  88 */                 tessellator.setColorRGBA_I(ColorUtil.multiplicating(10066329, color), alpha);
/*  89 */                 tessellator.addVertex(d3, d0 + 0.0625F, d1 + 0.0625F);
/*  90 */                 tessellator.addVertex(d3, d0 + 0.0625F, d1);
/*  91 */                 tessellator.addVertex(d3, d0, d1);
/*  92 */                 tessellator.addVertex(d3, d0, d1 + 0.0625F);
/*  93 */                 break;
/*     */               case 5: 
/*  95 */                 tessellator.setColorRGBA_I(ColorUtil.multiplicating(10066329, color), alpha);
/*  96 */                 tessellator.addVertex(d2, d0, d1 + 0.0625F);
/*  97 */                 tessellator.addVertex(d2, d0, d1);
/*  98 */                 tessellator.addVertex(d2, d0 + 0.0625F, d1);
/*  99 */                 tessellator.addVertex(d2, d0 + 0.0625F, d1 + 0.0625F);
/*     */               }
/*     */             }
/*     */           }
/*     */         } }
/*     */     }
/* 105 */     tessellator.draw();
/*     */     
/* 107 */     GL11.glDepthMask(true);
/* 108 */     GL11.glDisable(3042);
/* 109 */     GL11.glEnable(3008);
/* 110 */     GL11.glEnable(3553);
/* 111 */     GLHelper.enableLighting();
/*     */     
/* 113 */     ItemStack stack = NGTUtilClient.getMinecraft().field_71439_g.field_71071_by.func_70448_g();
/* 114 */     if ((stack != null) && (stack.func_77973_b() == RTMItem.crowbar))
/*     */     {
/* 116 */       GL11.glTranslatef(0.5F, 0.5F, 0.5F);
/* 117 */       RTMCore.proxy.renderMissingModel();
/*     */     }
/*     */     
/* 120 */     GL11.glDisable(2884);
/* 121 */     GL11.glPopMatrix();
/*     */   }
/*     */   
/*     */ 
/*     */   public void render(TileEntityPaint par1, double par2, double par4, double par6, float par8, int par9, float alpha)
/*     */   {
/* 127 */     renderPaintAt(par1, par2, par4, par6, par8);
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/RenderPaint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */