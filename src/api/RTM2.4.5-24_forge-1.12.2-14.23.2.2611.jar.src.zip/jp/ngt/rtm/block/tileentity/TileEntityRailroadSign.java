/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.ngtlib.block.TileEntityPlaceable;
/*    */ import jp.ngt.rtm.RTMResource;
/*    */ import jp.ngt.rtm.modelpack.modelset.TextureSetRRS;
/*    */ import jp.ngt.rtm.modelpack.state.ResourceState;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class TileEntityRailroadSign extends TileEntityPlaceable implements jp.ngt.rtm.modelpack.IResourceSelector
/*    */ {
/* 16 */   private ResourceState<TextureSetRRS> state = new ResourceState(RTMResource.RRS);
/*    */   
/*    */ 
/*    */   public void func_145839_a(NBTTagCompound nbt)
/*    */   {
/* 21 */     super.func_145839_a(nbt);
/* 22 */     this.state.readFromNBT(nbt.func_74775_l("State"));
/*    */     
/* 24 */     if (this.state.version < 1)
/*    */     {
/* 26 */       getResourceState().setResourceName(nbt.func_74779_i("textureName"));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public NBTTagCompound func_189515_b(NBTTagCompound nbt)
/*    */   {
/* 33 */     super.func_189515_b(nbt);
/* 34 */     nbt.func_74782_a("State", this.state.writeToNBT());
/* 35 */     return nbt;
/*    */   }
/*    */   
/*    */ 
/*    */   @SideOnly(Side.CLIENT)
/*    */   public AxisAlignedBB getRenderBoundingBox()
/*    */   {
/* 42 */     return new AxisAlignedBB(func_174877_v(), func_174877_v().func_177982_a(1, 2, 1));
/*    */   }
/*    */   
/*    */ 
/*    */   public void updateResourceState()
/*    */   {
/* 48 */     if ((this.field_145850_b == null) || (!this.field_145850_b.field_72995_K))
/*    */     {
/* 50 */       sendPacket();
/* 51 */       func_70296_d();
/* 52 */       jp.ngt.ngtlib.block.BlockUtil.markBlockForUpdate(func_145831_w(), func_174877_v());
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public int[] getSelectorPos()
/*    */   {
/* 59 */     return new int[] { func_174877_v().func_177958_n(), func_174877_v().func_177956_o(), func_174877_v().func_177952_p() };
/*    */   }
/*    */   
/*    */ 
/*    */   public ResourceState<TextureSetRRS> getResourceState()
/*    */   {
/* 65 */     return this.state;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean closeGui(ResourceState par1)
/*    */   {
/* 71 */     return true;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityRailroadSign.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */