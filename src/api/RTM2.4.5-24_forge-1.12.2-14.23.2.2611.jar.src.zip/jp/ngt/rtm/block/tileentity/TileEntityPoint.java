/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.rtm.RTMResource;
/*    */ import jp.ngt.rtm.modelpack.ResourceType;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class TileEntityPoint extends TileEntityMachineBase
/*    */ {
/* 12 */   private boolean activated = false;
/* 13 */   private float move = 24.0F;
/*    */   
/*    */ 
/*    */   public void func_145839_a(NBTTagCompound nbt)
/*    */   {
/* 18 */     super.func_145839_a(nbt);
/* 19 */     this.activated = nbt.func_74767_n("Activated");
/* 20 */     this.move = nbt.func_74760_g("Move");
/*    */   }
/*    */   
/*    */ 
/*    */   public NBTTagCompound func_189515_b(NBTTagCompound nbt)
/*    */   {
/* 26 */     super.func_189515_b(nbt);
/* 27 */     nbt.func_74757_a("Activated", this.activated);
/* 28 */     nbt.func_74776_a("Move", this.move);
/* 29 */     return nbt;
/*    */   }
/*    */   
/*    */   public boolean isActivated()
/*    */   {
/* 34 */     return this.activated;
/*    */   }
/*    */   
/*    */   public void setActivated(boolean par1)
/*    */   {
/* 39 */     this.activated = par1;
/* 40 */     sendPacket();
/* 41 */     func_70296_d();
/*    */   }
/*    */   
/*    */   public float getMove()
/*    */   {
/* 46 */     return this.move;
/*    */   }
/*    */   
/*    */ 
/*    */   public void setMove(float par1)
/*    */   {
/* 52 */     this.move = par1;
/* 53 */     sendPacket();
/* 54 */     func_70296_d();
/*    */   }
/*    */   
/*    */ 
/*    */   @SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*    */   public AxisAlignedBB getRenderBoundingBox()
/*    */   {
/* 61 */     AxisAlignedBB bb = new AxisAlignedBB(func_174877_v().func_177982_a(-1, 0, -1), func_174877_v().func_177982_a(2, 1, 2));
/* 62 */     return bb;
/*    */   }
/*    */   
/*    */ 
/*    */   protected ResourceType getSubType()
/*    */   {
/* 68 */     return RTMResource.MACHINE_POINT;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityPoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */