/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.ngtlib.block.EnumFace;
/*    */ import jp.ngt.rtm.block.BlockMirror;
/*    */ import jp.ngt.rtm.block.BlockMirror.MirrorType;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class TileEntityMirror extends TileEntity implements net.minecraft.util.ITickable
/*    */ {
/*    */   public BlockMirror.MirrorType mirrorType;
/*    */   @SideOnly(Side.CLIENT)
/*    */   public MirrorComponent[] mirrors;
/*    */   
/*    */   public void func_73660_a()
/*    */   {
/* 21 */     if ((this.field_145850_b.field_72995_K) && (this.mirrors == null))
/*    */     {
/* 23 */       this.mirrorType = ((BlockMirror)func_145838_q()).mirrorType;
/* 24 */       setupMirror();
/*    */     }
/*    */   }
/*    */   
/*    */   private void setupMirror()
/*    */   {
/* 30 */     boolean b = this.mirrorType == BlockMirror.MirrorType.Mono_Panel;
/* 31 */     this.mirrors = new MirrorComponent[b ? 1 : 6];
/* 32 */     for (int i = 0; i < this.mirrors.length; i++)
/*    */     {
/* 34 */       EnumFace face = b ? EnumFace.get(func_145832_p()) : EnumFace.get(i);
/* 35 */       this.mirrors[i] = new MirrorComponent(func_174877_v().func_177958_n(), func_174877_v().func_177956_o(), func_174877_v().func_177952_p(), this.mirrorType, face);
/* 36 */       MirrorObject.add(this.field_145850_b, this.mirrors[i], face, this.mirrorType);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void onChunkUnload()
/*    */   {
/* 43 */     removeMirror();
/*    */   }
/*    */   
/*    */ 
/*    */   public void func_145843_s()
/*    */   {
/* 49 */     super.func_145843_s();
/* 50 */     removeMirror();
/*    */   }
/*    */   
/*    */   private void removeMirror()
/*    */   {
/* 55 */     if ((this.field_145850_b.field_72995_K) && (this.mirrors != null))
/*    */     {
/* 57 */       for (int i = 0; i < this.mirrors.length; i++)
/*    */       {
/* 59 */         MirrorObject.remove(this.mirrors[i]);
/*    */       }
/* 61 */       this.mirrors = null;
/*    */     }
/*    */   }
/*    */   
/*    */   public int getAlpha()
/*    */   {
/* 67 */     if (this.mirrorType == BlockMirror.MirrorType.Hexa_Cube)
/*    */     {
/* 69 */       int meta = func_145832_p();
/* 70 */       return (meta << 4) + meta;
/*    */     }
/*    */     
/*    */ 
/* 74 */     return 255;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean shouldRenderInPass(int pass)
/*    */   {
/* 81 */     return pass == 1;
/*    */   }
/*    */   
/*    */ 
/*    */   @SideOnly(Side.CLIENT)
/*    */   public double func_145833_n()
/*    */   {
/* 88 */     return 4096.0D;
/*    */   }
/*    */   
/*    */ 
/*    */   @SideOnly(Side.CLIENT)
/*    */   public AxisAlignedBB getRenderBoundingBox()
/*    */   {
/* 95 */     AxisAlignedBB bb = new AxisAlignedBB(func_174877_v(), func_174877_v().func_177982_a(1, 1, 1));
/* 96 */     return bb;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityMirror.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */