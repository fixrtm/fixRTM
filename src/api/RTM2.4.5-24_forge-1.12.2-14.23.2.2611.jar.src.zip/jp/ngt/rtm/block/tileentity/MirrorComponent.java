package jp.ngt.rtm.block.tileentity;

import jp.ngt.ngtlib.block.EnumFace;
import jp.ngt.rtm.block.BlockMirror.MirrorType;

public class MirrorComponent
{
  public MirrorComponent(int x, int y, int z, BlockMirror.MirrorType mirrorType, EnumFace face) {}
}


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/MirrorComponent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */