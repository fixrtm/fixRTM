/*     */ package jp.ngt.rtm.block.tileentity;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import jp.ngt.ngtlib.block.BlockUtil;
/*     */ import jp.ngt.ngtlib.block.TileEntityCustom;
/*     */ import jp.ngt.ngtlib.math.NGTMath;
/*     */ import jp.ngt.ngtlib.math.Vec3;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.PlayerCapabilities;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.ITickable;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.GameRules;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class TileEntityEffect
/*     */   extends TileEntityCustom
/*     */   implements ITickable
/*     */ {
/*     */   public static final int Phase1 = 40;
/*     */   public static final int Phase2 = 400;
/*     */   public static final int Phase3 = 800;
/*     */   public static final float Scale = 20.0F;
/*     */   public static final float Slope1 = 0.03125F;
/*     */   public static final float Slope2 = 0.015625F;
/*     */   public static final float Radius = 2.0F;
/*     */   public static final float MaxDistance = 128.0F;
/*  38 */   public static final DamageSource nuclearDamage = new DamageSource("nuclear").func_76361_j();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int tickCount;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void func_145839_a(NBTTagCompound nbt)
/*     */   {
/*  52 */     super.func_145839_a(nbt);
/*  53 */     this.tickCount = nbt.func_74762_e("count");
/*     */   }
/*     */   
/*     */ 
/*     */   public NBTTagCompound func_189515_b(NBTTagCompound nbt)
/*     */   {
/*  59 */     super.func_189515_b(nbt);
/*  60 */     nbt.func_74768_a("count", this.tickCount);
/*  61 */     return nbt;
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_73660_a()
/*     */   {
/*  67 */     if (!this.field_145850_b.field_72995_K)
/*     */     {
/*  69 */       if (this.tickCount > 800)
/*     */       {
/*  71 */         this.field_145850_b.func_175698_g(func_174877_v());
/*     */       }
/*  73 */       else if (this.tickCount > 40)
/*     */       {
/*  75 */         if (this.tickCount % 3 == 0)
/*     */         {
/*  77 */           float f0 = this.tickCount - 40;
/*  78 */           double flameSize = getSigmoid(f0, 0.03125F) * 20.0D * 2.0D;
/*  79 */           double blastSize = getLinear(f0);
/*  80 */           doExplosion(flameSize, blastSize);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */     this.tickCount += 1;
/*     */   }
/*     */   
/*     */   private void doExplosion(double flameSize, double blastSize)
/*     */   {
/*  96 */     int x = func_174877_v().func_177958_n();
/*  97 */     int y = func_174877_v().func_177956_o();
/*  98 */     int z = func_174877_v().func_177952_p();
/*  99 */     double tileX = x + 0.5D;
/* 100 */     double tileY = y + 0.5D;
/* 101 */     double tileZ = z + 0.5D;
/*     */     
/* 103 */     if (blastSize > 128.0D)
/*     */     {
/* 105 */       blastSize = 128.0D;
/*     */     }
/*     */     
/* 108 */     double d0 = flameSize * flameSize;
/* 109 */     double d1 = blastSize * blastSize;
/*     */     
/*     */ 
/* 112 */     if ((this.tickCount < 400) && (this.field_145850_b.func_82736_K().func_82766_b("mobGriefing")))
/*     */     {
/* 114 */       int i0 = (int)blastSize;
/* 115 */       int i1 = (int)(blastSize * 2.0D);
/* 116 */       int i2 = (int)d0;
/* 117 */       int i3 = (int)d1;
/* 118 */       int i0y = i0;
/* 119 */       int i1y = i1;
/* 120 */       if (y - i0y < 0)
/*     */       {
/* 122 */         i0y = y;
/*     */       }
/*     */       
/* 125 */       if (y - i0y + i1y >= 256)
/*     */       {
/* 127 */         i1y = 256 - y + i0y;
/*     */       }
/*     */       
/* 130 */       for (int i = 0; i < i1; i++)
/*     */       {
/* 132 */         for (int j = 0; j < i1y; j++)
/*     */         {
/* 134 */           for (int k = 0; k < i1; k++)
/*     */           {
/* 136 */             int x0 = i - i0;
/* 137 */             int y0 = j - i0y;
/* 138 */             int z0 = k - i0;
/* 139 */             int i4 = x0 * x0 + y0 * y0 + z0 * z0;
/* 140 */             int flag = 0;
/* 141 */             if (i4 <= i2)
/*     */             {
/* 143 */               flag = 1;
/*     */             }
/* 145 */             else if (i4 <= i3)
/*     */             {
/* 147 */               flag = 2;
/*     */             }
/*     */             
/* 150 */             if (flag > 0)
/*     */             {
/* 152 */               int x1 = x0 + x;
/* 153 */               int y1 = y0 + y;
/* 154 */               int z1 = z0 + z;
/* 155 */               if (isChunksExist(x1, y1, z1))
/*     */               {
/* 157 */                 IBlockState state = BlockUtil.getBlockState(func_145831_w(), x1, y1, z1);
/* 158 */                 Block block = state.func_177230_c();
/* 159 */                 if (block != Blocks.field_150350_a)
/*     */                 {
/*     */ 
/*     */ 
/*     */ 
/* 164 */                   float hardness = state.func_185887_b(this.field_145850_b, func_174877_v());
/* 165 */                   if (flag == 1)
/*     */                   {
/* 167 */                     if ((hardness >= 0.0F) && (hardness < 500.0F))
/*     */                     {
/* 169 */                       setBlock(x1, y1, z1, Blocks.field_150350_a);
/*     */                     }
/*     */                     
/*     */ 
/*     */                   }
/* 174 */                   else if ((hardness >= 0.0F) && (hardness < 0.5F))
/*     */                   {
/* 176 */                     if (block != Blocks.field_150480_ab)
/*     */                     {
/* 178 */                       setBlock(x1, y1, z1, Blocks.field_150350_a);
/* 179 */                       if ((state.func_185904_a() == Material.field_151585_k) || (state.func_185904_a() == Material.field_151584_j))
/*     */                       {
/* 181 */                         setBlock(x1, y1, z1, Blocks.field_150480_ab);
/*     */                       }
/*     */                     }
/*     */                   }
/* 185 */                   else if ((block == Blocks.field_150349_c) || (block == Blocks.field_150458_ak) || (block == Blocks.field_150391_bh))
/*     */                   {
/* 187 */                     setBlock(x1, y1, z1, Blocks.field_150346_d);
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 198 */     double time = (800 - this.tickCount) / 760.0D;
/* 199 */     List list = this.field_145850_b.func_72839_b(null, getAABB(tileX, tileY, tileZ, blastSize));
/*     */     
/* 201 */     Iterator iterator = list.iterator();
/* 202 */     while (iterator.hasNext())
/*     */     {
/* 204 */       Entity entity = (Entity)iterator.next();
/* 205 */       double distanceSq = entity.func_70092_e(tileX, tileY, tileZ);
/* 206 */       if (distanceSq < d1)
/*     */       {
/* 208 */         double dx = entity.field_70165_t - tileX;
/* 209 */         double dy = entity.field_70163_u + entity.func_70047_e() - tileY;
/* 210 */         double dz = entity.field_70161_v - tileZ;
/* 211 */         Vec3 vec3 = new Vec3(dx, dy, dz);
/* 212 */         double density = NGTMath.pow(0.5D, getBlockDensity(tileX, tileY, tileZ, vec3));
/* 213 */         double distance = Math.sqrt(distanceSq);
/* 214 */         double d4 = 1.0D - distance / 128.0D;
/* 215 */         double d5 = time * density * d4;
/* 216 */         double acceleration = d5 / distance * 2.5D;
/* 217 */         float damage = (float)d5 * 10.0F;
/*     */         
/* 219 */         if (damage >= 0.25F)
/*     */         {
/* 221 */           if (distanceSq < d0)
/*     */           {
/* 223 */             entity.func_70097_a(DamageSource.field_76372_a, damage * 2.0F);
/* 224 */             entity.func_70015_d(5);
/*     */           }
/*     */           else
/*     */           {
/* 228 */             entity.func_70097_a(nuclearDamage, damage);
/*     */           }
/*     */         }
/*     */         
/* 232 */         if (acceleration > 0.0D)
/*     */         {
/* 234 */           if ((!(entity instanceof EntityPlayer)) || 
/*     */           
/* 236 */             (!((EntityPlayer)entity).field_71075_bZ.field_75100_b))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 242 */             entity.field_70133_I = true;
/* 243 */             entity.field_70159_w += dx * acceleration;
/* 244 */             entity.field_70181_x += dy * acceleration * 1.2000000476837158D;
/* 245 */             entity.field_70179_y += dz * acceleration;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public double getSigmoid(float x, float a) {
/* 253 */     return (1.0D / (1.0D + Math.pow(2.718281828459045D, -x * a)) - 0.5D) * 2.0D;
/*     */   }
/*     */   
/*     */   public double getLinear(float x)
/*     */   {
/* 258 */     return x * 0.015625F * 20.0F * 2.0F;
/*     */   }
/*     */   
/*     */   private AxisAlignedBB getAABB(double x, double y, double z, double size)
/*     */   {
/* 263 */     double minY = y - size;
/* 264 */     double maxY = y + size;
/*     */     
/* 266 */     if (minY < 0.0D)
/*     */     {
/* 268 */       minY = 0.0D;
/*     */     }
/*     */     
/* 271 */     if (maxY > 256.0D)
/*     */     {
/* 273 */       maxY = 256.0D;
/*     */     }
/*     */     
/* 276 */     return new AxisAlignedBB(x - size, minY, z - size, x + size, maxY, z + size);
/*     */   }
/*     */   
/*     */   private boolean isChunksExist(int x, int y, int z)
/*     */   {
/* 281 */     if ((y >= 0) && (y < 256))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 288 */       return func_145831_w().func_175667_e(new BlockPos(x, y, z));
/*     */     }
/*     */     
/*     */ 
/* 292 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   private int getBlockDensity(double posX, double posY, double posZ, Vec3 par2)
/*     */   {
/* 298 */     Vec3 vec3 = par2.normalize();
/* 299 */     double x0 = vec3.getX();
/* 300 */     double y0 = vec3.getY();
/* 301 */     double z0 = vec3.getZ();
/* 302 */     int i0 = 0;
/*     */     
/* 304 */     while (vec3.length() < par2.length())
/*     */     {
/* 306 */       int x = NGTMath.floor(posX + vec3.getX());
/* 307 */       int y = NGTMath.floor(posY + vec3.getY());
/* 308 */       int z = NGTMath.floor(posZ + vec3.getZ());
/* 309 */       BlockPos pos = new BlockPos(x, y, z);
/* 310 */       IBlockState state = this.field_145850_b.func_180495_p(pos);
/* 311 */       Block block = state.func_177230_c();
/* 312 */       if ((block.func_185496_a(state, func_145831_w(), pos) != null) && (block.func_176209_a(state, false)))
/*     */       {
/* 314 */         i0++;
/*     */       }
/*     */       
/* 317 */       vec3 = vec3.addVec(x0, y0, z0);
/*     */     }
/*     */     
/* 320 */     return i0;
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean setBlock(int x, int y, int z, Block block)
/*     */   {
/* 326 */     return BlockUtil.setBlock(func_145831_w(), x, y, z, block, 0, 2);
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public double func_145833_n()
/*     */   {
/* 333 */     return Double.POSITIVE_INFINITY;
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public AxisAlignedBB getRenderBoundingBox()
/*     */   {
/* 340 */     return INFINITE_EXTENT_AABB;
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */