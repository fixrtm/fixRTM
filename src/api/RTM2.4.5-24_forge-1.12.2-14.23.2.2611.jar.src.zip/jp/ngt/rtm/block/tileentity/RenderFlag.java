/*     */ package jp.ngt.rtm.block.tileentity;
/*     */ 
/*     */ import jp.ngt.ngtlib.math.NGTMath;
/*     */ import jp.ngt.ngtlib.renderer.NGTRenderer;
/*     */ import jp.ngt.ngtlib.renderer.NGTTessellator;
/*     */ import jp.ngt.rtm.modelpack.cfg.FlagConfig;
/*     */ import jp.ngt.rtm.modelpack.modelset.TextureSetFlag;
/*     */ import jp.ngt.rtm.modelpack.state.ResourceState;
/*     */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class RenderFlag extends TileEntitySpecialRenderer<TileEntityFlag>
/*     */ {
/*  18 */   private static ResourceLocation TEXTURE = new ResourceLocation("minecraft", "textures/ornament/iron.png");
/*     */   
/*     */   private void renderFlag(TileEntityFlag tileEntity, double par2, double par4, double par6, float par8)
/*     */   {
/*  22 */     GL11.glPushMatrix();
/*  23 */     GL11.glEnable(32826);
/*  24 */     GL11.glDisable(2884);
/*  25 */     GL11.glTranslatef((float)par2 + 0.5F, (float)par4 + 0.0F, (float)par6 + 0.5F);
/*     */     
/*  27 */     TextureSetFlag set = (TextureSetFlag)tileEntity.getResourceState().getResourceSet();
/*     */     
/*  29 */     renderPole(set);
/*     */     
/*  31 */     GL11.glTranslatef(0.0F, ((FlagConfig)set.getConfig()).poleLength, 0.0F);
/*  32 */     float yaw = tileEntity.getRotation();
/*  33 */     GL11.glRotatef(yaw, 0.0F, 1.0F, 0.0F);
/*     */     
/*  35 */     float wind = 1.0F;
/*  36 */     float windInv = 1.0F - wind;
/*  37 */     float h = ((FlagConfig)set.getConfig()).height;
/*  38 */     float w = ((FlagConfig)set.getConfig()).width;
/*     */     
/*  40 */     GL11.glShadeModel(7425);
/*  41 */     func_147499_a(set.texture);
/*  42 */     NGTTessellator tessellator = NGTTessellator.instance;
/*  43 */     tessellator.startDrawingQuads();
/*  44 */     int resV = ((FlagConfig)set.getConfig()).resolutionV;
/*  45 */     int resU = ((FlagConfig)set.getConfig()).resolutionU;
/*  46 */     for (int i = 0; i < resV; i++)
/*     */     {
/*  48 */       float v0 = i / resV;
/*  49 */       float v1 = (i + 1) / resV;
/*     */       
/*  51 */       for (int j = 0; j < resU; j++)
/*     */       {
/*  53 */         float u0 = j / resU;
/*  54 */         float u1 = (j + 1) / resU;
/*  55 */         float u0w = u0 * w;
/*  56 */         float u1w = u1 * w;
/*     */         
/*  58 */         float r0 = getR(tileEntity.wave, u1, v0);
/*  59 */         float d0 = getWave(r0, u1);
/*  60 */         float nr0 = getNormalR(r0 + yaw);
/*  61 */         tessellator.setNormal(NGTMath.getSin(nr0), 0.0F, NGTMath.getCos(nr0));
/*  62 */         tessellator.addVertexWithUV(d0, -(v0 + windInv * u1w) * h, u1w * wind, u1, v0);
/*     */         
/*  64 */         float r1 = getR(tileEntity.wave, u1, v1);
/*  65 */         float d1 = getWave(r1, u1);
/*  66 */         float nr1 = getNormalR(r1 + yaw);
/*  67 */         tessellator.setNormal(NGTMath.getSin(nr1), 0.0F, NGTMath.getCos(nr1));
/*  68 */         tessellator.addVertexWithUV(d1, -(v1 + windInv * u1w) * h, u1w * wind, u1, v1);
/*     */         
/*  70 */         float r2 = getR(tileEntity.wave, u0, v1);
/*  71 */         float d2 = getWave(r2, u0);
/*  72 */         float nr2 = getNormalR(r2 + yaw);
/*  73 */         tessellator.setNormal(NGTMath.getSin(nr2), 0.0F, NGTMath.getCos(nr2));
/*  74 */         tessellator.addVertexWithUV(d2, -(v1 + windInv * u0w) * h, u0w * wind, u0, v1);
/*     */         
/*  76 */         float r3 = getR(tileEntity.wave, u0, v0);
/*  77 */         float d3 = getWave(r3, u0);
/*  78 */         float nr3 = getNormalR(r3 + yaw);
/*  79 */         tessellator.setNormal(NGTMath.getSin(nr3), 0.0F, NGTMath.getCos(nr3));
/*  80 */         tessellator.addVertexWithUV(d3, -(v0 + windInv * u0w) * h, u0w * wind, u0, v0);
/*     */       }
/*     */     }
/*  83 */     tessellator.draw();
/*  84 */     GL11.glShadeModel(7424);
/*  85 */     GL11.glEnable(2884);
/*     */     
/*  87 */     GL11.glPopMatrix();
/*     */   }
/*     */   
/*     */   private void renderPole(TextureSetFlag set)
/*     */   {
/*  92 */     NGTTessellator tessellator = NGTTessellator.instance;
/*  93 */     func_147499_a(TEXTURE);
/*  94 */     tessellator.startDrawingQuads();
/*  95 */     NGTRenderer.renderPole(tessellator, 0.0625F, ((FlagConfig)set.getConfig()).poleLength, true);
/*  96 */     tessellator.draw();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private float getR(float r, float u, float v)
/*     */   {
/* 104 */     return -NGTMath.toRadians(r + 360.0F / (3.0F * u + 1.0F) * (v + 1.0F));
/*     */   }
/*     */   
/*     */ 
/*     */   private float getWave(float r, float u)
/*     */   {
/* 110 */     return NGTMath.getSin(r) * u * 0.15F;
/*     */   }
/*     */   
/*     */ 
/*     */   private float getNormalR(float r)
/*     */   {
/* 116 */     return NGTMath.toRadians(45.0F * NGTMath.getCos(r) + 90.0F);
/*     */   }
/*     */   
/*     */ 
/*     */   public void render(TileEntityFlag par1, double par2, double par4, double par6, float par8, int par9, float alpha)
/*     */   {
/* 122 */     renderFlag(par1, par2, par4, par6, par8);
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/RenderFlag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */