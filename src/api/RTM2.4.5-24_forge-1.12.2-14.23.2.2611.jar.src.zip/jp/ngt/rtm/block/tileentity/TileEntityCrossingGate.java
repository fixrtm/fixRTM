/*     */ package jp.ngt.rtm.block.tileentity;
/*     */ 
/*     */ import jp.ngt.rtm.RTMResource;
/*     */ import jp.ngt.rtm.modelpack.ResourceType;
/*     */ import jp.ngt.rtm.modelpack.modelset.ModelSetMachine;
/*     */ import jp.ngt.rtm.modelpack.state.ResourceState;
/*     */ import jp.ngt.rtm.sound.SoundPlayer;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class TileEntityCrossingGate extends TileEntityMachineBase
/*     */ {
/*  15 */   public int barMoveCount = 0;
/*     */   
/*  17 */   public int lightCount = -1;
/*     */   
/*     */   private int tickCountOnActive;
/*  20 */   private SoundPlayer soundPlayer = SoundPlayer.create();
/*     */   
/*     */ 
/*     */   public void func_73660_a()
/*     */   {
/*  25 */     super.func_73660_a();
/*     */     
/*  27 */     if (this.field_145850_b.func_175687_A(func_174877_v()) > 0)
/*     */     {
/*  29 */       if (this.barMoveCount < 90)
/*     */       {
/*  31 */         this.barMoveCount += 1;
/*     */       }
/*     */       
/*  34 */       if (this.tickCountOnActive < 360)
/*     */       {
/*  36 */         this.tickCountOnActive += 1;
/*     */       }
/*     */       else
/*     */       {
/*  40 */         this.tickCountOnActive = 0;
/*     */       }
/*     */       
/*  43 */       if (this.tickCountOnActive % 10 == 0)
/*     */       {
/*  45 */         this.lightCount = (this.lightCount <= 0 ? 1 : 0);
/*     */       }
/*     */       
/*  48 */       if (this.field_145850_b.field_72995_K)
/*     */       {
/*  50 */         ModelSetMachine set = (ModelSetMachine)getResourceState().getResourceSet();
/*  51 */         if ((!this.soundPlayer.isPlaying()) && (set.sound_Running != null))
/*     */         {
/*  53 */           this.soundPlayer.playSound(this, set.sound_Running, true);
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*  59 */       if (this.barMoveCount > 0)
/*     */       {
/*  61 */         this.barMoveCount -= 1;
/*     */       }
/*     */       
/*  64 */       this.tickCountOnActive = 0;
/*  65 */       this.lightCount = -1;
/*     */       
/*  67 */       if (this.field_145850_b.field_72995_K)
/*     */       {
/*  69 */         if (this.soundPlayer.isPlaying())
/*     */         {
/*  71 */           this.soundPlayer.stopSound();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void onActivate() {}
/*     */   
/*     */ 
/*     */   public void updateResourceState()
/*     */   {
/*  83 */     super.updateResourceState();
/*     */     
/*  85 */     if ((this.field_145850_b != null) && (this.field_145850_b.field_72995_K))
/*     */     {
/*  87 */       if (this.soundPlayer.isPlaying())
/*     */       {
/*  89 */         this.soundPlayer.stopSound();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*     */   public AxisAlignedBB getRenderBoundingBox()
/*     */   {
/*  98 */     BlockPos pos = func_174877_v();
/*  99 */     AxisAlignedBB bb = new AxisAlignedBB(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p(), pos.func_177958_n() + 1, pos.func_177956_o() + 4, pos.func_177952_p() + 1);
/* 100 */     return bb;
/*     */   }
/*     */   
/*     */ 
/*     */   protected ResourceType getSubType()
/*     */   {
/* 106 */     return RTMResource.MACHINE_GATE;
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityCrossingGate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */