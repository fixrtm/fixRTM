/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.rtm.modelpack.cfg.MachineConfig;
/*    */ import jp.ngt.rtm.modelpack.modelset.ModelSetMachine;
/*    */ import jp.ngt.rtm.modelpack.state.ResourceState;
/*    */ import jp.ngt.rtm.render.ModelObject;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraftforge.client.MinecraftForgeClient;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class RenderMachine extends TileEntitySpecialRenderer<TileEntityMachineBase>
/*    */ {
/* 16 */   public static final RenderMachine INSTANCE = new RenderMachine();
/*    */   
/*    */ 
/*    */ 
/*    */   private void renderMachine(TileEntityMachineBase par1, double par2, double par4, double par6, float par8)
/*    */   {
/* 22 */     GL11.glPushMatrix();
/* 23 */     GL11.glEnable(32826);
/* 24 */     GL11.glTranslatef((float)par2 + 0.5F, (float)par4, (float)par6 + 0.5F);
/*    */     
/* 26 */     ModelSetMachine modelSet = (ModelSetMachine)par1.getResourceState().getResourceSet();
/* 27 */     MachineConfig cfg = (MachineConfig)modelSet.getConfig();
/* 28 */     GL11.glTranslatef(0.0F, 0.5F, 0.0F);
/* 29 */     if (cfg.rotateByMetadata)
/*    */     {
/* 31 */       switch (par1.func_145832_p()) {
/*    */       case 0: 
/* 33 */         GL11.glRotatef(180.0F, 0.0F, 0.0F, 1.0F); break;
/*    */       case 1: 
/*    */         break; case 2:  GL11.glRotatef(-90.0F, 1.0F, 0.0F, 0.0F); break;
/* 36 */       case 3:  GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F); break;
/* 37 */       case 4:  GL11.glRotatef(90.0F, 0.0F, 0.0F, 1.0F); break;
/* 38 */       case 5:  GL11.glRotatef(-90.0F, 0.0F, 0.0F, 1.0F);
/*    */       }
/*    */     }
/* 41 */     GL11.glTranslatef(0.0F, -0.5F, 0.0F);
/* 42 */     float yaw = par1.getRotation();
/* 43 */     if ((cfg.rotateByMetadata) && (par1.func_145832_p() == 0))
/*    */     {
/* 45 */       yaw = -yaw;
/*    */     }
/* 47 */     GL11.glRotatef(yaw, 0.0F, 1.0F, 0.0F);
/* 48 */     int pass = MinecraftForgeClient.getRenderPass();
/* 49 */     modelSet.modelObj.render(par1, cfg, pass, par8);
/*    */     
/* 51 */     GL11.glPopMatrix();
/*    */   }
/*    */   
/*    */ 
/*    */   public void render(TileEntityMachineBase tileEntity, double par2, double par4, double par6, float par8, int par9, float alpha)
/*    */   {
/* 57 */     renderMachine(tileEntity, par2, par4, par6, par8);
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/RenderMachine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */