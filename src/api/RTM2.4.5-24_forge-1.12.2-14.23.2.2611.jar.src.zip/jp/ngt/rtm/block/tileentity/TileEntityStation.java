/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.ngtlib.block.TileEntityCustom;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class TileEntityStation
/*    */   extends TileEntityCustom
/*    */ {
/* 12 */   public int depth = 8; public int height = 3; public int width = 8;
/*    */   private String stationName;
/*    */   
/*    */   public void func_145839_a(NBTTagCompound nbt)
/*    */   {
/* 17 */     super.func_145839_a(nbt);
/* 18 */     this.width = nbt.func_74762_e("Width");
/* 19 */     this.height = nbt.func_74762_e("Height");
/* 20 */     this.depth = nbt.func_74762_e("Depth");
/* 21 */     setName(nbt.func_74779_i("StationName"));
/*    */   }
/*    */   
/*    */ 
/*    */   public NBTTagCompound func_189515_b(NBTTagCompound nbt)
/*    */   {
/* 27 */     super.func_189515_b(nbt);
/* 28 */     nbt.func_74778_a("StationName", this.stationName);
/* 29 */     nbt.func_74768_a("Width", this.width);
/* 30 */     nbt.func_74768_a("Height", this.height);
/* 31 */     nbt.func_74768_a("Depth", this.depth);
/* 32 */     return nbt;
/*    */   }
/*    */   
/*    */   public void setData(NBTTagCompound nbt)
/*    */   {
/* 37 */     func_145839_a(nbt);
/* 38 */     sendPacket();
/* 39 */     func_70296_d();
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 44 */     return this.stationName;
/*    */   }
/*    */   
/*    */   public void setName(String par1)
/*    */   {
/* 49 */     this.stationName = par1;
/* 50 */     func_70296_d();
/* 51 */     sendPacket();
/*    */   }
/*    */   
/*    */ 
/*    */   @SideOnly(Side.CLIENT)
/*    */   public double func_145833_n()
/*    */   {
/* 58 */     return Double.POSITIVE_INFINITY;
/*    */   }
/*    */   
/*    */ 
/*    */   @SideOnly(Side.CLIENT)
/*    */   public AxisAlignedBB getRenderBoundingBox()
/*    */   {
/* 65 */     return INFINITE_EXTENT_AABB;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityStation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */