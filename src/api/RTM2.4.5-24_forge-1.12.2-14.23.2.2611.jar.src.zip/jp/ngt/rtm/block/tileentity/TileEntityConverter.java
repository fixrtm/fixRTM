/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.ngtlib.block.BlockUtil;
/*    */ import jp.ngt.ngtlib.block.TileEntityCustom;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.ITickable;
/*    */ 
/*    */ public class TileEntityConverter extends TileEntityCustom implements ITickable
/*    */ {
/* 11 */   private int[] corePos = { 0, 0, 0 };
/*    */   
/*    */   private TileEntityConverterCore core;
/*    */   
/*    */   public void func_145839_a(NBTTagCompound nbt)
/*    */   {
/* 17 */     super.func_145839_a(nbt);
/* 18 */     this.corePos = nbt.func_74759_k("core");
/*    */   }
/*    */   
/*    */ 
/*    */   public NBTTagCompound func_189515_b(NBTTagCompound nbt)
/*    */   {
/* 24 */     super.func_189515_b(nbt);
/* 25 */     nbt.func_74783_a("core", this.corePos);
/* 26 */     return nbt;
/*    */   }
/*    */   
/*    */ 
/*    */   public void func_73660_a()
/*    */   {
/* 32 */     if (getCore() != null)
/*    */     {
/* 34 */       if (this.field_145850_b.func_175687_A(func_174877_v()) > 0)
/*    */       {
/* 36 */         this.core.powered = true;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public TileEntityConverterCore getCore()
/*    */   {
/* 44 */     if (this.core == null)
/*    */     {
/* 46 */       TileEntity tile = BlockUtil.getTileEntity(func_145831_w(), this.corePos[0], this.corePos[1], this.corePos[2]);
/* 47 */       if ((tile instanceof TileEntityConverterCore))
/*    */       {
/* 49 */         this.core = ((TileEntityConverterCore)tile);
/*    */       }
/*    */     }
/* 52 */     return this.core;
/*    */   }
/*    */   
/*    */   public void setCorePos(int x, int y, int z)
/*    */   {
/* 57 */     this.corePos = new int[] { x, y, z };
/*    */   }
/*    */   
/*    */ 
/*    */   public void setPos(int x, int y, int z, int prevX, int prevY, int prevZ)
/*    */   {
/* 63 */     super.setPos(x, y, z, prevX, prevY, prevZ);
/* 64 */     this.corePos[0] += prevX - x;
/* 65 */     this.corePos[1] += prevY - y;
/* 66 */     this.corePos[2] += prevZ - z;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */