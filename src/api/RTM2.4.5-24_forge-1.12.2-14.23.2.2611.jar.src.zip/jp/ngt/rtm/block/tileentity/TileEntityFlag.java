/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import java.util.Random;
/*    */ import jp.ngt.ngtlib.block.TileEntityPlaceable;
/*    */ import jp.ngt.rtm.RTMResource;
/*    */ import jp.ngt.rtm.modelpack.IResourceSelector;
/*    */ import jp.ngt.rtm.modelpack.modelset.TextureSetFlag;
/*    */ import jp.ngt.rtm.modelpack.state.ResourceState;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.util.ITickable;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class TileEntityFlag extends TileEntityPlaceable implements IResourceSelector, ITickable
/*    */ {
/* 18 */   private ResourceState<TextureSetFlag> state = new ResourceState(RTMResource.FLAG);
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public int tick;
/*    */   @SideOnly(Side.CLIENT)
/*    */   public float wave;
/*    */   
/*    */   public TileEntityFlag()
/*    */   {
/* 27 */     if (!jp.ngt.ngtlib.util.NGTUtil.isServer())
/*    */     {
/*    */ 
/* 30 */       this.wave = jp.ngt.ngtlib.math.NGTMath.RANDOM.nextInt(360);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void func_145839_a(NBTTagCompound nbt)
/*    */   {
/* 37 */     super.func_145839_a(nbt);
/* 38 */     this.state.readFromNBT(nbt.func_74775_l("State"));
/*    */     
/* 40 */     if (this.state.version < 1)
/*    */     {
/* 42 */       getResourceState().setResourceName(nbt.func_74779_i("TextureName"));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public NBTTagCompound func_189515_b(NBTTagCompound nbt)
/*    */   {
/* 49 */     super.func_189515_b(nbt);
/* 50 */     nbt.func_74782_a("State", this.state.writeToNBT());
/* 51 */     return nbt;
/*    */   }
/*    */   
/*    */ 
/*    */   public void func_73660_a()
/*    */   {
/* 57 */     if (this.field_145850_b.field_72995_K)
/*    */     {
/* 59 */       this.wave += 10.0F;
/* 60 */       if (this.wave >= 360.0F)
/*    */       {
/* 62 */         this.wave = 0.0F;
/*    */       }
/*    */       
/* 65 */       this.tick += 1;
/* 66 */       if (this.tick >= 36000)
/*    */       {
/* 68 */         this.tick = 0;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void updateResourceState()
/*    */   {
/* 76 */     if ((this.field_145850_b == null) || (!this.field_145850_b.field_72995_K))
/*    */     {
/* 78 */       sendPacket();
/* 79 */       func_70296_d();
/* 80 */       jp.ngt.ngtlib.block.BlockUtil.markBlockForUpdate(func_145831_w(), func_174877_v());
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public ResourceState<TextureSetFlag> getResourceState()
/*    */   {
/* 87 */     return this.state;
/*    */   }
/*    */   
/*    */ 
/*    */   public int[] getSelectorPos()
/*    */   {
/* 93 */     return new int[] { this.field_174879_c.func_177958_n(), this.field_174879_c.func_177956_o(), this.field_174879_c.func_177952_p() };
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean closeGui(ResourceState par1)
/*    */   {
/* 99 */     return true;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityFlag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */