/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.ngtlib.block.BlockUtil;
/*    */ import jp.ngt.rtm.RTMBlock;
/*    */ import jp.ngt.rtm.RTMResource;
/*    */ import jp.ngt.rtm.modelpack.ResourceType;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ public class TileEntityPipe extends TileEntityOrnament
/*    */ {
/* 14 */   public byte[] connection = new byte[6];
/*    */   
/*    */ 
/*    */   public void func_145839_a(NBTTagCompound nbt)
/*    */   {
/* 19 */     super.func_145839_a(nbt);
/*    */     
/*    */ 
/* 22 */     this.connection = nbt.func_74770_j("connection");
/* 23 */     if (this.connection.length < 6)
/*    */     {
/* 25 */       this.connection = new byte[6];
/*    */     }
/* 27 */     searchConnection();
/*    */   }
/*    */   
/*    */ 
/*    */   public NBTTagCompound func_189515_b(NBTTagCompound nbt)
/*    */   {
/* 33 */     super.func_189515_b(nbt);
/* 34 */     nbt.func_74773_a("connection", this.connection);
/* 35 */     return nbt;
/*    */   }
/*    */   
/*    */ 
/*    */   public void refresh()
/*    */   {
/* 41 */     searchConnection();
/* 42 */     sendPacket();
/* 43 */     func_70296_d();
/*    */   }
/*    */   
/*    */   public void searchConnection()
/*    */   {
/* 48 */     if (func_145831_w() == null) { return;
/*    */     }
/* 50 */     for (int i = 0; i < 6; i++)
/*    */     {
/* 52 */       int x0 = func_174877_v().func_177958_n() + BlockUtil.facing[i][0];
/* 53 */       int y0 = func_174877_v().func_177956_o() + BlockUtil.facing[i][1];
/* 54 */       int z0 = func_174877_v().func_177952_p() + BlockUtil.facing[i][2];
/* 55 */       IBlockState state = BlockUtil.getBlockState(func_145831_w(), x0, y0, z0);
/* 56 */       Block block = state.func_177230_c();
/* 57 */       if (block == RTMBlock.slot)
/*    */       {
/* 59 */         this.connection[i] = 3;
/*    */       }
/* 61 */       else if (block == RTMBlock.pipe)
/*    */       {
/* 63 */         this.connection[i] = 2;
/*    */       }
/* 65 */       else if (state.func_185914_p())
/*    */       {
/* 67 */         this.connection[i] = 1;
/*    */       }
/*    */       else
/*    */       {
/* 71 */         this.connection[i] = 0;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isConnected(byte side)
/*    */   {
/* 78 */     return (this.connection[side] == 2) || (this.connection[side] == 3);
/*    */   }
/*    */   
/*    */ 
/*    */   protected ResourceType getSubType()
/*    */   {
/* 84 */     return RTMResource.ORNAMENT_PIPE;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityPipe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */