/*     */ package jp.ngt.rtm.block.tileentity;
/*     */ 
/*     */ import jp.ngt.ngtlib.renderer.NGTTessellator;
/*     */ import jp.ngt.rtm.modelpack.cfg.SignboardConfig;
/*     */ import jp.ngt.rtm.modelpack.modelset.TextureSetSignboard;
/*     */ import jp.ngt.rtm.modelpack.state.ResourceStateSignboard;
/*     */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class RenderSignBoard
/*     */   extends TileEntitySpecialRenderer<TileEntitySignBoard>
/*     */ {
/*     */   public void renderSignBoardAt(TileEntitySignBoard tileEntity, double par2, double par4, double par6, float par8)
/*     */   {
/*  18 */     GL11.glPushMatrix();
/*  19 */     GL11.glEnable(32826);
/*  20 */     GL11.glTranslatef((float)par2 + 0.5F, (float)par4 + 0.5F, (float)par6 + 0.5F);
/*     */     
/*  22 */     TextureSetSignboard set = (TextureSetSignboard)tileEntity.getResourceState().getResourceSet();
/*  23 */     SignboardConfig cfg = (SignboardConfig)set.getConfig();
/*  24 */     float height = cfg.height / 2.0F;
/*  25 */     float width = cfg.width / 2.0F;
/*  26 */     float depth = cfg.depth / 2.0F;
/*  27 */     int meta = tileEntity.func_145832_p();
/*  28 */     byte dir = tileEntity.getDirection();
/*  29 */     float minV = 0.0F;
/*  30 */     float maxV = 1.0F;
/*  31 */     if (cfg.frame > 1)
/*     */     {
/*  33 */       minV = tileEntity.counter / cfg.animationCycle / cfg.frame;
/*  34 */       maxV = (tileEntity.counter / cfg.animationCycle + 1) / cfg.frame;
/*     */     }
/*     */     
/*  37 */     GL11.glRotatef(dir * -90.0F, 0.0F, 1.0F, 0.0F);
/*     */     
/*  39 */     if (meta == 0)
/*     */     {
/*  41 */       GL11.glTranslatef(0.0F, 0.5F - height, 0.0F);
/*     */     }
/*  43 */     else if (meta == 1)
/*     */     {
/*  45 */       GL11.glTranslatef(0.0F, height - 0.5F, 0.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*  50 */     else if (((dir == 1) && (meta == 4)) || ((dir == 3) && (meta == 5)))
/*     */     {
/*     */ 
/*  53 */       GL11.glTranslatef(0.0F, 0.0F, depth - 0.5F);
/*     */     }
/*  55 */     else if (((dir == 0) && (meta == 3)) || ((dir == 2) && (meta == 2)))
/*     */     {
/*  57 */       GL11.glTranslatef(0.0F, 0.0F, depth - 0.5F);
/*     */     }
/*  59 */     else if (((dir == 1) && (meta == 3)) || ((dir == 3) && (meta == 2)))
/*     */     {
/*     */ 
/*  62 */       GL11.glTranslatef(width - 0.5F, 0.0F, 0.0F);
/*     */     }
/*  64 */     else if (((dir == 0) && (meta == 4)) || ((dir == 2) && (meta == 5)))
/*     */     {
/*     */ 
/*  67 */       GL11.glTranslatef(0.5F - width, 0.0F, 0.0F);
/*     */     }
/*  69 */     else if (((dir == 0) && (meta == 5)) || ((dir == 2) && (meta == 4)))
/*     */     {
/*     */ 
/*  72 */       GL11.glTranslatef(width - 0.5F, 0.0F, 0.0F);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*  77 */       GL11.glTranslatef(0.5F - width, 0.0F, 0.0F);
/*     */     }
/*     */     
/*     */ 
/*  81 */     GL11.glDisable(2896);
/*  82 */     NGTTessellator tessellator = NGTTessellator.instance;
/*  83 */     func_147499_a(set.texture);
/*  84 */     float u0 = cfg.backTexture == 1 ? 0.5F : 1.0F;
/*  85 */     float u1 = cfg.backTexture == 1 ? 0.5F : 0.0F;
/*  86 */     tessellator.startDrawingQuads();
/*     */     
/*  88 */     tessellator.addVertexWithUV(width, -height, depth, u0, maxV);
/*  89 */     tessellator.addVertexWithUV(width, height, depth, u0, minV);
/*  90 */     tessellator.addVertexWithUV(-width, height, depth, 0.0F, minV);
/*  91 */     tessellator.addVertexWithUV(-width, -height, depth, 0.0F, maxV);
/*     */     
/*  93 */     int color = cfg.color;
/*  94 */     boolean flag1 = false;
/*  95 */     if (cfg.backTexture == 2)
/*     */     {
/*  97 */       tessellator.draw();
/*  98 */       flag1 = true;
/*  99 */       GL11.glDisable(3553);
/* 100 */       tessellator.startDrawingQuads();
/* 101 */       tessellator.setColorRGBA_I(color, 255);
/*     */     }
/*     */     
/*     */ 
/* 105 */     tessellator.addVertexWithUV(-width, -height, -depth, 1.0F, maxV);
/* 106 */     tessellator.addVertexWithUV(-width, height, -depth, 1.0F, minV);
/* 107 */     tessellator.addVertexWithUV(width, height, -depth, u1, minV);
/* 108 */     tessellator.addVertexWithUV(width, -height, -depth, u1, maxV);
/* 109 */     tessellator.draw();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 118 */     color -= 1052688;
/* 119 */     if (color < 0)
/*     */     {
/* 121 */       color = 0;
/*     */     }
/* 123 */     GL11.glDisable(3553);
/* 124 */     tessellator.startDrawingQuads();
/* 125 */     tessellator.setColorRGBA_I(color, 255);
/*     */     
/* 127 */     tessellator.addVertex(width, height, depth);
/* 128 */     tessellator.addVertex(width, height, -depth);
/* 129 */     tessellator.addVertex(-width, height, -depth);
/* 130 */     tessellator.addVertex(-width, height, depth);
/*     */     
/* 132 */     tessellator.addVertex(-width, -height, depth);
/* 133 */     tessellator.addVertex(-width, -height, -depth);
/* 134 */     tessellator.addVertex(width, -height, -depth);
/* 135 */     tessellator.addVertex(width, -height, depth);
/*     */     
/* 137 */     tessellator.addVertex(width, -height, -depth);
/* 138 */     tessellator.addVertex(width, height, -depth);
/* 139 */     tessellator.addVertex(width, height, depth);
/* 140 */     tessellator.addVertex(width, -height, depth);
/*     */     
/* 142 */     tessellator.addVertex(-width, -height, depth);
/* 143 */     tessellator.addVertex(-width, height, depth);
/* 144 */     tessellator.addVertex(-width, height, -depth);
/* 145 */     tessellator.addVertex(-width, -height, -depth);
/*     */     
/* 147 */     tessellator.draw();
/* 148 */     GL11.glEnable(2896);
/* 149 */     GL11.glEnable(3553);
/*     */     
/* 151 */     GL11.glEnable(3042);
/* 152 */     GL11.glBlendFunc(770, 771);
/* 153 */     GL11.glScalef(1.0F, -1.0F, 1.0F);
/* 154 */     for (SignboardText text : tileEntity.getResourceState().texts)
/*     */     {
/* 156 */       if ((cfg.backTexture != 1) || (text.posU < width))
/*     */       {
/*     */ 
/* 159 */         text.render(text.posU - width, text.posV - height, depth + 0.01F, 1.0F);
/*     */       }
/*     */       
/* 162 */       if ((cfg.backTexture == 0) || ((cfg.backTexture == 1) && (text.posU >= width)))
/*     */       {
/*     */ 
/* 165 */         GL11.glPushMatrix();
/* 166 */         GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
/* 167 */         float x = text.posU - width;
/* 168 */         if (cfg.backTexture == 1)
/*     */         {
/* 170 */           x -= cfg.width;
/*     */         }
/* 172 */         text.render(x, text.posV - height, depth + 0.01F, 1.0F);
/* 173 */         GL11.glPopMatrix();
/*     */       }
/*     */     }
/* 176 */     GL11.glDisable(3042);
/*     */     
/* 178 */     GL11.glPopMatrix();
/*     */   }
/*     */   
/*     */ 
/*     */   public void render(TileEntitySignBoard tileEntity, double par2, double par4, double par6, float par8, int par9, float alpha)
/*     */   {
/* 184 */     renderSignBoardAt(tileEntity, par2, par4, par6, par8);
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/RenderSignBoard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */