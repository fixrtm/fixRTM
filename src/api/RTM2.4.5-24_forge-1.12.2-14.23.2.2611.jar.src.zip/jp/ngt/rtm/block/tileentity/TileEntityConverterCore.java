/*     */ package jp.ngt.rtm.block.tileentity;
/*     */ 
/*     */ import java.util.Random;
/*     */ import jp.ngt.ngtlib.block.BlockLiquidBase;
/*     */ import jp.ngt.ngtlib.block.BlockUtil;
/*     */ import jp.ngt.ngtlib.io.NGTLog;
/*     */ import jp.ngt.ngtlib.math.NGTMath;
/*     */ import jp.ngt.ngtlib.math.Vec3;
/*     */ import jp.ngt.rtm.CommonProxy;
/*     */ import jp.ngt.rtm.RTMCore;
/*     */ import jp.ngt.rtm.RTMFluid;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class TileEntityConverterCore extends TileEntityConverter
/*     */ {
/*     */   private static final int Max_Capacity = 720;
/*     */   private byte direction;
/*     */   private int capacity;
/*  24 */   private int mode = 0;
/*  25 */   private int count = 0;
/*     */   
/*  27 */   private int prevMode = 0;
/*  28 */   private float pitch = 0.0F;
/*     */   
/*  30 */   public boolean powered = false;
/*  31 */   private boolean prevPowered = false;
/*     */   
/*     */ 
/*     */   public void func_145839_a(NBTTagCompound nbt)
/*     */   {
/*  36 */     super.func_145839_a(nbt);
/*  37 */     this.direction = nbt.func_74771_c("dir");
/*  38 */     this.capacity = nbt.func_74762_e("capacity");
/*  39 */     this.mode = nbt.func_74762_e("mode");
/*  40 */     this.count = nbt.func_74762_e("count");
/*     */   }
/*     */   
/*     */ 
/*     */   public NBTTagCompound func_189515_b(NBTTagCompound nbt)
/*     */   {
/*  46 */     super.func_189515_b(nbt);
/*  47 */     nbt.func_74774_a("dir", this.direction);
/*  48 */     nbt.func_74768_a("capacity", this.capacity);
/*  49 */     nbt.func_74768_a("mode", this.mode);
/*  50 */     nbt.func_74768_a("count", this.count);
/*  51 */     return nbt;
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_73660_a()
/*     */   {
/*  57 */     int x = getX();
/*  58 */     int y = getY();
/*  59 */     int z = getZ();
/*     */     
/*  61 */     this.prevPowered = this.powered;
/*  62 */     this.powered = false;
/*     */     
/*  64 */     this.prevMode = this.mode;
/*     */     
/*  66 */     if ((!this.prevPowered) && (this.pitch == 0.0F))
/*     */     {
/*  68 */       if (BlockUtil.getBlock(func_145831_w(), x, y + 1, z) == RTMFluid.liquefiedPigIron)
/*     */       {
/*  70 */         if (this.capacity < 720)
/*     */         {
/*  72 */           int meta = BlockUtil.getMetadata(func_145831_w(), x, y + 1, z);
/*  73 */           this.capacity += meta + 1;
/*  74 */           if (this.capacity > 720)
/*     */           {
/*  76 */             this.capacity = 720;
/*     */           }
/*  78 */           BlockUtil.setAir(this.field_145850_b, x, y + 1, z);
/*     */           
/*  80 */           if (this.capacity > 540)
/*     */           {
/*  82 */             this.mode = 1;
/*     */           }
/*     */         }
/*     */       }
/*  86 */       else if (this.capacity > 0)
/*     */       {
/*  88 */         if (this.mode == 1)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  94 */           this.mode = 2;
/*     */         }
/*  96 */         else if (this.mode == 2)
/*     */         {
/*  98 */           this.count += 1;
/*     */           
/* 100 */           if (this.count > this.capacity * 16)
/*     */           {
/* 102 */             this.mode = 3;
/* 103 */             this.count = 0;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 109 */     if ((this.mode == 0) || (this.mode == 3))
/*     */     {
/* 111 */       if (this.prevPowered)
/*     */       {
/* 113 */         this.pitch += 0.5F;
/*     */       }
/*     */       else
/*     */       {
/* 117 */         this.pitch -= 0.5F;
/*     */       }
/*     */       
/* 120 */       if (this.pitch > 90.0F)
/*     */       {
/* 122 */         this.pitch = 90.0F;
/*     */       }
/*     */       
/* 125 */       if (this.pitch < 0.0F)
/*     */       {
/* 127 */         this.pitch = 0.0F;
/*     */       }
/*     */       
/* 130 */       if ((this.prevPowered) && (this.pitch > 27.0F))
/*     */       {
/* 132 */         Vec3 vec3 = new Vec3(0.0D, 2.04805D, 2.9275D);
/* 133 */         vec3 = vec3.rotateAroundX(-this.pitch);
/* 134 */         vec3 = vec3.rotateAroundY(-this.direction * 90.0F);
/*     */         
/* 136 */         if (this.mode == 3)
/*     */         {
/* 138 */           if (this.capacity > 0)
/*     */           {
/* 140 */             this.capacity -= 1;
/*     */           }
/*     */           else
/*     */           {
/* 144 */             this.mode = 0;
/*     */           }
/*     */         }
/*     */         
/* 148 */         if (this.field_145850_b.field_72995_K)
/*     */         {
/* 150 */           if ((this.mode == 3) && (this.capacity > 0))
/*     */           {
/* 152 */             for (int i = 0; i < 10; i++)
/*     */             {
/* 154 */               Random random = this.field_145850_b.field_73012_v;
/* 155 */               double x0 = x + vec3.getX() + 0.5D - 0.25D + random.nextFloat() * 0.5F;
/* 156 */               double y0 = y + vec3.getY() - 0.25D + random.nextFloat() * 0.5F;
/* 157 */               double z0 = z + vec3.getZ() + 0.5D - 0.25D + random.nextFloat() * 0.5F;
/* 158 */               RTMCore.proxy.spawnModParticle(this.field_145850_b, x0, y0, z0, 0.0D, -0.125D, 0.0D);
/*     */             }
/*     */             
/*     */           }
/*     */           
/*     */         }
/* 164 */         else if ((this.mode == 3) && (this.capacity > 0))
/*     */         {
/* 166 */           int x1 = NGTMath.floor(x + vec3.getX() + 0.5D);
/* 167 */           int y1 = NGTMath.floor(y + vec3.getY());
/* 168 */           int z1 = NGTMath.floor(z + vec3.getZ() + 0.5D);
/* 169 */           while ((BlockUtil.getBlock(func_145831_w(), x1, y1, z1) == Blocks.field_150350_a) || (BlockUtil.getBlock(func_145831_w(), x1, y1, z1) == RTMFluid.liquefiedSteel))
/*     */           {
/* 171 */             y--;
/*     */           }
/* 173 */           BlockLiquidBase.addLiquid(this.field_145850_b, x1, y1 + 1, z1, RTMFluid.liquefiedSteel, 1, true);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 179 */     if ((!this.field_145850_b.field_72995_K) && (this.mode != this.prevMode))
/*     */     {
/* 181 */       sendPacket();
/* 182 */       NGTLog.sendChatMessageToAll("message.converter.mode" + this.mode, new Object[0]);
/*     */     }
/*     */   }
/*     */   
/*     */   public float getPitch()
/*     */   {
/* 188 */     return this.pitch;
/*     */   }
/*     */   
/*     */   public int getMode()
/*     */   {
/* 193 */     return this.mode;
/*     */   }
/*     */   
/*     */   public byte getDirection()
/*     */   {
/* 198 */     return this.direction;
/*     */   }
/*     */   
/*     */   public void setDirection(byte par1)
/*     */   {
/* 203 */     this.direction = par1;
/* 204 */     sendPacket();
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public AxisAlignedBB getRenderBoundingBox()
/*     */   {
/* 211 */     int x = getX();
/* 212 */     int y = getY();
/* 213 */     int z = getZ();
/* 214 */     AxisAlignedBB bb = new AxisAlignedBB(x - 3, y - 3, z - 3, x + 4, y + 4, z + 4);
/* 215 */     return bb;
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityConverterCore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */