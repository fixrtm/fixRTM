/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.ngtlib.block.TileEntityCustom;
/*    */ import jp.ngt.rtm.block.decoration.DecorationModel;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ 
/*    */ public class TileEntityDecoration extends TileEntityCustom
/*    */ {
/*  9 */   private String modelName = DecorationModel.DEFAULT_MODEL.name;
/*    */   
/*    */ 
/*    */   public void func_145839_a(NBTTagCompound nbt)
/*    */   {
/* 14 */     super.func_145839_a(nbt);
/* 15 */     this.modelName = nbt.func_74779_i("ModelName");
/*    */   }
/*    */   
/*    */ 
/*    */   public NBTTagCompound func_189515_b(NBTTagCompound nbt)
/*    */   {
/* 21 */     super.func_189515_b(nbt);
/* 22 */     nbt.func_74778_a("ModelName", this.modelName);
/* 23 */     return nbt;
/*    */   }
/*    */   
/*    */   public void setModelName(String par1)
/*    */   {
/* 28 */     this.modelName = par1;
/* 29 */     sendPacket();
/*    */   }
/*    */   
/*    */   public String getModelName()
/*    */   {
/* 34 */     return this.modelName;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityDecoration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */