/*     */ package jp.ngt.rtm.block.tileentity;
/*     */ 
/*     */ import jp.ngt.ngtlib.block.TileEntityCustom;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class TileEntityPaint extends TileEntityCustom
/*     */ {
/*  12 */   private int[][] colors = new int[6]['Ā'];
/*  13 */   private int[][] alphas = new int[6]['Ā'];
/*  14 */   private boolean[] hasColor = new boolean[6];
/*     */   
/*     */ 
/*     */   public void func_145839_a(NBTTagCompound nbt)
/*     */   {
/*  19 */     super.func_145839_a(nbt);
/*  20 */     int[] ia = nbt.func_74759_k("Colors");
/*  21 */     if (ia.length == 1536)
/*     */     {
/*  23 */       for (int i = 0; i < 6; i++)
/*     */       {
/*  25 */         for (int j = 0; j < 256; j++)
/*     */         {
/*  27 */           this.colors[i][j] = ia[(i * 256 + j)];
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  32 */     byte[] ba = nbt.func_74770_j("Alphas");
/*  33 */     if (ba.length == 1536)
/*     */     {
/*  35 */       for (int i = 0; i < 6; i++)
/*     */       {
/*  37 */         for (int j = 0; j < 256; j++)
/*     */         {
/*  39 */           this.alphas[i][j] = (ba[(i * 256 + j)] + 128);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  44 */     byte[] ba2 = nbt.func_74770_j("HasColor");
/*  45 */     if (ba2.length == 6)
/*     */     {
/*  47 */       for (int i = 0; i < 6; i++)
/*     */       {
/*  49 */         this.hasColor[i] = (ba2[i] == 1 ? 1 : false);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public NBTTagCompound func_189515_b(NBTTagCompound nbt)
/*     */   {
/*  57 */     super.func_189515_b(nbt);
/*  58 */     int[] ia = new int['؀'];
/*  59 */     for (int i = 0; i < 6; i++)
/*     */     {
/*  61 */       for (int j = 0; j < 256; j++)
/*     */       {
/*  63 */         ia[(i * 256 + j)] = this.colors[i][j];
/*     */       }
/*     */     }
/*  66 */     nbt.func_74783_a("Colors", ia);
/*     */     
/*  68 */     byte[] ba = new byte['؀'];
/*  69 */     for (int i = 0; i < 6; i++)
/*     */     {
/*  71 */       for (int j = 0; j < 256; j++)
/*     */       {
/*  73 */         ba[(i * 256 + j)] = ((byte)(this.alphas[i][j] - 128));
/*     */       }
/*     */     }
/*  76 */     nbt.func_74773_a("Alphas", ba);
/*     */     
/*  78 */     byte[] ba2 = new byte[6];
/*  79 */     for (int i = 0; i < 6; i++)
/*     */     {
/*  81 */       ba2[i] = ((byte)(this.hasColor[i] != 0 ? 1 : 0));
/*     */     }
/*  83 */     nbt.func_74773_a("HasColor", ba2);
/*     */     
/*  85 */     return nbt;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setColor(int color, int alpha, int p1, int p2, int dir)
/*     */   {
/*  91 */     if ((p1 < 0) || (p1 >= 16) || (p2 < 0) || (p2 >= 16)) return;
/*  92 */     int index = p1 * 16 + p2;
/*  93 */     int c0 = this.colors[dir][index];
/*  94 */     int a0 = this.alphas[dir][index];
/*  95 */     int[] ca = jp.ngt.ngtlib.util.ColorUtil.alphaBlending(color, alpha, c0, a0);
/*  96 */     this.colors[dir][index] = ca[0];
/*  97 */     this.alphas[dir][index] = ca[1];
/*  98 */     this.hasColor[dir] = true;
/*     */   }
/*     */   
/*     */   public void clearColor(int p1, int p2, int dir)
/*     */   {
/* 103 */     if ((p1 < 0) || (p1 >= 16) || (p2 < 0) || (p2 >= 16)) return;
/* 104 */     int index = p1 * 16 + p2;
/* 105 */     this.colors[dir][index] = 0;
/* 106 */     this.alphas[dir][index] = 0;
/*     */   }
/*     */   
/*     */   public boolean hasColor(int dir)
/*     */   {
/* 111 */     return this.hasColor[dir];
/*     */   }
/*     */   
/*     */   public int getColor(int p1, int p2, int dir)
/*     */   {
/* 116 */     return this.colors[dir][(p1 * 16 + p2)];
/*     */   }
/*     */   
/*     */   public int getAlpha(int p1, int p2, int dir)
/*     */   {
/* 121 */     return this.alphas[dir][(p1 * 16 + p2)];
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_70296_d()
/*     */   {
/* 127 */     super.func_70296_d();
/*     */     
/* 129 */     if (!this.field_145850_b.field_72995_K)
/*     */     {
/* 131 */       boolean flag = false;
/* 132 */       for (int i = 0; i < 6; i++)
/*     */       {
/* 134 */         if (hasColor(i))
/*     */         {
/* 136 */           this.hasColor[i] = false;
/* 137 */           for (int j = 0; j < 256; j++)
/*     */           {
/* 139 */             if (this.alphas[i][j] != 0)
/*     */             {
/* 141 */               this.hasColor[i] = true;
/* 142 */               flag = true;
/* 143 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 149 */       if (flag)
/*     */       {
/* 151 */         sendPacket();
/*     */       }
/*     */       else
/*     */       {
/* 155 */         this.field_145850_b.func_175698_g(func_174877_v());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*     */   public AxisAlignedBB getRenderBoundingBox()
/*     */   {
/* 164 */     return new AxisAlignedBB(func_174877_v(), func_174877_v().func_177982_a(1, 1, 1));
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean shouldRenderInPass(int pass)
/*     */   {
/* 170 */     return pass == 1;
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityPaint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */