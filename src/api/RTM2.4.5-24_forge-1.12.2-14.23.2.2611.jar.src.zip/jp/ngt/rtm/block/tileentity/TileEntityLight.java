/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.ngtlib.math.Vec3;
/*    */ import jp.ngt.rtm.RTMResource;
/*    */ import jp.ngt.rtm.modelpack.ResourceType;
/*    */ import jp.ngt.rtm.render.MachinePartsRenderer;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class TileEntityLight extends TileEntityMachineBase
/*    */ {
/*    */   public void func_73660_a()
/*    */   {
/* 16 */     super.func_73660_a();
/*    */     
/* 18 */     boolean b = this.field_145850_b.func_175687_A(func_174877_v()) > 0;
/* 19 */     if ((this.isGettingPower ^ b))
/*    */     {
/* 21 */       this.isGettingPower = b;
/*    */       
/* 23 */       this.field_145850_b.func_175664_x(func_174877_v());
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public Vec3 getNormal(float x, float y, float z, float pitch, float yaw)
/*    */   {
/* 30 */     if (this.normal == null)
/*    */     {
/* 32 */       this.normal = new Vec3(x, y, z);
/* 33 */       MachinePartsRenderer.rotateVec(this.normal, 
/* 34 */         func_145832_p(), pitch, yaw);
/*    */     }
/* 36 */     return this.normal;
/*    */   }
/*    */   
/*    */ 
/*    */   @SideOnly(Side.CLIENT)
/*    */   public AxisAlignedBB getRenderBoundingBox()
/*    */   {
/* 43 */     return INFINITE_EXTENT_AABB;
/*    */   }
/*    */   
/*    */ 
/*    */   protected ResourceType getSubType()
/*    */   {
/* 49 */     return RTMResource.MACHINE_LIGHT;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityLight.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */