/*     */ package jp.ngt.rtm.block.tileentity;
/*     */ 
/*     */ import java.util.Random;
/*     */ import jp.ngt.ngtlib.block.TileEntityCustom;
/*     */ import jp.ngt.rtm.modelpack.ResourceType;
/*     */ import jp.ngt.rtm.modelpack.cfg.ModelConfig;
/*     */ import jp.ngt.rtm.modelpack.cfg.OrnamentConfig;
/*     */ import jp.ngt.rtm.modelpack.modelset.ModelSetOrnament;
/*     */ import jp.ngt.rtm.modelpack.state.ResourceState;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public abstract class TileEntityOrnament extends TileEntityCustom implements jp.ngt.rtm.modelpack.IResourceSelector
/*     */ {
/*  19 */   private ResourceState<ModelSetOrnament> state = new ResourceState(getSubType());
/*     */   
/*     */   private byte attachedSide;
/*     */   private float randomScale;
/*     */   
/*     */   public void func_145839_a(NBTTagCompound nbt)
/*     */   {
/*  26 */     super.func_145839_a(nbt);
/*  27 */     this.state.readFromNBT(nbt.func_74775_l("State"));
/*  28 */     this.attachedSide = nbt.func_74771_c("AttachedSide");
/*  29 */     this.randomScale = nbt.func_74760_g("RandomScale");
/*     */   }
/*     */   
/*     */ 
/*     */   public NBTTagCompound func_189515_b(NBTTagCompound nbt)
/*     */   {
/*  35 */     super.func_189515_b(nbt);
/*  36 */     nbt.func_74782_a("State", this.state.writeToNBT());
/*  37 */     nbt.func_74774_a("AttachedSide", this.attachedSide);
/*  38 */     nbt.func_74776_a("RandomScale", getRandomScale());
/*  39 */     return nbt;
/*     */   }
/*     */   
/*     */   public byte getAttachedSide()
/*     */   {
/*  44 */     return this.attachedSide;
/*     */   }
/*     */   
/*     */   public void setAttachedSide(byte side)
/*     */   {
/*  49 */     this.attachedSide = side;
/*  50 */     func_70296_d();
/*     */   }
/*     */   
/*     */   public float getRandomScale()
/*     */   {
/*  55 */     if (this.randomScale <= 0.0F)
/*     */     {
/*  57 */       float min = ((OrnamentConfig)((ModelSetOrnament)getResourceState().getResourceSet()).getConfig()).minRandomScale;
/*  58 */       float randF = jp.ngt.ngtlib.math.NGTMath.RANDOM.nextFloat();
/*  59 */       this.randomScale = (min + (1.0F - min) * randF);
/*     */     }
/*  61 */     return this.randomScale;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean shouldRenderInPass(int pass)
/*     */   {
/*  67 */     return pass >= 0;
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public AxisAlignedBB getRenderBoundingBox()
/*     */   {
/*  74 */     ModelConfig cfg = ((ModelSetOrnament)getResourceState().getResourceSet()).getConfig();
/*  75 */     float[] fa = cfg.renderAABB;
/*  76 */     BlockPos pos = func_174877_v();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */     AxisAlignedBB bb = new AxisAlignedBB(pos.func_177958_n() + fa[0], pos.func_177956_o() + fa[1], pos.func_177952_p() + fa[2], pos.func_177958_n() + fa[3], pos.func_177956_o() + fa[4], pos.func_177952_p() + fa[5]);
/*  84 */     return bb;
/*     */   }
/*     */   
/*     */ 
/*     */   public ResourceState<ModelSetOrnament> getResourceState()
/*     */   {
/*  90 */     return this.state;
/*     */   }
/*     */   
/*     */ 
/*     */   public void updateResourceState()
/*     */   {
/*  96 */     if ((this.field_145850_b == null) || (!this.field_145850_b.field_72995_K))
/*     */     {
/*  98 */       sendPacket();
/*  99 */       func_70296_d();
/* 100 */       jp.ngt.ngtlib.block.BlockUtil.markBlockForUpdate(func_145831_w(), func_174877_v());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int[] getSelectorPos()
/*     */   {
/* 107 */     return new int[] { func_174877_v().func_177958_n(), func_174877_v().func_177956_o(), func_174877_v().func_177952_p() };
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean closeGui(ResourceState par1)
/*     */   {
/* 113 */     return true;
/*     */   }
/*     */   
/*     */   protected abstract ResourceType getSubType();
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityOrnament.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */