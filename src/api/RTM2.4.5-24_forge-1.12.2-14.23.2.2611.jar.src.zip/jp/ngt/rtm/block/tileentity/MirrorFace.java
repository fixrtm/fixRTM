/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum MirrorFace
/*    */ {
/*  7 */   YNEG(new MirrorVertex[] { MirrorVertex.PNN, MirrorVertex.PNP, MirrorVertex.NNP, MirrorVertex.NNN }), 
/*  8 */   YPOS(new MirrorVertex[] { MirrorVertex.PPP, MirrorVertex.PPN, MirrorVertex.NPN, MirrorVertex.NPP }), 
/*  9 */   ZNEG(new MirrorVertex[] { MirrorVertex.NNN, MirrorVertex.NPN, MirrorVertex.PPN, MirrorVertex.PNN }), 
/* 10 */   ZPOS(new MirrorVertex[] { MirrorVertex.PNP, MirrorVertex.PPP, MirrorVertex.NPP, MirrorVertex.NNP }), 
/* 11 */   XNEG(new MirrorVertex[] { MirrorVertex.NNP, MirrorVertex.NPP, MirrorVertex.NPN, MirrorVertex.NNN }), 
/* 12 */   XPOS(new MirrorVertex[] { MirrorVertex.PNN, MirrorVertex.PPN, MirrorVertex.PPP, MirrorVertex.PNP });
/*    */   
/*    */   public final MirrorVertex[] vertices;
/*    */   
/*    */   private MirrorFace(MirrorVertex... par1)
/*    */   {
/* 18 */     this.vertices = par1;
/*    */   }
/*    */   
/*    */   public static MirrorFace get(int par1)
/*    */   {
/* 23 */     return values()[par1];
/*    */   }
/*    */   
/*    */   public static enum MirrorVertex
/*    */   {
/* 28 */     NNN(-0.5F, -0.5F, -0.5F), 
/* 29 */     NNP(-0.5F, -0.5F, 0.5F), 
/* 30 */     NPN(-0.5F, 0.5F, -0.5F), 
/* 31 */     PNN(0.5F, -0.5F, -0.5F), 
/* 32 */     NPP(-0.5F, 0.5F, 0.5F), 
/* 33 */     PNP(0.5F, -0.5F, 0.5F), 
/* 34 */     PPN(0.5F, 0.5F, -0.5F), 
/* 35 */     PPP(0.5F, 0.5F, 0.5F);
/*    */     
/*    */     public final float x;
/*    */     public final float y;
/*    */     public final float z;
/*    */     
/*    */     private MirrorVertex(float par1, float par2, float par3)
/*    */     {
/* 43 */       this.x = par1;
/* 44 */       this.y = par2;
/* 45 */       this.z = par3;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/MirrorFace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */