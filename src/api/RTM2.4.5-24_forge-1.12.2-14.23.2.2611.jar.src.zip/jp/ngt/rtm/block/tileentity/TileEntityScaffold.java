/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.ngtlib.math.Vec3;
/*    */ import jp.ngt.rtm.RTMResource;
/*    */ import jp.ngt.rtm.modelpack.cfg.ModelConfig;
/*    */ import jp.ngt.rtm.modelpack.cfg.OrnamentConfig;
/*    */ import jp.ngt.rtm.modelpack.modelset.ModelSetOrnament;
/*    */ import jp.ngt.rtm.modelpack.state.ResourceState;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class TileEntityScaffold extends TileEntityOrnament
/*    */ {
/*    */   private byte dir;
/*    */   
/*    */   public void func_145839_a(NBTTagCompound nbt)
/*    */   {
/* 20 */     super.func_145839_a(nbt);
/* 21 */     this.dir = nbt.func_74771_c("direction");
/*    */   }
/*    */   
/*    */ 
/*    */   public NBTTagCompound func_189515_b(NBTTagCompound nbt)
/*    */   {
/* 27 */     super.func_189515_b(nbt);
/* 28 */     nbt.func_74774_a("direction", this.dir);
/* 29 */     return nbt;
/*    */   }
/*    */   
/*    */   public byte getDir()
/*    */   {
/* 34 */     return this.dir;
/*    */   }
/*    */   
/*    */   public void setDir(byte par1)
/*    */   {
/* 39 */     this.dir = par1;
/* 40 */     sendPacket();
/*    */   }
/*    */   
/*    */   public Vec3 getMotionVec()
/*    */   {
/* 45 */     float speed = ((OrnamentConfig)((ModelSetOrnament)getResourceState().getResourceSet()).getConfig()).conveyorSpeed;
/* 46 */     if (speed != 0.0F)
/*    */     {
/* 48 */       Vec3 vec = getVec(speed);
/* 49 */       vec = vec.rotateAroundY(180.0F - getDir() * 90.0F);
/* 50 */       return vec;
/*    */     }
/* 52 */     return Vec3.ZERO;
/*    */   }
/*    */   
/*    */   protected Vec3 getVec(float par1)
/*    */   {
/* 57 */     return new Vec3(0.0D, 0.0D, par1);
/*    */   }
/*    */   
/*    */ 
/*    */   @SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
/*    */   public AxisAlignedBB getRenderBoundingBox()
/*    */   {
/* 64 */     ModelConfig cfg = ((ModelSetOrnament)getResourceState().getResourceSet()).getConfig();
/* 65 */     float[] fa = cfg.renderAABB;
/* 66 */     BlockPos pos = func_174877_v();
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 73 */     AxisAlignedBB bb = new AxisAlignedBB(pos.func_177958_n() + fa[0], pos.func_177956_o() + fa[1], pos.func_177952_p() + fa[2], pos.func_177958_n() + fa[3], pos.func_177956_o() + fa[4], pos.func_177952_p() + fa[5]);
/* 74 */     return bb;
/*    */   }
/*    */   
/*    */ 
/*    */   protected jp.ngt.rtm.modelpack.ResourceType getSubType()
/*    */   {
/* 80 */     return RTMResource.ORNAMENT_SCAFFOLD;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityScaffold.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */