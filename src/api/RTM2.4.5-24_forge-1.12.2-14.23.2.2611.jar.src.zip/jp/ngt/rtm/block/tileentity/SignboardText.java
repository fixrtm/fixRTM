/*     */ package jp.ngt.rtm.block.tileentity;
/*     */ 
/*     */ import jp.ngt.ngtlib.renderer.media.FontImage;
/*     */ import jp.ngt.ngtlib.util.NGTUtil;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignboardText
/*     */ {
/*     */   private static final int IMAGE_SIZE = 48;
/*     */   private static final float TO_SEC = 0.001F;
/*     */   private static final String SEPARATOR = "\\|";
/*     */   private FontImage[] texts;
/*     */   private String rawText;
/*     */   public float posU;
/*     */   public float posV;
/*     */   public float size;
/*     */   public float width;
/*     */   public AnimeType animeType;
/*     */   public float animeSpeed;
/*     */   private float prevMinU;
/*     */   private long prevTime;
/*     */   private int index;
/*     */   
/*     */   public SignboardText(boolean isClient)
/*     */   {
/*  35 */     this.posU = (this.posV = 0.0F);
/*  36 */     this.size = 0.25F;
/*  37 */     this.width = 1.5F;
/*  38 */     this.animeType = AnimeType.SWITCH;
/*  39 */     this.animeSpeed = 1.0F;
/*  40 */     setText("sample|aaa", "Meiryo UI", 0, 0, isClient);
/*     */   }
/*     */   
/*     */   public static SignboardText readFromNBT(NBTTagCompound nbt)
/*     */   {
/*  45 */     SignboardText st = new SignboardText(!NGTUtil.isServer());
/*  46 */     String s1 = nbt.func_74779_i("Text");
/*  47 */     String s2 = nbt.func_74779_i("Font");
/*  48 */     int i1 = nbt.func_74762_e("Style");
/*  49 */     int i2 = nbt.func_74762_e("Color");
/*  50 */     st.posU = nbt.func_74760_g("PosU");
/*  51 */     st.posV = nbt.func_74760_g("PosV");
/*  52 */     st.size = nbt.func_74760_g("Size");
/*  53 */     st.width = nbt.func_74760_g("Width");
/*  54 */     st.animeType = AnimeType.values()[nbt.func_74762_e("AnimeType")];
/*  55 */     st.animeSpeed = nbt.func_74760_g("AnimeSpeed");
/*  56 */     st.setText(s1, s2, i1, i2, !NGTUtil.isServer());
/*  57 */     return st;
/*     */   }
/*     */   
/*     */   public NBTTagCompound writeToNBT()
/*     */   {
/*  62 */     NBTTagCompound nbt = new NBTTagCompound();
/*  63 */     nbt.func_74778_a("Text", this.rawText);
/*  64 */     nbt.func_74778_a("Font", getText().getFont());
/*  65 */     nbt.func_74768_a("Style", getText().getStyle());
/*  66 */     nbt.func_74768_a("Color", getText().getColor());
/*  67 */     nbt.func_74776_a("PosU", this.posU);
/*  68 */     nbt.func_74776_a("PosV", this.posV);
/*  69 */     nbt.func_74776_a("Size", this.size);
/*  70 */     nbt.func_74776_a("Width", this.width);
/*  71 */     nbt.func_74768_a("AnimeType", this.animeType.ordinal());
/*  72 */     nbt.func_74776_a("AnimeSpeed", this.animeSpeed);
/*  73 */     return nbt;
/*     */   }
/*     */   
/*     */   public FontImage getText()
/*     */   {
/*  78 */     return this.texts[this.index];
/*     */   }
/*     */   
/*     */   public String getRawText()
/*     */   {
/*  83 */     return this.rawText;
/*     */   }
/*     */   
/*     */   public void setText(String pText, String pFont, int pStyle, int pColor, boolean isClient)
/*     */   {
/*  88 */     if (this.animeType == AnimeType.SWITCH)
/*     */     {
/*  90 */       String[] sa = pText.split("\\|");
/*  91 */       this.texts = new FontImage[sa.length];
/*  92 */       for (int i = 0; i < sa.length; i++)
/*     */       {
/*  94 */         this.texts[i] = FontImage.create(sa[i], pFont, pStyle, pColor, 48, isClient);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*  99 */       this.texts = new FontImage[] { FontImage.create(pText, pFont, pStyle, pColor, 48, isClient) };
/*     */     }
/* 101 */     this.rawText = pText;
/* 102 */     this.index = 0;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void render(float x, float y, float z, float scale)
/*     */   {
/* 108 */     float minU = 0.0F;
/* 109 */     float maxU = 1.0F;
/* 110 */     float w2 = this.width;
/* 111 */     if (this.animeType == AnimeType.SCROLL)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 124 */       long time = System.currentTimeMillis();
/* 125 */       float difSec = (float)(time - this.prevTime) * 0.001F;
/* 126 */       minU = this.prevMinU + difSec / this.animeSpeed;
/* 127 */       minU %= 1.0F;
/* 128 */       float tw = 48.0F * this.width / this.size / getText().getWidth();
/* 129 */       maxU = minU + tw;
/* 130 */       this.prevTime = time;
/* 131 */       this.prevMinU = minU;
/*     */     }
/*     */     else
/*     */     {
/* 135 */       if (this.animeType == AnimeType.SWITCH)
/*     */       {
/* 137 */         long time = System.currentTimeMillis();
/* 138 */         float difSec = (float)(time - this.prevTime) * 0.001F;
/* 139 */         if (difSec >= this.animeSpeed)
/*     */         {
/* 141 */           this.index = ((this.index + 1) % this.texts.length);
/* 142 */           this.prevTime = time;
/*     */         }
/*     */       }
/*     */       
/* 146 */       int tw = (int)(48.0F * this.width / this.size);
/* 147 */       maxU = tw / getText().getWidth();
/* 148 */       if (maxU > 1.0F)
/*     */       {
/* 150 */         maxU = 1.0F;
/* 151 */         w2 = this.size * getText().getWidth() / getText().getHeight();
/*     */       }
/*     */     }
/*     */     
/* 155 */     float h = this.size * scale;
/* 156 */     float w = w2 * scale;
/* 157 */     getText().render(x, y, z, w, h, minU, 0.0F, maxU, 1.0F);
/*     */   }
/*     */   
/*     */   public static enum AnimeType
/*     */   {
/* 162 */     NONE, 
/* 163 */     SCROLL, 
/* 164 */     SWITCH;
/*     */     
/*     */     private AnimeType() {}
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/SignboardText.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */