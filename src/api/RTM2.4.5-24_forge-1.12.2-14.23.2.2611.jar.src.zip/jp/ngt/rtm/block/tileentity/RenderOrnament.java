/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.rtm.modelpack.cfg.OrnamentConfig;
/*    */ import jp.ngt.rtm.modelpack.modelset.ModelSetOrnament;
/*    */ import jp.ngt.rtm.modelpack.state.ResourceState;
/*    */ import jp.ngt.rtm.render.ModelObject;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraftforge.client.MinecraftForgeClient;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class RenderOrnament<T extends TileEntityOrnament>
/*    */   extends TileEntitySpecialRenderer<T>
/*    */ {
/*    */   private void renderOrnament(T par1, double par2, double par4, double par6, float par8)
/*    */   {
/* 19 */     GL11.glPushMatrix();
/* 20 */     GL11.glEnable(32826);
/* 21 */     GL11.glTranslatef((float)par2 + 0.5F, (float)par4 + 0.5F, (float)par6 + 0.5F);
/*    */     
/* 23 */     ResourceState<ModelSetOrnament> state = par1.getResourceState();
/* 24 */     ModelSetOrnament modelSet = (ModelSetOrnament)state.getResourceSet();
/* 25 */     OrnamentConfig cfg = (OrnamentConfig)modelSet.getConfig();
/* 26 */     int pass = MinecraftForgeClient.getRenderPass();
/*    */     
/* 28 */     float scale = par1.getRandomScale();
/* 29 */     GL11.glScalef(scale, scale, scale);
/* 30 */     modelSet.modelObj.render(par1, cfg, pass, par8);
/*    */     
/* 32 */     GL11.glPopMatrix();
/*    */   }
/*    */   
/*    */ 
/*    */   public void render(T tileEntity, double par2, double par4, double par6, float par8, int par9, float alpha)
/*    */   {
/* 38 */     renderOrnament(tileEntity, par2, par4, par6, par8);
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/RenderOrnament.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */