/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.ngtlib.renderer.model.ModelLoader;
/*    */ import jp.ngt.ngtlib.renderer.model.PolygonModel;
/*    */ import jp.ngt.ngtlib.renderer.model.VecAccuracy;
/*    */ import jp.ngt.rtm.RTMCore;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class RenderConverter
/*    */   extends TileEntitySpecialRenderer<TileEntityConverterCore>
/*    */ {
/*    */   private final PolygonModel model;
/* 19 */   private static final ResourceLocation[] textures = { new ResourceLocation("rtm", "textures/tileentity/converter_empty.png"), new ResourceLocation("rtm", "textures/tileentity/converter.png"), new ResourceLocation("rtm", "textures/tileentity/converter_burning.png"), new ResourceLocation("rtm", "textures/tileentity/converter_finish.png") };
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public RenderConverter()
/*    */   {
/* 26 */     this.model = ModelLoader.loadModel(new ResourceLocation("rtm", "models/converter.obj"), VecAccuracy.MEDIUM, new Object[0]);
/*    */   }
/*    */   
/*    */   private void renderConverterAt(TileEntityConverterCore tileEntity, double par2, double par4, double par6, float par8)
/*    */   {
/* 31 */     GL11.glPushMatrix();
/* 32 */     GL11.glEnable(32826);
/* 33 */     GL11.glTranslatef((float)par2 + 0.5F, (float)par4, (float)par6 + 0.5F);
/* 34 */     func_147499_a(textures[tileEntity.getMode()]);
/* 35 */     GL11.glRotatef(-tileEntity.getDirection() * 90.0F, 0.0F, 1.0F, 0.0F);
/* 36 */     this.model.renderPart(RTMCore.smoothing, "dai");
/* 37 */     GL11.glRotatef(tileEntity.getPitch(), 1.0F, 0.0F, 0.0F);
/* 38 */     this.model.renderPart(RTMCore.smoothing, "jiku");
/* 39 */     this.model.renderPart(RTMCore.smoothing, "body1");
/* 40 */     this.model.renderPart(RTMCore.smoothing, "body2");
/* 41 */     GL11.glPopMatrix();
/*    */   }
/*    */   
/*    */   public void renderTileEntityAt(TileEntityConverterCore par1, double par2, double par4, double par6, float par8, int par9)
/*    */   {
/* 46 */     renderConverterAt(par1, par2, par4, par6, par8);
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/RenderConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */