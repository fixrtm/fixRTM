/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.rtm.RTMResource;
/*    */ import jp.ngt.rtm.modelpack.ResourceType;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ 
/*    */ public class TileEntityTurnstile extends TileEntityMachineBase
/*    */ {
/*  9 */   private int count = 0;
/*    */   
/*    */ 
/*    */   public void func_145839_a(NBTTagCompound nbt)
/*    */   {
/* 14 */     super.func_145839_a(nbt);
/* 15 */     this.count = nbt.func_74762_e("Count");
/*    */   }
/*    */   
/*    */ 
/*    */   public NBTTagCompound func_189515_b(NBTTagCompound nbt)
/*    */   {
/* 21 */     super.func_189515_b(nbt);
/* 22 */     nbt.func_74768_a("Count", this.count);
/* 23 */     return nbt;
/*    */   }
/*    */   
/*    */ 
/*    */   public void func_73660_a()
/*    */   {
/* 29 */     super.func_73660_a();
/*    */     
/* 31 */     if (this.count > 0)
/*    */     {
/* 33 */       this.count -= 1;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean canThrough()
/*    */   {
/* 40 */     return this.count > 0;
/*    */   }
/*    */   
/*    */   public void setCount(int par1)
/*    */   {
/* 45 */     this.count = par1;
/* 46 */     if (!this.field_145850_b.field_72995_K)
/*    */     {
/* 48 */       sendPacket();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   protected ResourceType getSubType()
/*    */   {
/* 55 */     return RTMResource.MACHINE_TURNSTILE;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/TileEntityTurnstile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */