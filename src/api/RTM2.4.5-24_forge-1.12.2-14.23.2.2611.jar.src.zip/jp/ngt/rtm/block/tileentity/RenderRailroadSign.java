/*    */ package jp.ngt.rtm.block.tileentity;
/*    */ 
/*    */ import jp.ngt.ngtlib.renderer.NGTRenderer;
/*    */ import jp.ngt.ngtlib.renderer.NGTTessellator;
/*    */ import jp.ngt.rtm.modelpack.modelset.TextureSetRRS;
/*    */ import jp.ngt.rtm.modelpack.state.ResourceState;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class RenderRailroadSign extends TileEntitySpecialRenderer<TileEntityRailroadSign>
/*    */ {
/*    */   public void renderRailroadSignAt(TileEntityRailroadSign tileEntity, double par2, double par4, double par6, float par8)
/*    */   {
/* 18 */     GL11.glPushMatrix();
/* 19 */     GL11.glEnable(32826);
/* 20 */     GL11.glTranslatef((float)par2 + 0.5F, (float)par4, (float)par6 + 0.5F);
/*    */     
/* 22 */     GL11.glPushMatrix();
/* 23 */     float f0 = 1.25F;
/* 24 */     float w = 0.25F;
/* 25 */     float d = 0.0675F;
/* 26 */     boolean flipVertical = !tileEntity.func_145831_w().func_175623_d(tileEntity.func_174877_v().func_177984_a());
/* 27 */     if (flipVertical)
/*    */     {
/* 29 */       f0 = -0.25F;
/*    */     }
/* 31 */     GL11.glTranslatef(0.0F, f0, 0.0F);
/* 32 */     GL11.glRotatef(tileEntity.getRotation(), 0.0F, 1.0F, 0.0F);
/*    */     
/* 34 */     NGTTessellator tessellator = NGTTessellator.instance;
/* 35 */     TextureSetRRS set = (TextureSetRRS)tileEntity.getResourceState().getResourceSet();
/* 36 */     func_147499_a(set.texture);
/* 37 */     tessellator.startDrawingQuads();
/* 38 */     tessellator.setNormal(0.0F, 1.0F, 0.0F);
/* 39 */     tessellator.addVertexWithUV(w, -w, d, 1.0F, 1.0F);
/* 40 */     tessellator.addVertexWithUV(w, w, d, 1.0F, 0.0F);
/* 41 */     tessellator.addVertexWithUV(-w, w, d, 0.0F, 0.0F);
/* 42 */     tessellator.addVertexWithUV(-w, -w, d, 0.0F, 1.0F);
/* 43 */     tessellator.draw();
/*    */     
/* 45 */     GL11.glDisable(2896);
/* 46 */     tessellator.startDrawingQuads();
/* 47 */     tessellator.setColorOpaque_I(0);
/* 48 */     tessellator.addVertexWithUV(-w, -w, d, 0.0F, 1.0F);
/* 49 */     tessellator.addVertexWithUV(-w, w, d, 0.0F, 0.0F);
/* 50 */     tessellator.addVertexWithUV(w, w, d, 1.0F, 0.0F);
/* 51 */     tessellator.addVertexWithUV(w, -w, d, 1.0F, 1.0F);
/* 52 */     tessellator.draw();
/* 53 */     GL11.glPopMatrix();
/*    */     
/* 55 */     GL11.glDisable(3553);
/* 56 */     if (flipVertical)
/*    */     {
/* 58 */       GL11.glTranslatef(0.0F, -0.5F, 0.0F);
/*    */     }
/* 60 */     tessellator.startDrawingQuads();
/* 61 */     tessellator.setColorOpaque_I(4210752);
/* 62 */     NGTRenderer.renderPole(tessellator, 0.0625F, 1.5F, false);
/* 63 */     tessellator.draw();
/* 64 */     GL11.glEnable(3553);
/* 65 */     GL11.glEnable(2896);
/*    */     
/* 67 */     GL11.glPopMatrix();
/*    */   }
/*    */   
/*    */ 
/*    */   public void render(TileEntityRailroadSign par1, double par2, double par4, double par6, float par8, int par9, float aplha)
/*    */   {
/* 73 */     renderRailroadSignAt(par1, par2, par4, par6, par8);
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/tileentity/RenderRailroadSign.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */