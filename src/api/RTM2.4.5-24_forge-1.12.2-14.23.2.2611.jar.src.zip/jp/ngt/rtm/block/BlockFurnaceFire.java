/*     */ package jp.ngt.rtm.block;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import jp.ngt.ngtlib.block.BlockLiquidBase;
/*     */ import jp.ngt.ngtlib.block.BlockUtil;
/*     */ import jp.ngt.rtm.RTMBlock;
/*     */ import jp.ngt.rtm.RTMFluid;
/*     */ import jp.ngt.rtm.RTMItem;
/*     */ import jp.ngt.rtm.RTMMaterial;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.BlockRenderLayer;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.EnumParticleTypes;
/*     */ import net.minecraft.util.SoundCategory;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fluids.Fluid;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class BlockFurnaceFire
/*     */   extends BlockLiquidBase
/*     */ {
/*  35 */   private static final Item itemIronOre = Item.func_150898_a(Blocks.field_150366_p);
/*     */   
/*     */   public BlockFurnaceFire(Fluid fluid, boolean light)
/*     */   {
/*  39 */     super(fluid, RTMMaterial.melted);
/*  40 */     func_149715_a(light ? 1.0F : 0.0F);
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public BlockRenderLayer func_180664_k()
/*     */   {
/*  47 */     return BlockRenderLayer.TRANSLUCENT;
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_180650_b(World world, BlockPos pos, IBlockState state, Random random)
/*     */   {
/*  53 */     super.func_180650_b(world, pos, state, random);
/*     */     
/*  55 */     if (!world.field_72995_K)
/*     */     {
/*  57 */       int x = pos.func_177958_n();
/*  58 */       int y = pos.func_177956_o();
/*  59 */       int z = pos.func_177952_p();
/*  60 */       int meta = BlockUtil.getMetadata(world, pos);
/*     */       
/*  62 */       if (this == RTMFluid.furnaceFire)
/*     */       {
/*  64 */         if (meta == 0)
/*     */         {
/*  66 */           IBlockState state2 = BlockUtil.getBlockState(world, x, y - 1, z);
/*  67 */           Block block = state2.func_177230_c();
/*  68 */           if ((block != RTMBlock.fireBrick) && (block != RTMBlock.hotStoveBrick) && (state2.func_185915_l()))
/*     */           {
/*  70 */             BlockUtil.setBlock(world, x, y, z, Blocks.field_150480_ab, 0, 2);
/*     */           }
/*     */         }
/*     */       }
/*  74 */       else if (this == RTMFluid.exhaustGas)
/*     */       {
/*  76 */         if (BlockUtil.getBlock(world, x, y + 1, z) == RTMFluid.furnaceFire)
/*     */         {
/*  78 */           int m1 = BlockUtil.getMetadata(world, x, y + 1, z);
/*  79 */           BlockUtil.setBlock(world, x, y, z, RTMFluid.furnaceFire, m1, 2);
/*  80 */           BlockUtil.setBlock(world, x, y + 1, z, RTMFluid.exhaustGas, meta, 2);
/*  81 */           world.func_180497_b(new BlockPos(x, y + 1, z), this, func_149738_a(world), 0);
/*     */         }
/*  83 */         else if (BlockUtil.isAir(world, x, y + 1, z))
/*     */         {
/*  85 */           if (random.nextInt(10) == 0)
/*     */           {
/*  87 */             if (meta > 0)
/*     */             {
/*  89 */               BlockUtil.setBlock(world, x, y, z, RTMFluid.exhaustGas, meta - 1, 2);
/*     */             }
/*     */             else
/*     */             {
/*  93 */               BlockUtil.setBlock(world, x, y, z, Blocks.field_150350_a, 0, 2);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_180634_a(World world, BlockPos pos, IBlockState state, Entity entity)
/*     */   {
/* 104 */     boolean flag1 = true;
/* 105 */     int x = pos.func_177958_n();
/* 106 */     int y = pos.func_177956_o();
/* 107 */     int z = pos.func_177952_p();
/*     */     
/* 109 */     if ((entity instanceof EntityItem))
/*     */     {
/* 111 */       ItemStack itemstack0 = ((EntityItem)entity).func_92059_d();
/* 112 */       int sizeCoke = 0;
/* 113 */       int sizeIron = 0;
/* 114 */       boolean isIron = false;
/*     */       
/* 116 */       if (itemstack0.func_77973_b() == RTMItem.coke)
/*     */       {
/* 118 */         sizeCoke = itemstack0.func_190916_E() / 2;
/* 119 */         entity.func_70110_aj();
/* 120 */         flag1 = false;
/*     */       }
/* 122 */       else if ((itemstack0.func_77973_b() == Items.field_151044_h) && (itemstack0.func_77952_i() == 1))
/*     */       {
/* 124 */         sizeCoke = itemstack0.func_190916_E() / 8;
/* 125 */         entity.func_70110_aj();
/* 126 */         flag1 = false;
/*     */       }
/* 128 */       else if (itemstack0.func_77973_b() == itemIronOre)
/*     */       {
/* 130 */         sizeIron = itemstack0.func_190916_E();
/* 131 */         isIron = true;
/* 132 */         entity.func_70110_aj();
/* 133 */         flag1 = false;
/*     */       }
/*     */       
/* 136 */       if ((sizeCoke > 0) || (sizeIron > 0))
/*     */       {
/* 138 */         if (!world.field_72995_K)
/*     */         {
/* 140 */           List list = world.func_72872_a(EntityItem.class, new AxisAlignedBB(x, y, z, x + 1.0D, y + 1.0D, z + 1.0D));
/* 141 */           if ((list != null) && (!list.isEmpty()))
/*     */           {
/* 143 */             int i2 = 0;
/* 144 */             for (int i = 0; i < list.size(); i++)
/*     */             {
/* 146 */               EntityItem entityItem = (EntityItem)list.get(i);
/* 147 */               ItemStack itemstack1 = entityItem.func_92059_d();
/* 148 */               if (itemstack1.func_77973_b() == RTMItem.coke)
/*     */               {
/* 150 */                 i2 = itemstack1.func_190916_E() / 2;
/*     */               }
/* 152 */               else if ((itemstack1.func_77973_b() == Items.field_151044_h) && (itemstack1.func_77952_i() == 1))
/*     */               {
/* 154 */                 i2 = itemstack1.func_190916_E() / 8;
/*     */               }
/*     */               else
/*     */               {
/* 158 */                 i2 = 0;
/*     */               }
/*     */               
/* 161 */               if (i2 > 0)
/*     */               {
/* 163 */                 if (sizeCoke + i2 > sizeIron)
/*     */                 {
/* 165 */                   itemstack1.func_190920_e(sizeCoke + i2 - sizeIron);
/* 166 */                   entityItem.func_92058_a(itemstack1);
/* 167 */                   sizeCoke = sizeIron;
/*     */                 }
/*     */                 else
/*     */                 {
/* 171 */                   sizeCoke += i2;
/* 172 */                   entityItem.func_70106_y();
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */           
/* 178 */           if (isIron)
/*     */           {
/* 180 */             if (sizeCoke == 0)
/*     */             {
/* 182 */               return;
/*     */             }
/* 184 */             if (sizeCoke < sizeIron)
/*     */             {
/* 186 */               itemstack0.func_190918_g(sizeCoke);
/* 187 */               ((EntityItem)entity).func_92058_a(itemstack0);
/* 188 */               sizeIron = sizeCoke;
/*     */             }
/*     */             else
/*     */             {
/* 192 */               entity.func_70106_y();
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 197 */             if (sizeIron == 0)
/*     */             {
/* 199 */               return;
/*     */             }
/* 201 */             if (sizeCoke > sizeIron)
/*     */             {
/* 203 */               itemstack0.func_190918_g(sizeIron);
/* 204 */               ((EntityItem)entity).func_92058_a(itemstack0);
/* 205 */               sizeCoke = sizeIron;
/*     */             }
/*     */             else
/*     */             {
/* 209 */               entity.func_70106_y();
/*     */             }
/*     */           }
/*     */           
/* 213 */           onCollidedIronOre(world, x, y, z, sizeIron);
/*     */         }
/*     */       }
/*     */       
/* 217 */       if (flag1)
/*     */       {
/* 219 */         entity.field_70181_x = 0.20000000298023224D;
/* 220 */         entity.field_70159_w = ((world.field_73012_v.nextFloat() - world.field_73012_v.nextFloat()) * 0.2F);
/* 221 */         entity.field_70179_y = ((world.field_73012_v.nextFloat() - world.field_73012_v.nextFloat()) * 0.2F);
/* 222 */         entity.func_184185_a(SoundEvents.field_187659_cY, 0.4F, 2.0F + world.field_73012_v.nextFloat() * 0.4F);
/*     */       }
/*     */     }
/*     */     
/* 226 */     if (flag1)
/*     */     {
/* 228 */       entity.func_70097_a(DamageSource.field_76371_c, 1.0F);
/* 229 */       entity.func_70015_d(5);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void onCollidedIronOre(World world, int x, int y, int z, int amount)
/*     */   {
/* 236 */     if ((BlockUtil.getBlock(world, x, y - 1, z) instanceof BlockFurnaceFire))
/*     */     {
/* 238 */       if ((BlockUtil.getBlock(world, x, y, z) == RTMFluid.furnaceFire) && (world.field_73012_v.nextInt(10) == 0))
/*     */       {
/* 240 */         int meta = BlockUtil.getMetadata(world, x, y, z);
/* 241 */         amount += world.field_73012_v.nextInt(meta + 1);
/* 242 */         if (world.field_73012_v.nextInt(5) == 0)
/*     */         {
/* 244 */           BlockUtil.setBlock(world, x, y, z, RTMFluid.exhaustGas, 15, 2);
/*     */         }
/*     */       }
/* 247 */       onCollidedIronOre(world, x, y - 1, z, amount);
/*     */     }
/*     */     else
/*     */     {
/* 251 */       while (amount > 0)
/*     */       {
/* 253 */         if (!(BlockUtil.getBlock(world, x, y, z) instanceof BlockFurnaceFire)) {
/*     */           break;
/*     */         }
/*     */         
/* 257 */         BlockUtil.setAir(world, x, y, z);
/* 258 */         amount = BlockLiquidBase.addLiquid(world, x, y, z, RTMFluid.liquefiedPigIron, amount, true);
/* 259 */         y++;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void randomDisplayTick(World world, int x, int y, int z, Random random)
/*     */   {
/* 267 */     if (this == RTMFluid.furnaceFire)
/*     */     {
/* 269 */       IBlockState state = BlockUtil.getBlockState(world, x, y + 1, z);
/* 270 */       if ((state.func_185904_a() == Material.field_151579_a) && (!state.func_185914_p()))
/*     */       {
/* 272 */         double d5 = x + random.nextFloat();
/* 273 */         double d6 = y;
/* 274 */         double d7 = z + random.nextFloat();
/* 275 */         world.func_175688_a(EnumParticleTypes.EXPLOSION_NORMAL, d5, d6, d7, 0.0D, 0.0D, 0.0D, new int[0]);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 286 */         if (random.nextInt(200) == 0)
/*     */         {
/* 288 */           world.func_184134_a(x, y, z, SoundEvents.field_187656_cX, SoundCategory.BLOCKS, 0.2F + random.nextFloat() * 0.2F, 0.9F + random.nextFloat() * 0.15F, false);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void meltBlock(World world, int x, int y, int z)
/*     */   {
/* 307 */     if (this == RTMFluid.furnaceFire)
/*     */     {
/* 309 */       super.meltBlock(world, x, y, z);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockFurnaceFire.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */