/*    */ package jp.ngt.rtm.block;
/*    */ 
/*    */ import jp.ngt.ngtlib.block.BlockContainerCustomWithMeta;
/*    */ import jp.ngt.ngtlib.block.BlockUtil;
/*    */ import jp.ngt.rtm.block.tileentity.TileEntityMirror;
/*    */ import net.minecraft.block.SoundType;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockMirror extends BlockContainerCustomWithMeta
/*    */ {
/*    */   public final MirrorType mirrorType;
/*    */   
/*    */   public BlockMirror(MirrorType par1)
/*    */   {
/* 21 */     super(Material.field_151592_s);
/* 22 */     this.mirrorType = par1;
/* 23 */     func_149672_a(SoundType.field_185853_f);
/*    */   }
/*    */   
/*    */ 
/*    */   public TileEntity func_149915_a(World world, int par2)
/*    */   {
/* 29 */     return new TileEntityMirror();
/*    */   }
/*    */   
/*    */ 
/*    */   public AxisAlignedBB func_185496_a(IBlockState state, IBlockAccess world, BlockPos pos)
/*    */   {
/* 35 */     if (this.mirrorType == MirrorType.Mono_Panel)
/*    */     {
/* 37 */       int meta = BlockUtil.getMetadata(world, pos);
/* 38 */       switch (meta) {
/*    */       case 0: 
/* 40 */         return new AxisAlignedBB(0.0D, 0.9375D, 0.0D, 1.0D, 1.0D, 1.0D);
/* 41 */       case 1:  return new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.0625D, 1.0D);
/* 42 */       case 2:  return new AxisAlignedBB(0.0D, 0.0D, 0.9375D, 1.0D, 1.0D, 1.0D);
/* 43 */       case 3:  return new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 0.0625D);
/* 44 */       case 4:  return new AxisAlignedBB(0.9375D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
/* 45 */       case 5:  return new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.0625D, 1.0D, 1.0D);
/*    */       }
/*    */     }
/* 48 */     return field_185505_j;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void func_180653_a(World world, BlockPos pos, IBlockState state, float chance, int fortune) {}
/*    */   
/*    */ 
/*    */ 
/*    */   public static enum MirrorType
/*    */   {
/* 59 */     Mono_Panel, 
/* 60 */     Hexa_Cube;
/*    */     
/*    */     private MirrorType() {}
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockMirror.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */