/*    */ package jp.ngt.rtm.block;
/*    */ 
/*    */ import jp.ngt.ngtlib.block.BlockArgHolder;
/*    */ import jp.ngt.ngtlib.block.BlockContainerCustom;
/*    */ import jp.ngt.rtm.RTMCore;
/*    */ import jp.ngt.rtm.block.tileentity.TileEntityFlag;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockFlag extends BlockContainerCustom
/*    */ {
/*    */   public BlockFlag()
/*    */   {
/* 16 */     super(net.minecraft.block.material.Material.field_151573_f);
/* 17 */     func_149713_g(0);
/* 18 */     setAABB(new net.minecraft.util.math.AxisAlignedBB(0.4375D, 0.0D, 0.4375D, 0.5625D, 1.0D, 0.5625D));
/*    */   }
/*    */   
/*    */ 
/*    */   public TileEntity func_149915_a(World world, int meta)
/*    */   {
/* 24 */     return new TileEntityFlag();
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean onBlockActivated(BlockArgHolder holder, float hitX, float hitY, float hitZ)
/*    */   {
/* 30 */     if (holder.getWorld().field_72995_K)
/*    */     {
/* 32 */       int x = holder.getBlockPos().func_177958_n();
/* 33 */       int y = holder.getBlockPos().func_177956_o();
/* 34 */       int z = holder.getBlockPos().func_177952_p();
/* 35 */       holder.getPlayer().openGui(RTMCore.instance, RTMCore.guiIdSelectTileEntityTexture, holder.getWorld(), x, y, z);
/*    */     }
/* 37 */     return true;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockFlag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */