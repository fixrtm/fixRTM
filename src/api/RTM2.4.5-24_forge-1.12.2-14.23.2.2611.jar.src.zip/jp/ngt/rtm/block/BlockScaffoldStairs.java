/*     */ package jp.ngt.rtm.block;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ import jp.ngt.ngtlib.block.BlockContainerCustomWithMeta;
/*     */ import jp.ngt.ngtlib.block.BlockUtil;
/*     */ import jp.ngt.ngtlib.math.NGTMath;
/*     */ import jp.ngt.ngtlib.math.Vec3;
/*     */ import jp.ngt.rtm.RTMBlock;
/*     */ import jp.ngt.rtm.RTMSound;
/*     */ import jp.ngt.rtm.block.tileentity.TileEntityScaffold;
/*     */ import jp.ngt.rtm.block.tileentity.TileEntityScaffoldStairs;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockScaffoldStairs
/*     */   extends BlockContainerCustomWithMeta
/*     */ {
/*     */   public BlockScaffoldStairs(Block par1)
/*     */   {
/*  34 */     super(Material.field_151573_f);
/*  35 */     func_149711_c(2.0F);
/*  36 */     func_149752_b(10.0F);
/*  37 */     func_149672_a(RTMSound.SOUND_METAL2);
/*     */   }
/*     */   
/*     */ 
/*     */   public TileEntity func_149915_a(World world, int meta)
/*     */   {
/*  43 */     return new TileEntityScaffoldStairs();
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_180633_a(World world, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack)
/*     */   {
/*  49 */     int facing = NGTMath.floor(NGTMath.normalizeAngle(placer.field_70177_z + 180.0D) / 90.0D + 0.5D) & 0x3;
/*  50 */     TileEntity tile = world.func_175625_s(pos);
/*  51 */     if ((tile instanceof TileEntityScaffold))
/*     */     {
/*  53 */       ((TileEntityScaffold)tile).setDir((byte)facing);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_185477_a(IBlockState state, World world, BlockPos pos, AxisAlignedBB entityBox, List<AxisAlignedBB> collidingBoxes, @Nullable Entity entity, boolean isActualState)
/*     */   {
/*  60 */     TileEntity tile = world.func_175625_s(pos);
/*  61 */     if ((tile instanceof TileEntityScaffold))
/*     */     {
/*  63 */       byte dir = ((TileEntityScaffold)tile).getDir();
/*  64 */       int x = pos.func_177958_n();
/*  65 */       int y = pos.func_177956_o();
/*  66 */       int z = pos.func_177952_p();
/*  67 */       byte flag0 = getConnectionType(world, x + 1, y, z, dir);
/*  68 */       byte flag1 = getConnectionType(world, x - 1, y, z, dir);
/*  69 */       byte flag2 = getConnectionType(world, x, y, z + 1, dir);
/*  70 */       byte flag3 = getConnectionType(world, x, y, z - 1, dir);
/*     */       
/*  72 */       if ((dir == 0) || (dir == 2))
/*     */       {
/*  74 */         if (flag1 != 3)
/*     */         {
/*  76 */           setAABB(new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.0625D, 2.0D, 1.0D));
/*  77 */           super.func_185477_a(state, world, pos, entityBox, collidingBoxes, entity, isActualState);
/*     */         }
/*     */         
/*  80 */         if (flag0 != 3)
/*     */         {
/*  82 */           setAABB(new AxisAlignedBB(0.9375D, 0.0D, 0.0D, 1.0D, 2.0D, 1.0D));
/*  83 */           super.func_185477_a(state, world, pos, entityBox, collidingBoxes, entity, isActualState);
/*     */         }
/*     */         
/*  86 */         for (int i = 0; i < 4; i++)
/*     */         {
/*  88 */           float f0 = i * 0.25F;
/*  89 */           float f1 = dir == 2 ? f0 : 0.75F - f0;
/*  90 */           setAABB(new AxisAlignedBB(0.0D, 0.0F + f0, f1, 1.0D, 0.25F + f0, 0.25F + f1));
/*  91 */           super.func_185477_a(state, world, pos, entityBox, collidingBoxes, entity, isActualState);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  96 */         if (flag3 != 3)
/*     */         {
/*  98 */           setAABB(new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 2.0D, 0.0625D));
/*  99 */           super.func_185477_a(state, world, pos, entityBox, collidingBoxes, entity, isActualState);
/*     */         }
/*     */         
/* 102 */         if (flag2 != 3)
/*     */         {
/* 104 */           setAABB(new AxisAlignedBB(0.0D, 0.0D, 0.9375D, 1.0D, 2.0D, 1.0D));
/* 105 */           super.func_185477_a(state, world, pos, entityBox, collidingBoxes, entity, isActualState);
/*     */         }
/*     */         
/* 108 */         for (int i = 0; i < 4; i++)
/*     */         {
/* 110 */           float f0 = i * 0.25F;
/* 111 */           float f1 = dir == 1 ? f0 : 0.75F - f0;
/* 112 */           setAABB(new AxisAlignedBB(f1, 0.0F + f0, 0.0D, 0.25F + f1, 0.25F + f0, 1.0D));
/* 113 */           super.func_185477_a(state, world, pos, entityBox, collidingBoxes, entity, isActualState);
/*     */         }
/*     */       }
/*     */       
/* 117 */       setAABB(field_185505_j);
/*     */     }
/*     */     else
/*     */     {
/* 121 */       setAABB(field_185505_j);
/* 122 */       super.func_185477_a(state, world, pos, entityBox, collidingBoxes, entity, isActualState);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static byte getConnectionType(IBlockAccess world, int x, int y, int z, byte dir)
/*     */   {
/* 129 */     IBlockState state = BlockUtil.getBlockState(world, x, y, z);
/* 130 */     Block block = state.func_177230_c();
/* 131 */     Block blockD = BlockUtil.getBlock(world, x, y - 1, z);
/* 132 */     Block blockU = BlockUtil.getBlock(world, x, y + 1, z);
/*     */     
/* 134 */     if (block == RTMBlock.scaffold)
/*     */     {
/* 136 */       TileEntity tile = BlockUtil.getTileEntity(world, x, y, z);
/* 137 */       if ((tile instanceof TileEntityScaffold))
/*     */       {
/* 139 */         byte dir2 = ((TileEntityScaffold)tile).getDir();
/* 140 */         boolean b0 = (dir2 == 0) || (dir2 == 2);
/* 141 */         return (byte)(b0 ? 1 : 2);
/*     */       }
/* 143 */       return 0;
/*     */     }
/* 145 */     if (block == RTMBlock.scaffoldStairs)
/*     */     {
/* 147 */       TileEntity tile = BlockUtil.getTileEntity(world, x, y, z);
/* 148 */       if ((tile instanceof TileEntityScaffoldStairs))
/*     */       {
/* 150 */         if (((TileEntityScaffoldStairs)tile).getDir() == dir)
/*     */         {
/* 152 */           return 3;
/*     */         }
/*     */       }
/* 155 */       return 0;
/*     */     }
/* 157 */     if (blockD == RTMBlock.scaffoldStairs)
/*     */     {
/* 159 */       TileEntity tile = BlockUtil.getTileEntity(world, x, y - 1, z);
/* 160 */       if ((tile instanceof TileEntityScaffoldStairs))
/*     */       {
/* 162 */         if (((TileEntityScaffoldStairs)tile).getDir() == dir)
/*     */         {
/* 164 */           return 3;
/*     */         }
/*     */       }
/* 167 */       return 0;
/*     */     }
/* 169 */     if (blockU == RTMBlock.scaffoldStairs)
/*     */     {
/* 171 */       TileEntity tile = BlockUtil.getTileEntity(world, x, y + 1, z);
/* 172 */       if ((tile instanceof TileEntityScaffoldStairs))
/*     */       {
/* 174 */         if (((TileEntityScaffoldStairs)tile).getDir() == dir)
/*     */         {
/* 176 */           return 3;
/*     */         }
/*     */       }
/* 179 */       return 0;
/*     */     }
/* 181 */     if (state.func_185914_p())
/*     */     {
/* 183 */       return 4;
/*     */     }
/*     */     
/*     */ 
/* 187 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void func_180653_a(World world, BlockPos pos, IBlockState state, float chance, int fortune)
/*     */   {
/* 194 */     if (!world.field_72995_K)
/*     */     {
/* 196 */       func_180635_a(world, pos, getItem(state.func_177230_c().func_176201_c(state)));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected ItemStack getItem(int damage)
/*     */   {
/* 203 */     return new ItemStack(Item.func_150898_a(this), 1, damage);
/*     */   }
/*     */   
/*     */ 
/*     */   public Boolean isEntityInsideMaterial(IBlockAccess world, BlockPos pos, IBlockState state, Entity entity, double yToTest, Material materialIn, boolean testingHead)
/*     */   {
/* 209 */     return Boolean.valueOf(BlockScaffold.getSpeed(world, pos) != 0.0F);
/*     */   }
/*     */   
/*     */ 
/*     */   public Vec3d func_176197_a(World world, BlockPos pos, Entity entity, Vec3d motion)
/*     */   {
/* 215 */     TileEntity tile = world.func_175625_s(pos);
/* 216 */     if ((tile instanceof TileEntityScaffoldStairs))
/*     */     {
/* 218 */       Vec3 vec = ((TileEntityScaffoldStairs)tile).getMotionVec();
/* 219 */       BlockScaffold.addVecToEntity(entity, vec);
/*     */     }
/*     */     
/* 222 */     return motion;
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_176199_a(World world, BlockPos pos, Entity entity)
/*     */   {
/* 228 */     TileEntity tile = world.func_175625_s(pos);
/* 229 */     if ((tile instanceof TileEntityScaffoldStairs))
/*     */     {
/* 231 */       Vec3 vec = ((TileEntityScaffoldStairs)tile).getMotionVec();
/* 232 */       BlockScaffold.addVecToEntity(entity, vec);
/*     */     }
/*     */   }
/*     */   
/*     */   public void func_180634_a(World world, BlockPos pos, IBlockState state, Entity entity) {}
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockScaffoldStairs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */