/*    */ package jp.ngt.rtm.block;
/*    */ 
/*    */ import com.google.common.base.Predicate;
/*    */ import jp.ngt.ngtlib.block.BlockContainerCustom;
/*    */ import jp.ngt.rtm.block.tileentity.TileEntityPaint;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class BlockPaint
/*    */   extends BlockContainerCustom
/*    */ {
/*    */   public BlockPaint()
/*    */   {
/* 21 */     super(Material.field_151585_k);
/* 22 */     setAABB(field_185506_k);
/*    */   }
/*    */   
/*    */ 
/*    */   public TileEntity func_149915_a(World world, int meta)
/*    */   {
/* 28 */     return new TileEntityPaint();
/*    */   }
/*    */   
/*    */ 
/*    */   @SideOnly(Side.CLIENT)
/*    */   public boolean func_176225_a(IBlockState blockState, IBlockAccess blockAccess, BlockPos pos, EnumFacing side)
/*    */   {
/* 35 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean func_176209_a(IBlockState state, boolean hitIfLiquid)
/*    */   {
/* 41 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   public void func_180653_a(World world, BlockPos pos, IBlockState state, float chance, int fortune) {}
/*    */   
/*    */ 
/*    */   public boolean isReplaceableOreGen(IBlockState state, IBlockAccess world, BlockPos pos, Predicate<IBlockState> target)
/*    */   {
/* 50 */     return true;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockPaint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */