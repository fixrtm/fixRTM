/*     */ package jp.ngt.rtm.block.decoration;
/*     */ 
/*     */ 
/*     */ public class Element
/*     */   implements Cloneable
/*     */ {
/*     */   public String name;
/*     */   
/*     */   public Face[] faces;
/*     */   
/*     */   public Element clone()
/*     */   {
/*  13 */     Element element = new Element();
/*  14 */     element.name = this.name;
/*  15 */     element.faces = new Face[this.faces.length];
/*  16 */     for (int i = 0; i < element.faces.length; i++)
/*     */     {
/*  18 */       element.faces[i] = this.faces[i].clone();
/*     */     }
/*  20 */     return element;
/*     */   }
/*     */   
/*     */   public void addVec(float[] vec3, boolean lockUV)
/*     */   {
/*  25 */     for (Face face : this.faces)
/*     */     {
/*  27 */       face.addVec(vec3, lockUV);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Element getDefaultElement()
/*     */   {
/*  33 */     Element element = new Element();
/*  34 */     element.name = "default";
/*     */     
/*  36 */     float minU = 0.0F;
/*  37 */     float maxU = 1.0F;
/*  38 */     float minV = 0.0F;
/*  39 */     float maxV = 1.0F;
/*     */     
/*  41 */     Face front = new Face();
/*  42 */     front.name = "front";
/*  43 */     front.texture = "minecraft:decoration/deco_platform_side";
/*  44 */     front.shadow = 0.8F;
/*  45 */     front.type = Face.FaceType.FRONT;
/*  46 */     front.vertex = new float[][] { { 0.0F, 1.0F, 1.0F, minU, minV }, { 0.0F, 0.0F, 1.0F, minU, maxV }, { 1.0F, 0.0F, 1.0F, maxU, maxV }, { 1.0F, 1.0F, 1.0F, maxU, minV } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  53 */     Face back = new Face();
/*  54 */     back.name = "back";
/*  55 */     back.texture = "minecraft:blocks/log_birch";
/*  56 */     back.shadow = 0.8F;
/*  57 */     back.type = Face.FaceType.BACK;
/*  58 */     back.vertex = new float[][] { { 1.0F, 1.0F, 0.0F, minU, minV }, { 1.0F, 0.0F, 0.0F, minU, maxV }, { 0.0F, 0.0F, 0.0F, maxU, maxV }, { 0.0F, 1.0F, 0.0F, maxU, minV } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */     Face left = new Face();
/*  66 */     left.name = "left";
/*  67 */     left.texture = "rtm:blocks/fireBrick";
/*  68 */     left.shadow = 0.6F;
/*  69 */     left.type = Face.FaceType.LEFT;
/*  70 */     left.vertex = new float[][] { { 1.0F, 1.0F, 1.0F, minU, minV }, { 1.0F, 0.0F, 1.0F, minU, maxV }, { 1.0F, 0.0F, 0.0F, maxU, maxV }, { 1.0F, 1.0F, 0.0F, maxU, minV } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  77 */     Face right = new Face();
/*  78 */     right.name = "right";
/*  79 */     right.texture = "minecraft:blocks/bookshelf";
/*  80 */     right.shadow = 0.6F;
/*  81 */     right.type = Face.FaceType.RIGHT;
/*  82 */     right.vertex = new float[][] { { 0.0F, 1.0F, 0.0F, minU, minV }, { 0.0F, 0.0F, 0.0F, minU, maxV }, { 0.0F, 0.0F, 1.0F, maxU, maxV }, { 0.0F, 1.0F, 1.0F, maxU, minV } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  89 */     Face top = new Face();
/*  90 */     top.name = "top";
/*  91 */     top.texture = "minecraft:decoration/deco_platform_top";
/*  92 */     top.shadow = 1.0F;
/*  93 */     top.type = Face.FaceType.TOP;
/*  94 */     top.vertex = new float[][] { { 0.0F, 1.0F, 0.0F, minU, minV }, { 0.0F, 1.0F, 1.0F, minU, maxV }, { 1.0F, 1.0F, 1.0F, maxU, maxV }, { 1.0F, 1.0F, 0.0F, maxU, minV } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */     Face bottom = new Face();
/* 102 */     bottom.name = "bottom";
/* 103 */     bottom.texture = "sound_test:blocks/deco_test";
/* 104 */     bottom.shadow = 0.5F;
/* 105 */     bottom.type = Face.FaceType.BOTTOM;
/* 106 */     bottom.vertex = new float[][] { { 0.0F, 0.0F, 1.0F, minU, minV }, { 0.0F, 0.0F, 0.0F, minU, maxV }, { 1.0F, 0.0F, 0.0F, maxU, maxV }, { 1.0F, 0.0F, 1.0F, maxU, minV } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */     element.faces = new Face[] { front, back, left, right, top, bottom };
/*     */     
/* 115 */     return element;
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/decoration/Element.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */