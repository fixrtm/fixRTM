/*    */ package jp.ngt.rtm.block.decoration;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import jp.ngt.ngtlib.io.NGTJson;
/*    */ 
/*    */ public class DecorationModel
/*    */   implements Cloneable
/*    */ {
/*  9 */   public static final DecorationModel DEFAULT_MODEL = getDefaultModel("default");
/*    */   
/*    */   public String name;
/*    */   
/*    */   public Element[] elements;
/*    */   
/*    */   public DecorationModel clone()
/*    */   {
/* 17 */     DecorationModel model = new DecorationModel();
/* 18 */     model.elements = new Element[this.elements.length];
/* 19 */     for (int i = 0; i < model.elements.length; i++)
/*    */     {
/* 21 */       model.elements[i] = this.elements[i].clone();
/*    */     }
/* 23 */     this.name += "_copy";
/* 24 */     return model;
/*    */   }
/*    */   
/*    */   public String toJson()
/*    */   {
/* 29 */     return NGTJson.getJsonFromObject(this);
/*    */   }
/*    */   
/*    */   public static DecorationModel fromJson(String json) throws IOException
/*    */   {
/* 34 */     return (DecorationModel)NGTJson.getObjectFromJson(json, DecorationModel.class);
/*    */   }
/*    */   
/*    */ 
/*    */   public static DecorationModel getDefaultModel(String name)
/*    */   {
/* 40 */     DecorationModel model = new DecorationModel();
/* 41 */     model.name = name;
/* 42 */     model.elements = new Element[] { Element.getDefaultElement() };
/* 43 */     return model;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/decoration/DecorationModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */