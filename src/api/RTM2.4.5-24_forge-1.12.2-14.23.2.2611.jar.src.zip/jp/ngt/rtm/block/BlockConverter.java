/*     */ package jp.ngt.rtm.block;
/*     */ 
/*     */ import jp.ngt.ngtlib.block.BlockContainerCustom;
/*     */ import jp.ngt.ngtlib.block.BlockUtil;
/*     */ import jp.ngt.rtm.RTMBlock;
/*     */ import jp.ngt.rtm.RTMItem;
/*     */ import jp.ngt.rtm.block.tileentity.TileEntityConverter;
/*     */ import jp.ngt.rtm.block.tileentity.TileEntityConverterCore;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockConverter extends BlockContainerCustom
/*     */ {
/*  21 */   private static int[][] pos_iron = { { -3, 0, -1 }, { -3, 0, 0 }, { -3, 0, 1 }, { 3, 0, -1 }, { 3, 0, 0 }, { 3, 0, 1 }, { -3, 1, -1 }, { -3, 1, 0 }, { -3, 1, 1 }, { -1, 1, -1 }, { -1, 1, 0 }, { -1, 1, 1 }, { 0, 1, -1 }, { 0, 1, 0 }, { 0, 1, 1 }, { 1, 1, -1 }, { 1, 1, 0 }, { 1, 1, 1 }, { 3, 1, -1 }, { 3, 1, 0 }, { 3, 1, 1 }, { -3, 2, -1 }, { -3, 2, 0 }, { -3, 2, 1 }, { -2, 2, -1 }, { -2, 2, 0 }, { -2, 2, 1 }, { -1, 2, -2 }, { -1, 2, 2 }, { 0, 2, -2 }, { 0, 2, 2 }, { 1, 2, -2 }, { 1, 2, 2 }, { 2, 2, -1 }, { 2, 2, 0 }, { 2, 2, 1 }, { 3, 2, -1 }, { 3, 2, 0 }, { 3, 2, 1 }, { -3, 3, -1 }, { -3, 3, 0 }, { -3, 3, 1 }, { -2, 3, -1 }, { -2, 3, 0 }, { -2, 3, 1 }, { -1, 3, -2 }, { -1, 3, 2 }, { 0, 3, -2 }, { 0, 3, 2 }, { 1, 3, -2 }, { 1, 3, 2 }, { 2, 3, -1 }, { 2, 3, 0 }, { 2, 3, 1 }, { 3, 3, -1 }, { 3, 3, 0 }, { 3, 3, 1 }, { -3, 4, 0 }, { -2, 4, -1 }, { -2, 4, 0 }, { -2, 4, 1 }, { -1, 4, -2 }, { -1, 4, 2 }, { 0, 4, -2 }, { 0, 4, 2 }, { 1, 4, -2 }, { 1, 4, 2 }, { 2, 4, -1 }, { 2, 4, 0 }, { 2, 4, 1 }, { 3, 4, 0 }, { -2, 5, -1 }, { -2, 5, 0 }, { -2, 5, 1 }, { -1, 5, -2 }, { -1, 5, 2 }, { 0, 5, -2 }, { 0, 5, 2 }, { 0, 5, 3 }, { 1, 5, -2 }, { 1, 5, 2 }, { 2, 5, -1 }, { 2, 5, 0 }, { 2, 5, 1 }, { -2, 6, -1 }, { -2, 6, 0 }, { -2, 6, 1 }, { -1, 6, -2 }, { -1, 6, 2 }, { 0, 6, -2 }, { 0, 6, 2 }, { 1, 6, -2 }, { 1, 6, 2 }, { 2, 6, -1 }, { 2, 6, 0 }, { 2, 6, 1 }, { -1, 7, -1 }, { -1, 7, 0 }, { -1, 7, 1 }, { 0, 7, -1 }, { 0, 7, 1 }, { 1, 7, -1 }, { 1, 7, 0 }, { 1, 7, 1 } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  30 */   private static int[][] pos_brick = { { -1, 0, -1 }, { -1, 0, 0 }, { -1, 0, 1 }, { 0, 0, -1 }, { 0, 0, 1 }, { 1, 0, -1 }, { 1, 0, 0 }, { 1, 0, 1 } };
/*     */   
/*     */   public final boolean isCore;
/*     */   
/*     */   public BlockConverter(boolean par1)
/*     */   {
/*  36 */     super(Material.field_151576_e);
/*  37 */     this.isCore = par1;
/*  38 */     func_149715_a(par1 ? 1.0F : 0.0F);
/*  39 */     if (par1)
/*     */     {
/*  41 */       setAABB(new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.9375D, 1.0D));
/*     */     }
/*  43 */     func_149711_c(2.0F);
/*  44 */     func_149752_b(10.0F);
/*     */   }
/*     */   
/*     */ 
/*     */   public TileEntity func_149915_a(World world, int p_149915_2_)
/*     */   {
/*  50 */     if (this.isCore)
/*     */     {
/*  52 */       return new TileEntityConverterCore();
/*     */     }
/*     */     
/*     */ 
/*  56 */     return new TileEntityConverter();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void func_180634_a(World worldIn, BlockPos pos, IBlockState state, Entity entity)
/*     */   {
/*  63 */     if (this == RTMBlock.converterCore)
/*     */     {
/*  65 */       entity.func_70097_a(DamageSource.field_76371_c, 1.0F);
/*  66 */       entity.func_70015_d(1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_180663_b(World world, BlockPos pos, IBlockState state)
/*     */   {
/*  73 */     if (!world.field_72995_K)
/*     */     {
/*  75 */       TileEntity tile0 = BlockUtil.getTileEntity(world, pos);
/*  76 */       if ((tile0 instanceof TileEntityConverter))
/*     */       {
/*  78 */         TileEntityConverterCore tile1 = ((TileEntityConverter)tile0).getCore();
/*  79 */         int tx = tile1.getX();
/*  80 */         int ty = tile1.getY();
/*  81 */         int tz = tile1.getZ();
/*  82 */         if ((tile1 != null) && (BlockUtil.getBlock(world, tx, ty, tz) == RTMBlock.converterCore))
/*     */         {
/*  84 */           createConverter(world, tx, ty - 4, tz, tile1.getDirection(), true);
/*     */           
/*  86 */           func_180635_a(world, new BlockPos(tx, ty - 4, tz), new ItemStack(RTMItem.steel_ingot, 64, 0));
/*  87 */           func_180635_a(world, new BlockPos(tx, ty - 4, tz), new ItemStack(RTMItem.steel_ingot, 64, 0));
/*  88 */           func_180635_a(world, new BlockPos(tx, ty - 4, tz), new ItemStack(RTMItem.steel_ingot, 64, 0));
/*  89 */           func_180635_a(world, new BlockPos(tx, ty - 4, tz), new ItemStack(RTMItem.steel_ingot, 16, 0));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte shouldCreateConverter(World world, int x, int y, int z)
/*     */   {
/* 100 */     if (BlockUtil.getBlock(world, x, y + 2, z) != RTMBlock.fireBrick)
/*     */     {
/* 102 */       return -1;
/*     */     }
/*     */     
/* 105 */     for (int i = 2; i < 7; i++)
/*     */     {
/* 107 */       for (int j = 0; j < pos_brick.length; j++)
/*     */       {
/* 109 */         if (BlockUtil.getBlock(world, x + pos_brick[j][0], y + i, z + pos_brick[j][2]) != RTMBlock.fireBrick)
/*     */         {
/* 111 */           return -1;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 117 */     for (int i = 0; i < 4; i++)
/*     */     {
/* 119 */       boolean flag = true;
/* 120 */       for (int j = 0; j < pos_iron.length; j++)
/*     */       {
/* 122 */         int[] p0 = BlockUtil.rotateBlockPos((byte)i, pos_iron[j][0], pos_iron[j][1], pos_iron[j][2]);
/* 123 */         if (BlockUtil.getBlock(world, x + p0[0], y + p0[1], z + p0[2]) != RTMBlock.steelMaterial)
/*     */         {
/* 125 */           flag = false;
/*     */         }
/*     */       }
/*     */       
/* 129 */       if (flag)
/*     */       {
/* 131 */         return (byte)i;
/*     */       }
/*     */     }
/*     */     
/* 135 */     return -1;
/*     */   }
/*     */   
/*     */   public static void createConverter(World world, int x, int y, int z, byte dir, boolean setAir)
/*     */   {
/* 140 */     if (setAir)
/*     */     {
/* 142 */       BlockUtil.setAir(world, x, y + 4, z);
/* 143 */       BlockUtil.setAir(world, x, y + 2, z);
/*     */     }
/*     */     else
/*     */     {
/* 147 */       BlockUtil.setBlock(world, x, y + 4, z, RTMBlock.converterCore, 0, 2);
/* 148 */       TileEntityConverterCore tile = (TileEntityConverterCore)BlockUtil.getTileEntity(world, x, y + 4, z);
/* 149 */       tile.setDirection(dir);
/*     */       
/* 151 */       setConverterBlock(world, x, y + 2, z, x, y + 4, z);
/*     */     }
/*     */     
/* 154 */     for (int i = 2; i < 7; i++)
/*     */     {
/* 156 */       for (int j = 0; j < pos_brick.length; j++)
/*     */       {
/* 158 */         if (setAir)
/*     */         {
/* 160 */           BlockUtil.setAir(world, x + pos_brick[j][0], y + i, z + pos_brick[j][2]);
/*     */         }
/*     */         else
/*     */         {
/* 164 */           setConverterBlock(world, x + pos_brick[j][0], y + i, z + pos_brick[j][2], x, y + 4, z);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 169 */     for (int j = 0; j < pos_iron.length; j++)
/*     */     {
/* 171 */       int[] p0 = BlockUtil.rotateBlockPos(dir, pos_iron[j][0], pos_iron[j][1], pos_iron[j][2]);
/* 172 */       if (setAir)
/*     */       {
/* 174 */         BlockUtil.setAir(world, x + p0[0], y + p0[1], z + p0[2]);
/*     */       }
/*     */       else
/*     */       {
/* 178 */         setConverterBlock(world, x + p0[0], y + p0[1], z + p0[2], x, y + 4, z);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static void setConverterBlock(World world, int x, int y, int z, int coreX, int coreY, int coreZ)
/*     */   {
/* 185 */     BlockUtil.setBlock(world, x, y, z, RTMBlock.converterBase, 0, 2);
/* 186 */     TileEntityConverter tile = (TileEntityConverter)BlockUtil.getTileEntity(world, x, y, z);
/* 187 */     tile.setCorePos(coreX, coreY, coreZ);
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */