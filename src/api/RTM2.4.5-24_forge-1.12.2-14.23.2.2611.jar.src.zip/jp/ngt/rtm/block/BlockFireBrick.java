/*     */ package jp.ngt.rtm.block;
/*     */ 
/*     */ import java.util.Random;
/*     */ import jp.ngt.ngtlib.block.BlockCustomWithMeta;
/*     */ import jp.ngt.ngtlib.block.BlockUtil;
/*     */ import jp.ngt.rtm.RTMBlock;
/*     */ import jp.ngt.rtm.RTMFluid;
/*     */ import jp.ngt.rtm.RTMMaterial;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.BlockRenderLayer;
/*     */ import net.minecraft.util.EnumBlockRenderType;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class BlockFireBrick
/*     */   extends BlockCustomWithMeta
/*     */ {
/*     */   private boolean changeColor;
/*     */   
/*     */   public BlockFireBrick(boolean randomTick)
/*     */   {
/*  29 */     super(RTMMaterial.fireproof);
/*  30 */     this.changeColor = randomTick;
/*  31 */     func_149675_a(randomTick);
/*  32 */     func_149711_c(2.0F);
/*  33 */     func_149752_b(10.0F);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean func_149662_c(IBlockState state)
/*     */   {
/*  39 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public EnumBlockRenderType func_149645_b(IBlockState state)
/*     */   {
/*  45 */     return EnumBlockRenderType.MODEL;
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public BlockRenderLayer func_180664_k()
/*     */   {
/*  52 */     return this.changeColor ? BlockRenderLayer.CUTOUT_MIPPED : BlockRenderLayer.SOLID;
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_180633_a(World world, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack)
/*     */   {
/*  58 */     super.func_180633_a(world, pos, state, placer, stack);
/*  59 */     if ((!world.field_72995_K) && ((placer instanceof EntityPlayer)))
/*     */     {
/*  61 */       if (this != RTMBlock.fireBrick)
/*     */       {
/*     */ 
/*     */ 
/*  65 */         if (this != RTMBlock.hotStoveBrick) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void func_180650_b(World world, BlockPos pos, IBlockState state, Random rand)
/*     */   {
/*  75 */     if (!world.field_72995_K)
/*     */     {
/*  77 */       if (this == RTMBlock.hotStoveBrick)
/*     */       {
/*  79 */         int x = pos.func_177958_n();
/*  80 */         int y = pos.func_177956_o();
/*  81 */         int z = pos.func_177952_p();
/*  82 */         int meta = BlockUtil.getMetadata(world, x, y, z);
/*  83 */         int n = 16 - meta;
/*     */         
/*  85 */         for (int i = 0; i < 6; i++)
/*     */         {
/*  87 */           int x0 = x + BlockUtil.field_01[i][0];
/*  88 */           int y0 = y + BlockUtil.field_01[i][1];
/*  89 */           int z0 = z + BlockUtil.field_01[i][2];
/*  90 */           Block block = BlockUtil.getBlock(world, x0, y0, z0);
/*  91 */           if (block == Blocks.field_150350_a)
/*     */           {
/*  93 */             if ((meta > 0) && (world.field_73012_v.nextInt(n) == 0))
/*     */             {
/*  95 */               BlockUtil.setBlock(world, x0, y0, z0, RTMFluid.furnaceFire, 15, 2);
/*  96 */               BlockUtil.setBlock(world, x, y, z, this, 0, 2);
/*  97 */               break;
/*     */             }
/*     */           }
/* 100 */           else if (block == RTMFluid.exhaustGas)
/*     */           {
/* 102 */             int m0 = BlockUtil.getMetadata(world, x0, y0, z0);
/* 103 */             if ((meta < 15) && (m0 > 0))
/*     */             {
/* 105 */               BlockUtil.setBlock(world, x, y, z, this, meta + 1, 2);
/* 106 */               BlockUtil.setBlock(world, x0, y0, z0, RTMFluid.exhaustGas, m0 - 1, 2);
/* 107 */               break;
/*     */             }
/*     */           }
/* 110 */           else if (block == Blocks.field_150353_l)
/*     */           {
/* 112 */             if (meta < 15)
/*     */             {
/* 114 */               BlockUtil.setBlock(world, x, y, z, this, meta + 1, 2);
/* 115 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String getHarvestTool(IBlockState state)
/*     */   {
/* 126 */     return "pickaxe";
/*     */   }
/*     */   
/*     */ 
/*     */   public int getHarvestLevel(IBlockState state)
/*     */   {
/* 132 */     return 0;
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockFireBrick.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */