/*    */ package jp.ngt.rtm.block;
/*    */ 
/*    */ import jp.ngt.ngtlib.block.BlockArgHolder;
/*    */ import jp.ngt.ngtlib.block.BlockUtil;
/*    */ import jp.ngt.ngtlib.util.NGTUtil;
/*    */ import jp.ngt.rtm.RTMItem;
/*    */ import jp.ngt.rtm.block.tileentity.TileEntityPoint;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockPoint extends BlockMachineBase
/*    */ {
/*    */   public BlockPoint()
/*    */   {
/* 20 */     super(Material.field_151576_e);
/* 21 */     setAABB(new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.3125D, 1.0D));
/*    */   }
/*    */   
/*    */ 
/*    */   public TileEntity func_149915_a(World var1, int var2)
/*    */   {
/* 27 */     return new TileEntityPoint();
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean onBlockActivated(BlockArgHolder holder, float hitX, float hitY, float hitZ)
/*    */   {
/* 33 */     World world = holder.getWorld();
/* 34 */     BlockPos pos = holder.getBlockPos();
/* 35 */     EntityPlayer player = holder.getPlayer();
/* 36 */     int x = pos.func_177958_n();
/* 37 */     int y = pos.func_177956_o();
/* 38 */     int z = pos.func_177952_p();
/* 39 */     if (!clickMachine(world, x, y, z, player))
/*    */     {
/* 41 */       TileEntity tile = BlockUtil.getTileEntity(world, x, y, z);
/* 42 */       if ((tile != null) && ((tile instanceof TileEntityPoint)))
/*    */       {
/* 44 */         TileEntityPoint point = (TileEntityPoint)tile;
/* 45 */         if (NGTUtil.isEquippedItem(player, RTMItem.crowbar))
/*    */         {
/* 47 */           if (!world.field_72995_K)
/*    */           {
/* 49 */             float f0 = point.getMove();
/* 50 */             point.setMove(-f0);
/*    */           }
/*    */           
/*    */ 
/*    */         }
/* 55 */         else if (!world.field_72995_K)
/*    */         {
/* 57 */           boolean b0 = point.isActivated();
/* 58 */           point.setActivated(!b0);
/* 59 */           world.func_175685_c(pos, this, true);
/* 60 */           world.func_175685_c(pos.func_177977_b(), this, true);
/*    */         }
/*    */         
/* 63 */         point.onActivate();
/* 64 */         return true;
/*    */       }
/*    */     }
/* 67 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   protected int getWeakPower(BlockArgHolder holder)
/*    */   {
/* 73 */     TileEntity tile = BlockUtil.getTileEntity(holder.getBlockAccess(), holder.getBlockPos());
/* 74 */     boolean b = (tile != null) && ((tile instanceof TileEntityPoint)) && (((TileEntityPoint)tile).isActivated());
/* 75 */     return b ? 15 : 0;
/*    */   }
/*    */   
/*    */ 
/*    */   protected int getStrongPower(BlockArgHolder holder)
/*    */   {
/* 81 */     return getWeakPower(holder);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean func_149744_f(IBlockState state)
/*    */   {
/* 87 */     return true;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockPoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */