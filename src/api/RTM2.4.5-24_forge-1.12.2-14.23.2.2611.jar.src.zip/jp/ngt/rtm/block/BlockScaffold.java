/*     */ package jp.ngt.rtm.block;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ import jp.ngt.ngtlib.block.BlockContainerCustomWithMeta;
/*     */ import jp.ngt.ngtlib.block.BlockUtil;
/*     */ import jp.ngt.ngtlib.math.NGTMath;
/*     */ import jp.ngt.ngtlib.math.Vec3;
/*     */ import jp.ngt.rtm.RTMBlock;
/*     */ import jp.ngt.rtm.block.tileentity.TileEntityScaffold;
/*     */ import jp.ngt.rtm.block.tileentity.TileEntityScaffoldStairs;
/*     */ import jp.ngt.rtm.modelpack.cfg.OrnamentConfig;
/*     */ import jp.ngt.rtm.modelpack.modelset.ModelSetOrnament;
/*     */ import jp.ngt.rtm.modelpack.state.ResourceState;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockScaffold extends BlockContainerCustomWithMeta
/*     */ {
/*     */   public BlockScaffold()
/*     */   {
/*  33 */     super(Material.field_151573_f);
/*  34 */     func_149711_c(2.0F);
/*  35 */     func_149752_b(10.0F);
/*  36 */     func_149672_a(jp.ngt.rtm.RTMSound.SOUND_METAL2);
/*  37 */     setAABB(field_185505_j);
/*     */   }
/*     */   
/*     */ 
/*     */   public TileEntity func_149915_a(World world, int par2)
/*     */   {
/*  43 */     return new TileEntityScaffold();
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_180633_a(World world, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack)
/*     */   {
/*  49 */     int i0 = NGTMath.floor(NGTMath.normalizeAngle(placer.field_70177_z + 180.0D) / 90.0D + 0.5D) & 0x3;
/*     */     
/*  51 */     TileEntity tile = world.func_175625_s(pos);
/*  52 */     if ((tile instanceof TileEntityScaffold))
/*     */     {
/*  54 */       ((TileEntityScaffold)tile).setDir((byte)i0);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void func_185477_a(IBlockState state, World world, BlockPos pos, AxisAlignedBB entityBox, List<AxisAlignedBB> collidingBoxes, @Nullable Entity entity, boolean isActualState)
/*     */   {
/*  61 */     setAABB(new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.0625D, 1.0D));
/*  62 */     super.func_185477_a(state, world, pos, entityBox, collidingBoxes, entity, isActualState);
/*     */     
/*  64 */     TileEntity tile = world.func_175625_s(pos);
/*  65 */     byte dir = ((TileEntityScaffold)tile).getDir();
/*  66 */     boolean b0 = (dir == 0) || (dir == 2);
/*  67 */     int x = pos.func_177958_n();
/*  68 */     int y = pos.func_177956_o();
/*  69 */     int z = pos.func_177952_p();
/*  70 */     byte flag0 = getConnectionType(world, x + 1, y, z, (byte)1);
/*  71 */     byte flag1 = getConnectionType(world, x - 1, y, z, (byte)1);
/*  72 */     byte flag2 = getConnectionType(world, x, y, z + 1, (byte)0);
/*  73 */     byte flag3 = getConnectionType(world, x, y, z - 1, (byte)0);
/*  74 */     boolean flagXP = ((flag0 < 1) || (flag0 > 3)) && ((b0) || (flag2 == 1) || (flag3 == 1) || (flag2 == 3) || (flag3 == 3));
/*  75 */     boolean flagXN = ((flag1 < 1) || (flag1 > 3)) && ((b0) || (flag2 == 1) || (flag3 == 1) || (flag2 == 3) || (flag3 == 3));
/*  76 */     boolean flagZP = ((flag2 < 1) || (flag2 > 3)) && ((!b0) || (flag0 == 2) || (flag1 == 2) || (flag0 == 3) || (flag1 == 3));
/*  77 */     boolean flagZN = ((flag3 < 1) || (flag3 > 3)) && ((!b0) || (flag0 == 2) || (flag1 == 2) || (flag0 == 3) || (flag1 == 3));
/*     */     
/*  79 */     if (flagXP)
/*     */     {
/*  81 */       setAABB(new AxisAlignedBB(0.9375D, 0.0D, 0.0D, 1.0D, 1.5D, 1.0D));
/*  82 */       super.func_185477_a(state, world, pos, entityBox, collidingBoxes, entity, isActualState);
/*     */     }
/*     */     
/*  85 */     if (flagXN)
/*     */     {
/*  87 */       setAABB(new AxisAlignedBB(0.0D, 0.0D, 0.0D, 0.0625D, 1.5D, 1.0D));
/*  88 */       super.func_185477_a(state, world, pos, entityBox, collidingBoxes, entity, isActualState);
/*     */     }
/*     */     
/*  91 */     if (flagZP)
/*     */     {
/*  93 */       setAABB(new AxisAlignedBB(0.0D, 0.0D, 0.9375D, 1.0D, 1.5D, 1.0D));
/*  94 */       super.func_185477_a(state, world, pos, entityBox, collidingBoxes, entity, isActualState);
/*     */     }
/*     */     
/*  97 */     if (flagZN)
/*     */     {
/*  99 */       setAABB(new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.5D, 0.0625D));
/* 100 */       super.func_185477_a(state, world, pos, entityBox, collidingBoxes, entity, isActualState);
/*     */     }
/*     */     
/* 103 */     setAABB(field_185505_j);
/*     */   }
/*     */   
/*     */ 
/*     */   public static byte getConnectionType(IBlockAccess world, int x, int y, int z, byte dir)
/*     */   {
/* 109 */     IBlockState state = BlockUtil.getBlockState(world, x, y, z);
/* 110 */     Block block0 = state.func_177230_c();
/* 111 */     Block block1 = BlockUtil.getBlock(world, x, y - 1, z);
/*     */     
/* 113 */     if (block0 == RTMBlock.scaffold)
/*     */     {
/* 115 */       TileEntity tile = BlockUtil.getTileEntity(world, x, y, z);
/* 116 */       if ((tile instanceof TileEntityScaffold))
/*     */       {
/* 118 */         byte dir2 = ((TileEntityScaffold)tile).getDir();
/* 119 */         boolean b0 = (dir2 == 0) || (dir2 == 2);
/* 120 */         return (byte)(b0 ? 1 : 2);
/*     */       }
/* 122 */       return 0;
/*     */     }
/* 124 */     if (block0 == RTMBlock.scaffoldStairs)
/*     */     {
/* 126 */       TileEntity tile = BlockUtil.getTileEntity(world, x, y, z);
/* 127 */       if ((tile instanceof TileEntityScaffoldStairs))
/*     */       {
/* 129 */         byte dir2 = ((TileEntityScaffoldStairs)tile).getDir();
/* 130 */         boolean flag = ((dir == 1) && ((dir2 == 1) || (dir2 == 3))) || ((dir == 0) && ((dir2 == 0) || (dir2 == 2)));
/* 131 */         return (byte)(flag ? 3 : 0);
/*     */       }
/* 133 */       return 0;
/*     */     }
/* 135 */     if (block1 == RTMBlock.scaffoldStairs)
/*     */     {
/* 137 */       TileEntity tile = BlockUtil.getTileEntity(world, x, y - 1, z);
/* 138 */       if ((tile instanceof TileEntityScaffoldStairs))
/*     */       {
/* 140 */         byte dir2 = ((TileEntityScaffoldStairs)tile).getDir();
/* 141 */         boolean flag = ((dir == 1) && ((dir2 == 1) || (dir2 == 3))) || ((dir == 0) && ((dir2 == 0) || (dir2 == 2)));
/* 142 */         return (byte)(flag ? 3 : 0);
/*     */       }
/* 144 */       return 0;
/*     */     }
/* 146 */     if (state.func_185914_p())
/*     */     {
/* 148 */       return 4;
/*     */     }
/*     */     
/*     */ 
/* 152 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected ItemStack getItem(int damage)
/*     */   {
/* 159 */     return new ItemStack(Item.func_150898_a(this), 1, damage);
/*     */   }
/*     */   
/*     */   public static float getSpeed(IBlockAccess world, BlockPos pos)
/*     */   {
/* 164 */     TileEntity tile = world.func_175625_s(pos);
/* 165 */     if ((tile instanceof TileEntityScaffold))
/*     */     {
/* 167 */       return ((OrnamentConfig)((ModelSetOrnament)((TileEntityScaffold)tile).getResourceState().getResourceSet()).getConfig()).conveyorSpeed;
/*     */     }
/* 169 */     return 0.0F;
/*     */   }
/*     */   
/*     */ 
/*     */   public Boolean isEntityInsideMaterial(IBlockAccess world, BlockPos pos, IBlockState state, Entity entity, double yToTest, Material materialIn, boolean testingHead)
/*     */   {
/* 175 */     return Boolean.valueOf(getSpeed(world, pos) != 0.0F);
/*     */   }
/*     */   
/*     */ 
/*     */   public Vec3d func_176197_a(World world, BlockPos pos, Entity entity, Vec3d motion)
/*     */   {
/* 181 */     TileEntity tile = world.func_175625_s(pos);
/* 182 */     if ((tile instanceof TileEntityScaffold))
/*     */     {
/* 184 */       Vec3 vec = ((TileEntityScaffold)tile).getMotionVec();
/* 185 */       addVecToEntity(entity, vec);
/*     */     }
/*     */     
/* 188 */     return motion;
/*     */   }
/*     */   
/*     */   public static void addVecToEntity(Entity entity, Vec3 vec)
/*     */   {
/* 193 */     if ((vec.length() > 0.0D) && (entity.func_96092_aw()))
/*     */     {
/*     */ 
/* 196 */       double d1 = 1.0D;
/* 197 */       entity.field_70159_w += vec.getX() * d1;
/* 198 */       entity.field_70181_x += vec.getY() * d1;
/* 199 */       entity.field_70179_y += vec.getZ() * d1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockScaffold.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */