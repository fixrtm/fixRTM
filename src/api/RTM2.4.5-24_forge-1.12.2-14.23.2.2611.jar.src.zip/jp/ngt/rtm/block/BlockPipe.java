/*     */ package jp.ngt.rtm.block;
/*     */ 
/*     */ import java.util.List;
/*     */ import jp.ngt.ngtlib.block.BlockArgHolder;
/*     */ import jp.ngt.ngtlib.block.BlockContainerCustomWithMeta;
/*     */ import jp.ngt.ngtlib.block.BlockSet;
/*     */ import jp.ngt.ngtlib.block.BlockUtil;
/*     */ import jp.ngt.rtm.RTMItem;
/*     */ import jp.ngt.rtm.RTMMaterial;
/*     */ import jp.ngt.rtm.RTMSound;
/*     */ import jp.ngt.rtm.block.tileentity.TileEntityPipe;
/*     */ import jp.ngt.rtm.item.ItemInstalledObject.IstlObjType;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockPipe
/*     */   extends BlockContainerCustomWithMeta
/*     */ {
/*     */   public BlockPipe()
/*     */   {
/*  24 */     super(RTMMaterial.fireproof);
/*  25 */     func_149713_g(0);
/*  26 */     func_149711_c(2.0F);
/*  27 */     func_149752_b(10.0F);
/*  28 */     func_149672_a(RTMSound.SOUND_METAL2);
/*     */   }
/*     */   
/*     */ 
/*     */   public TileEntity func_149915_a(World p_149915_1_, int p_149915_2_)
/*     */   {
/*  34 */     return new TileEntityPipe();
/*     */   }
/*     */   
/*     */ 
/*     */   protected void neighborChanged(BlockArgHolder holder)
/*     */   {
/*  40 */     super.neighborChanged(holder);
/*  41 */     TileEntityPipe tile = (TileEntityPipe)BlockUtil.getTileEntity(holder.getWorld(), holder.getBlockPos());
/*  42 */     tile.refresh();
/*     */   }
/*     */   
/*     */   public List<BlockSet> setLiquid(World world, int x, int y, int z, int fromX, int fromY, int fromZ, List<BlockSet> list, int count)
/*     */   {
/*  47 */     if (count > 255)
/*     */     {
/*  49 */       return list;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  71 */     TileEntityPipe tile = (TileEntityPipe)BlockUtil.getTileEntity(world, x, y, z);
/*  72 */     for (int i = 0; i < 6; i++)
/*     */     {
/*  74 */       int x0 = x + BlockUtil.facing[i][0];
/*  75 */       int y0 = y + BlockUtil.facing[i][1];
/*  76 */       int z0 = z + BlockUtil.facing[i][2];
/*  77 */       if ((x0 != fromX) || (y0 != fromY) || (z0 != fromZ))
/*     */       {
/*  79 */         if (tile.connection[i] == 3)
/*     */         {
/*  81 */           Block block = BlockUtil.getBlock(world, x0, y0, z0);
/*  82 */           int m0 = BlockUtil.getMetadata(world, x0, y0, z0);
/*  83 */           BlockSet bs = new BlockSet(x0, y0, z0, block, m0);
/*  84 */           if (!list.contains(bs))
/*     */           {
/*  86 */             list.add(bs);
/*     */           }
/*     */         }
/*  89 */         else if (tile.connection[i] == 2)
/*     */         {
/*  91 */           setLiquid(world, x0, y0, z0, x, y, z, list, ++count);
/*     */         }
/*     */       }
/*     */     }
/*  95 */     return list;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getHarvestTool(IBlockState state)
/*     */   {
/* 101 */     return "pickaxe";
/*     */   }
/*     */   
/*     */ 
/*     */   public int getHarvestLevel(IBlockState state)
/*     */   {
/* 107 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */   protected ItemStack getItem(int damage)
/*     */   {
/* 113 */     return new ItemStack(RTMItem.installedObject, 1, ItemInstalledObject.IstlObjType.PIPE.id);
/*     */   }
/*     */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockPipe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */