/*    */ package jp.ngt.rtm.block;
/*    */ 
/*    */ import jp.ngt.rtm.RTMItem;
/*    */ import jp.ngt.rtm.block.tileentity.TileEntityLight;
/*    */ import jp.ngt.rtm.item.ItemInstalledObject.IstlObjType;
/*    */ import net.minecraft.block.SoundType;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockLight extends BlockMachineBase
/*    */ {
/*    */   public BlockLight()
/*    */   {
/* 16 */     super(Material.field_151592_s);
/* 17 */     func_149672_a(SoundType.field_185853_f);
/*    */   }
/*    */   
/*    */ 
/*    */   public TileEntity func_149915_a(World var1, int var2)
/*    */   {
/* 23 */     return new TileEntityLight();
/*    */   }
/*    */   
/*    */ 
/*    */   protected ItemStack getItem(int meta)
/*    */   {
/* 29 */     return new ItemStack(RTMItem.installedObject, 1, ItemInstalledObject.IstlObjType.LIGHT.id);
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockLight.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */