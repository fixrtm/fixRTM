/*    */ package jp.ngt.rtm.block;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.util.BlockRenderLayer;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class BlockIronPillar extends Block
/*    */ {
/*    */   public BlockIronPillar()
/*    */   {
/* 18 */     super(Material.field_151576_e);
/* 19 */     func_149711_c(2.0F);
/* 20 */     func_149752_b(10.0F);
/* 21 */     func_149713_g(1);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean func_149662_c(IBlockState state)
/*    */   {
/* 27 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean func_149686_d(IBlockState state)
/*    */   {
/* 33 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   @SideOnly(Side.CLIENT)
/*    */   public BlockRenderLayer func_180664_k()
/*    */   {
/* 40 */     return BlockRenderLayer.CUTOUT;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean isLadder(IBlockState state, IBlockAccess world, BlockPos pos, EntityLivingBase entity)
/*    */   {
/* 47 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @SideOnly(Side.CLIENT)
/*    */   public boolean func_176225_a(IBlockState blockState, IBlockAccess access, BlockPos pos, EnumFacing side)
/*    */   {
/* 55 */     return access.func_180495_p(pos.func_177972_a(side)).func_177230_c() != this;
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockIronPillar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */