/*    */ package jp.ngt.rtm.block;
/*    */ 
/*    */ import jp.ngt.ngtlib.block.BlockContainerCustom;
/*    */ import jp.ngt.rtm.block.tileentity.TileEntityPlantOrnament;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockPlant extends BlockContainerCustom
/*    */ {
/*    */   public BlockPlant()
/*    */   {
/* 13 */     super(Material.field_151585_k);
/*    */   }
/*    */   
/*    */ 
/*    */   public TileEntity func_149915_a(World world, int par2)
/*    */   {
/* 19 */     return new TileEntityPlantOrnament();
/*    */   }
/*    */ }


/* Location:              /Users/anatawa12/Desktop/fixRtm/mods/RTM2.4.5-24_forge-1.12.2-14.23.2.2611.jar!/jp/ngt/rtm/block/BlockPlant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */