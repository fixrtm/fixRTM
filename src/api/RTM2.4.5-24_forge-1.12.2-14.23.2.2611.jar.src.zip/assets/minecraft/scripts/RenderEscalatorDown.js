//include <scripts/RenderEscalatorUp.js>

function render(entity, pass, par3)//メソッド重複してたら後の方で上書きされる
{
	renderEscalator(entity, pass, par3, true);
}
